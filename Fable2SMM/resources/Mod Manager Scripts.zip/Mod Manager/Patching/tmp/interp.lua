print("(app)ly or (gen)erate childhood patch?")
while ans ~= "app" and ans ~= "gen" do
	ans = io.read()
end

local patchfile = "C:/CGames/Fable 2 GOTY Modded/data/scripts/Mod Manager/Patching/tmp/nongame_patch.lua"
local originalfile = "C:/CGames/Fable 2 GOTY Modded/data/scripts/Mod Manager/Patching/tmp/nongame.lua"
local modifiedfile = "C:/CGames/Fable 2 GOTY Modded/data/scripts/Mod Manager/Patching/tmp/nongame_modified.lua"
if ans == "app" then
	local app, reason = loadfile("C:/CGames/Fable 2 GOTY Modded/data/scripts/Mod Manager/Patching/DeltaPatchApplicator ItVal.lua")
	if not app then error(reason) end

	app(originalfile, patchfile)
elseif ans == "gen" then
	local gen, reason = loadfile("C:/CGames/Fable 2 GOTY Modded/data/scripts/Mod Manager/Patching/DeltaPatchGenerator.lua")
	if not gen then error(reason) end

	gen(originalfile, modifiedfile, patchfile)
end