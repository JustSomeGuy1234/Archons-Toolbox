--[[

This code runs in the GUI Lua state. 
It has access to the Anark/Gameface GUI, though I have no idea to what extent.

This script will be run every time the GUI state is restarted or another instance is created.
This includes (but is definitely not limited to):
  Loading into the main menu
  Every time you go into a section of the pause menu

Currently there is no mod system for the GUI. I haven't really looked into it too much.
The main reason I use this is for access to the IO table, which I use for quest script patch generation.
  (These patches are different to the file patches used to install the manager)

--]]

output("Calling our external GUI code!")


--[[
-- This is kind of an example of what we have access to.

if GUI then
  output("There's a g_Menu here")
  local old_update = GUI.UpdateInput
  local framecount = 0
  function GUI.UpdateInput(...)
    old_update(...)
    framecount = framecount + 1
    if framecount >= 60 then
      print("60 frames!")
      framecount = 0
    end
    if GUI.Input.PushingUpHeld then output("g_HUD = " .. tostring(g_HUD or "nil")) end
  end
else
  output("There's no g_Menu yet")
end

if g_HUD then
  output("There's a g_HUD now!")
else
  output("There's no g_HUD yet")
end

--]]


local patchprocess, err = loadfile("GAME:/data/scripts/Mod Manager/Patching/DeltaPatchGUI.lua")
if err then
  output("Failed to compile DeltaPatchGUI")
else
  local patchprocessworked
  patchprocessworked, err = pcall(patchprocess)
  if not patchprocessworked then
    output("Failed to run DeltaPatchGUI:\n" .. tostring(err))
  end
  output("Patching Worked: " .. tostring(patchprocessworked) .. "\nPatched function/err: " .. tostring(err))
end


local app = loadfile("GAME:/data/scripts/Mod Manager/Patching/DeltaPatchApplicator.lua")


