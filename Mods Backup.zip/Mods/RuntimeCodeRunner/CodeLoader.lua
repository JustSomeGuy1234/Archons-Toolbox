-- By github.com/JustSomeGuy1234
-- Just Some Guy#8131 on Discord.

-- This script essentially reads and runs a specific external lua file every x number of ticks. (Currently every couple of seconds)
-- When the external script gets run, it should return an int which is the "newChecksum" and a function which is the users code. (codetorun)
-- This script then compares newChecksum to curChecksum.
-- If it is different, this script knows the external script has changed, so it calls the users function that was also returned.
-- The function that the script should return contains code that we can change as we wish, as it's in an external plaintext file.
-- We also have manual control over newChecksum in the same external file, so when we want our function run we just change it.

-- So basically, whenever we want to run the code in the external script,
-- we just change the curChecksum value in it and this script will execute the function, one that we can modify at runtime.


local self = getfenv(1)

function ResetCodeEnv()
	CodeEnv = {}
	CodeEnv.__index = _G
	CodeEnv.CodeLoader = self
	setmetatable(CodeEnv, CodeEnv)
end
ResetCodeEnv()

ShouldDie = false
curChecksum = 0
newChecksum = 0
timeBetweenRuns = 2
runTimer = QuestManager.NewTimer(timeBetweenRuns)
lastResult = false
lastReason = "Last reason never set"
logString = "Log string never set"
logEnabled = true
ExternalScriptPath = "scripts/Mods/RuntimeCodeRunner/RuntimeCode.lua"
LogOffset = CVector3(0, -2, 2)

function ModUpdate()
  -- GUI.DisplayMessageBox("RuntimeScriptLoader starting (for the first time this save?)...")
  local extra_log_params = {DrawInFrontOfScene = true}
  while not ShouldDie do
    -- This code loops every tick.
		coroutine.yield()

 
	-- The following function call draws the text that says true; nil.
    -- We also toggle the debug text with right stick click.
    if logEnabled then
		if not LogOffset then
			LogOffset = CVector3(0, -2, 2)
		end
		Debug.Draw3DText(GetPlayerHero():GetPosition() + LogOffset, logString, 1, extra_log_params)
    end
	  local is_stick_released, newmessage = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_GENERIC_RIGHT_STICK_RELEASED, lastMessageID)
		if is_stick_released then
			logEnabled = not logEnabled
			lastMessageID = newmessage:GetID()
		end
		

    -- If a couple of seconds have passed, reset timer and run ext. script
    if runTimer:GetTime() <= 0 then
		runTimer:SetTime(timeBetweenRuns)

		  if ExternalScriptPath == nil then
				GUI.DisplayMessageBox("CodeLoader failed: External script not specified.\nEnsure it is set in the CodeLoader.lua file.")
				return
		  end
		  local alreadyErrored = false
		  local ExternalScript = loadfile(ExternalScriptPath)
		  if type(ExternalScript) ~= "function" then
				lastReason = "Failed to run external script:\n" .. tostring(ExternalScriptPath)
				if ExternalScript == nil then
					lastReason = lastReason .. "\nReason: Probable syntax error."
				else
					lastReason = lastReason .. "\nReason: File probably not found. Ensure it has been added to dir.manifest"
				end
				lastReason = lastReason .. "\nError occured on frame: " .. Timing.GetWorldFrame()
				lastResult = false
				alreadyErrored = true
		  else
			-- Now we run the external script to retrieve the code and checksum... Most of the time.
			-- If the script fails to run, CodeToRun will actually be the error log, and newChecksum will be nil. Just keep that in mind.
			setfenv(ExternalScript, CodeEnv)
				scriptRan, CodeToRun, newChecksum = pcall(ExternalScript)
		  end
		  local codeToRunType = type(CodeToRun)
		  if not alreadyErrored and (not scriptRan or codeToRunType ~= "function" or newChecksum == nil) then
				-- We know that the script either: failed to define the code function, checksum, or failed to run due to a syntax error.
				alreadyErrored = true
				if not scriptRan then
					-- As previously mentioned, CodeToRun is actually the error message if the script has failed.
					lastResult = scriptRan
					lastReason = CodeToRun
				elseif	newChecksum == nil then
					lastResult = false
					lastReason = "External runtime code script has not returned the newChecksum value!"
				elseif codeToRunType ~= "function" then
					lastResult = false
					lastReason = "External runtime code script didn't return the function to call!"
				end
	    elseif not alreadyErrored and curChecksum ~= newChecksum then
				-- At this point the script ran, we changed the checksum in the external script ourselves, and everything *should be* what it should be. Run the returned function.
	      curChecksum = newChecksum
	      lastResult, lastReason = pcall(CodeToRun) -- Note the pcall. If our external script causes an error it will kill this coroutine.
	    end
		logString = tostring(lastResult) .. "\n" .. tostring(lastReason)
    end
  end
end

-- [[ MCM Stuff ]]
function SetLogOffsets()
	local function AskForOffset(axis, cur, tmp)
		local returnedAmount, user_accepted = GUI.AskForAmount(tmp, 
			{Type = EAdjusterTypes.ADJUSTER_TYPE_MONEY, MinVal = -500, MaxVal = 500, Increment = 5, DefaultVal = cur, ShowSign = true},
			"Set Log " .. axis .. " Offset.\nUnit is pretendcentimetres", 1)
		if user_accepted then
			if returnedAmount > 500 then
				returnedAmount = (returnedAmount - 4294967295)
			end
			return returnedAmount / 100
		end
	end
	local tmp = {}
	local cur_x = LogOffset:GetX() * 100
	local cur_y = LogOffset:GetY() * 100
	local cur_z = LogOffset:GetZ() * 100
	local returnedoff = AskForOffset("X", cur_x, tmp)
	if returnedoff then
		LogOffset:SetX(returnedoff)
	end
	returnedoff = AskForOffset("Y (forward?)", cur_y, tmp)
	if returnedoff then
		LogOffset:SetY(returnedoff)
	end
	returnedoff = AskForOffset("Z (up?)", cur_z, tmp)
	if returnedoff then
		LogOffset:SetZ(returnedoff)
	end
end

function GetMainMCMEntries()
	return {
		MCM.NewActionEntry("3d Log Offsets", true, SetLogOffsets, nil)
	}
end
function GetMCMEntry()
	return MCM.NewActionEntry("Code Loader", true, MCM.OpenMenu, {"Code Loader Config", GetMainMCMEntries}), "CodeLoader"
end

-- [[ Mod Management Stuff ]]
function Terminate()
	ShouldDie = true
	return {LogOffset, curChecksum}
end

function Enable()
	GUI.DisplayMessageBox("Enabling CodeLoader")
end

function Disable()
	GUI.DisplayMessageBox("Disabling CodeLoader")
end

function Uninstall()
	GUI.DisplayMessageBox("Uninstalling CodeLoader")
	Disable()
	return Terminate()
end

do
	local tmp = {...}
	local args = tmp[1]
	if args then
		LogOffset = (type(args[1]) == "userdata" and args[1]) or LogOffset
		curChecksum = args[2] or 0
	end
end
