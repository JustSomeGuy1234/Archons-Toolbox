--[[
If your mod recieves messages that should be uniquely handled and not received by OTHER MODS i.e. GUI messages (specifically value picker),
then it should use the FCFS table. (First Come First Serve)
--]]
FCFSMessages = {}

local args = {...} 
local manager = args[1] 

DisplayAllKeys = function(someTable, val) -- table to print, bool for whether to print key or values. Intended to print keys.
	local howManyKeys = 0
	local tmpstr = ""
	for k,v in pairs(someTable) do
		local resultStr = ""
		if val then
			resultStr = tostring(v)
		else
			resultStr = tostring(k)
		end
		tmpstr = tmpstr .. "\n" .. resultStr
		howManyKeys = howManyKeys+1
	end
	if howManyKeys < 1 then
		GUI.DisplayMessageBox("Table had no keys!")
		return
	end
	
	-- Add all keys to a string, seperated by new lines
	local strTable = {}

	for s in tmpstr:gmatch("[^\r\n]+") do
		table.insert(strTable, s)
	end
	
	-- Print 12 lines of a table's keys at a time
	local strBundle = ""
	myI = 0
	for i = 1, #strTable do
		myI = i
		if i % 12 == 0 then
			GUI.DisplayMessageBox(strBundle .. "\nPage " .. tostring(i/12) .. " of " .. tostring(#strTable/12))
			strBundle = ""
		end
		strBundle = strBundle .. tostring(strTable[i]) .. "\n"
	end
	if myI % 12 ~= 0 then
		GUI.DisplayMessageBox(strBundle)
		strBundle = ""
		myI = 0
	end
end

function UnstuckHero(ent)
	if type(ent) ~= "userdata" then
		ent = QuestManager.HeroEntity
	end
	ScriptFunction.SetDefaultCamera()
	Player.StopInteractionMode(ent)
end

function LoadModFile(relative_path, nameid_override)
	local modspath = "scripts/Mods/"

	local nameid = nameid_override or getfenv(2)._NAMEID
	if not nameid then
		error("LoadModFile: Failed to get _NAMEID from calling mod! Are you calling this from your mod environment? If not, pass your mods NameID as the second arg.")
	end

	local final_path = modspath .. nameid .. "/" .. relative_path
	local script_function = loadfile(final_path)
	if not script_function then
		GUI.DisplayMessageBox("LoadModFile: Failed to compile script:\n" .. final_path)
		return
	end
	if type(script_function) == "string" then
		GUI.DisplayMessageBox("LoadModFile: Failed to find script:\n" .. final_path .. "\n\nAre you sure it's in your modmanifest.json and dir.manifest?")
		return
	end
	setfenv(script_function, getfenv(2))
	return script_function
end

function ReloadMod(name)
	-- This function should ONLY be used for development to reload code changes.
	-- Updating your mod is properly done automatically when your modmanifest's version changes.
	name = name or getfenv(2)._NAMEID
	if not name then
		GUI.DisplayMessageBox("A mod just tried to manually update but did not pass its NameID!")
		return
	end
	local node = manager.GetModHandleWithName(name)
	if not node then
		GUI.DisplayMessageBox("A mod just tried to manually update but a mod handle with name " .. tostring(name) .. " cannot be found!")
		return
	end
	manager.UpdateModForced(name, node)
end