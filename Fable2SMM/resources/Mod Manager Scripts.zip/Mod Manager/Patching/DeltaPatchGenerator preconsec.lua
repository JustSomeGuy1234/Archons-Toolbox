-- DeltaPatchGenerator.lua

--[[
Args:
origpath: The unmodified script path
newpath: The modified script path
outpath: The patch output path

Returns: A table containing each differing byte. This is most likely useless as the table is written to the output path to be loaded later by the game state.
--]]

local args = {...}
local origpath = args[1]
local newpath = args[2]
local outpath = args[3]
if not origpath or not newpath or not outpath then
	print("no source file or modded file or outpath provided")
	io.input()
	return
end

-- Load the original file and dump it into a string. Do the same with the modified version.
local loaded, err = loadfile(origpath)
if not loaded or err then error(err) end
local originaldumped = string.dump(loaded)

loaded, err = loadfile(newpath)
if not loaded or err then error(err) end
local newdumped = string.dump(loaded)


-- For each byte in our modified script, compare to the original. 
-- Any differences will be added to two tables one will contain the offsets, the other will contain the values. Neither will have keys.
-- Offsets will be relative to the last one. This saves a lot of space as instead of {6000,6001,6002,6342,6343}, we'll have {6000,1,1,340,1} which almost halves the size.
-- (A negative offset indicates the number of bytes that we can write consecutively without needing an offset for each)
local patchtable = {}

print(#newdumped)
print(#originaldumped)
patchoffsetsegments = {}
patchvaluesegments = {}
local lastoffset = 0
local totalconsecs = 0
local consecs = 0
for offset=1, #newdumped do
	local newByte = newdumped:sub(offset, offset)
	if newByte ~= originaldumped:sub(offset, offset) then
		local finaloffset = offset - lastoffset
		lastoffset = offset
		local tableindex = #patchtable + 1
		patchtable[tableindex] = {finaloffset, newByte}
		patchoffsetsegments[tableindex] = finaloffset
		patchvaluesegments[tableindex] = string.byte(newByte)
	end
end
 
-- They will be concat'd into string form, creating two "tables" to be written to the patch file.
-- Concat the offset and value tables into two strings.
patchoffsettableconcat = table.concat(patchoffsetsegments, ",")
patchvaluetableconcat = table.concat(patchvaluesegments, ",")

-- Concat all strings to create the final string to write to the patch file
local patchstring = "local len = " .. tostring(#newdumped) .. "\n"
patchstring = patchstring .. "local offsets = {\n    "
patchstring = patchstring .. patchoffsettableconcat .. "\n}\n"

patchstring = patchstring .. "local values = {\n    " .. patchvaluetableconcat .. "\n}\n"

patchstring = patchstring .. "\nreturn len, offsets, values"


local patchfile = io.open(outpath, "w")
patchfile:write(patchstring)
patchfile:close()

return patchtable