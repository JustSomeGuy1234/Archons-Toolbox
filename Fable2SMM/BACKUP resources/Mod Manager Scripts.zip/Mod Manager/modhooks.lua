-- Still partly placeholder code, needs adapting


HooksEnum = {
	OnSaveLoad = 1,
	OnEnterArea = 2,
	OnHeroHit = 3,
}
Hooks = {
	[HooksEnum["OnSaveLoad"]] = {

	},
	[HooksEnum["OnEnterArea"]] = {
		--[[
		Cur = {ID = "SomeID", func, tab}
		--]]
	},
	[HooksEnum["OnHeroHit"]] = {
		--[[
		--OnHeroHit
		Cur = {ID = "AnotherID", func, tab, next},
		() = {ID = "SomeID", func, tab, prev, next}, -- Not actually in the table, but in next and prev of prev and next entry
		End = {ID = "AndAnotha", func, tab, prev}
			--]]
	}
}
Hooks.MessageIDs = {}

Hooks[HooksEnum["OnSaveLoad"]].CheckCondition = function()
	
end
Hooks[HooksEnum["OnEnterArea"]].CheckCondition = function()
	local is_posted, message = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_LEVEL_LOADED, Hooks.MessageIDs.LastMessageID_LevelLoaded)
	if is_posted then
		Hooks.MessageIDs.LastMessageID_LevelLoaded = message:GetID()
		return true
	else
		return false
	end
end
Hooks[HooksEnum["OnHeroHit"]].CheckCondition = function()
	local is_posted, message = MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_HIT, QuestManager.HeroEntity, Hooks.MessageIDs.LastMessageID_HeroHit)
	if is_posted then
		Hooks.MessageIDs.LastMessageID_HeroHit = message:GetID()
		return true
	end
	return false
end

function UpdateHooks()
	for i=1,#Hooks do
		local hooktab = Hooks[i]
		if hooktab.Cur and hooktab.CheckCondition() then
			TriggerHook(hooktab)
		end
	end
end
function TriggerHook(hooktable)
	if not hooktable then return false end
	local last_success, last_reason
	local hookentry = hooktable.Cur
	while hookentry do
		last_success, last_reason = pcall(hookentry.func, hookentry.tab)
		if not last_success then
			Debug.Error(last_reason)
		end
		hookentry = hookentry.next
	end
	return true
end
function OnSaveLoad()
	TriggerHook(Hooks[HooksEnum["OnSaveLoad"]])
end

function AddHook(hook, id, thefunc, tab)
	local hooktab = Hooks[HooksEnum[hook]]
	local last_end = hooktab.End
	hooktab.End = {
		id = id,
		func = thefunc,
		tab = tab,
		prev = last_end
	}
	if last_end then
		last_end.next = hooktab.End
	end
	if hooktab.Cur == nil then
		hooktab.Cur = hooktab.End
	end
end
function RemoveHook(hook, id)
	local hooktab = Hooks[HooksEnum[hook]]
	local l = hooktab.Cur
	while l do
		if l.id == id then
			if l.prev then
				l.prev.next = l.next
			end
			if l.next then
				l.next.prev = l.prev
			end
			if hooktab.Cur == l then
				hooktab.Cur = l.next
			end
			if hooktab.End == l then
				hooktab.End = l.prev
			end
		end
		l = l.next
	end
end

--[[
	-- Testing
	area1func = function()
		print("area1 hook called")
	end

	hit1func = function()
		print("hit1 hit hook called")
	end
	hit2func = function()
		print("middle hit hook called")
	end
	hit3func = function()
		print("hit3 hit hook called")
	end

	AddHook("OnEnterArea", "SomeID", area1func)

	AddHook("OnHeroHit", "AnotherID", hit1func)
	AddHook("OnHeroHit", "SomeID", hit2func)
	AddHook("OnHeroHit", "AndAnotha", hit3func)
--]]