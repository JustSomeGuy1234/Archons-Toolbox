﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Fable2SMM
{
    public class DebugListener : TraceListener
    {
        public static string ListenerLog { get => _listenerLog; set { _listenerLog = value; ListenerLogChanged?.Invoke(null, EventArgs.Empty); } }
        private static string _listenerLog = "";
        public static event EventHandler ListenerLogChanged;



        public override void Write(string message)
        {
            ListenerLog += message;
        }
        public override void Write(object o)
        {
            Write((o ?? "null").ToString());
        }
        public override void WriteLine(string message)
        {
            Write("\n" + (message ?? "null") + "\n");
        }
        public override void WriteLine(object o)
        {
            if (o == null)
                WriteLine("null");
            else
                WriteLine(o.ToString());
        }
    }
}
