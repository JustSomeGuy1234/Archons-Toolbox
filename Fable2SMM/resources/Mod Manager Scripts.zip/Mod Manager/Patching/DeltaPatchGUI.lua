output(loadfile("GAME:\\data\\scripts\\quests\\qc010_childhood.lua"))

local patchfolder = "GAME:\\data\\scripts\\Mod Manager\\Patching\\"

-- Load patch generator and patch table.
local generator, genErr = loadfile(patchfolder .. "DeltaPatchGenerator.lua")
local patchertype = type(generator)
if patchertype ~= "function" then
	output("Error: patcher function failed to compile! patching will not be available (yet):\nfunction type: " .. tostring(patchertype) .. "\n" .. tostring(genErr or ""))
	return false
end

local patchlistfunc, listErr = loadfile(patchfolder .. "PatchGenList.lua")
local patchlisttype = type(patchlistfunc)
if patchlisttype ~= "function" then
	output("Error: patch list failed to compile! patching will not be available (yet):\nfunction type: " .. tostring(patchlisttype) .. "\n" .. tostring(listErr or ""))
	return false
end

local PatchList = patchlistfunc()

for k,v in pairs(PatchList) do
	local _file, error_message, error_code = io.open(v.PatchPath, "r")
	local exists = error_code == nil or error_code and error_code ~= 2
	if type(_file) == "userdata" then _file:close() end

	if not exists or v.Overwrite then
		output("generating patch for " .. v.Source)
		generator(v.Source, v.Target, v.PatchPath)
	end
end