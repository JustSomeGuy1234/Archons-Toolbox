output("Calling our external GUI code!")


if GUI then
  output("There's a g_Menu here")
  local old_update = GUI.UpdateInput
  local framecount = 0
  function GUI.UpdateInput(...)
    old_update(...)
    framecount = framecount + 1
    if framecount >= 60 then
      print("60 frames!")
      framecount = 0
    end
    if GUI.Input.PushingUpHeld then output("g_HUD = " .. tostring(g_HUD or "nil")) end
  end
else
  output("There's no g_Menu yet")
end

if g_HUD then
  output("There's a g_HUD now!")
else
  output("There's no g_HUD yet")
end

-- Main Menu GUI: io.write 82BD90D8
-- Main Menu GUI: io.read 82BD80F0

local patchprocess, err = loadfile("GAME:/data/scripts/Mod Manager/Patching/DeltaPatchGUI.lua")
if err then
  output("Failed to compile DeltaPatchGUI")
else
  local patchprocessworked
  patchprocessworked, err = pcall(patchprocess)
  if not patchprocessworked then
    output("Failed to run DeltaPatchGUI:\n" .. tostring(err))
  end
  output("Patching Worked: " .. tostring(patchprocessworked) .. "\nPatched function/err: " .. tostring(err))
end


local app = loadfile("GAME:/data/scripts/Mod Manager/Patching/DeltaPatchApplicator.lua")

-- PrintTable(GUI)
