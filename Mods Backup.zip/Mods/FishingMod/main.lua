
-- Bait needs an item, a custom name to be shown outside of nametag scenarios, an effectiveness (25% less wait time per level, decimals work too, and lvl to use item at)
BaitEnum = {{Name = "No Bait", CustomName = "No Bait Selected", Item = "None", Effectiveness = 0, MinLevel = 0}}
function NewBait(item, custom_name, effectiveness, min_level)
	local new_bait = {}
	
	local record = GDB.GetRecord(item)
	if record:IsNull() then GUI.DisplayMessageBox("bait item " .. item .. "had no record") return end

	record = record:GetRecord("InventoryItemComponent")
	if record:IsNull() then GUI.DisplayMessageBox("bait item " .. item .. "had no item component") return end

	local item_name = record:GetString("NameTag")
	if item_name == "" then GUI.DisplayMessageBox("bait item " .. item .. "has no name tag") return end

	new_bait.Name = item_name
	new_bait.Item = item
	new_bait.Effectiveness = effectiveness
	new_bait.MinLevel = min_level
	new_bait.CustomName = custom_name or "missing name"
	return new_bait
end
BaitEnum[#BaitEnum + 1] = NewBait("ObjectInventoryFoodAndDrinkFish_3", "Westcliff Cod", 2, 2)
BaitEnum[#BaitEnum + 1] = NewBait("ObjectInventoryFoodAndDrinkFish_5", "Magnificent Tuna", 1, 1)

do
	local auxscript = loadfile("scripts/Mods/FishingMod/auxiliary.lua")
	setfenv(auxscript, getfenv(1))
	LootTables, Upgrades, GetMainMenuEntries, GetUpgradeMenuEntries = auxscript()
end

Debugging = false
DebugMessage = "No Fishing Message"
low_red, low_green = 200, 0
InFishingSetupMode = false
CurrentReward = "ObjectInventoryFoodAndDrinkFish_1"
Catching = false
BaseMeterWidth = 20
SelectedBait = 1
FractionBaitShouldRemove = 2
MinWaitTime = 10
MaxWaitTime = 20
MinStartingTime = 5
MaxStartingTime = 10
BaitChoiceTime = 4.5
CurrentXP = 0

function Draw3DText(...)
	if Debugging then
		Debug.Draw3DText(...)
	end
end

function ModUpdate()
	fish_update = coroutine.create(FishUpdate)
	setup_update = coroutine.create(FishingSetupUpdate)
	local text_pos
	while not ShouldDie do
		coroutine.yield()

		FishingSetupWorked, FishingSetupWhyNot = coroutine.resume(setup_update)
		assert(FishingSetupWorked, FishingSetupWhyNot)

		MyFishWorked, FishWhyNot = coroutine.resume(fish_update)
		assert(MyFishWorked, FishWhyNot)

		if Catching then
			text_pos = FishingPos
		else
			text_pos = QuestManager.HeroEntity:GetPosition()
		end
		Draw3DText(text_pos, DebugMessage, 1, {DrawInFrontOfScene = true})
	end
	Terminate()
	coroutine.yield()
end

function EnterFishingSetupMode()
	InFishingSetupMode = true
end
function ExitFishingSetupMode()
	InFishingSetupMode = false
end

function FishingSetupUpdate()
	while true do
		if InFishingSetupMode then
			GUI.TurnOnExpressionMeter()
			GUI.StartExpressionMeterPip()
			while GUI.IsExpressionMeterActive() do
				coroutine.yield()
			end

			if GUI.IsExpressionMeterCanceled() then
				InFishingSetupMode = false
			else
				InFishingSetupMode = false
				StartFishing()
				InFishingSetupMode = true
			end
		end
		coroutine.yield()
	end
end

function SpireZap()
	local drummy = Debug.CreateEntityByHero("ObjectChickenDrumstick")
	local hero = QuestManager.HeroEntity
	ScriptFunction.Ghost(drummy, 0)
	drummy:SetPosition(FishingPos)
	ElectricArcManager.CreateNamedEntityDummyEndPointsArc("FishingZap", drummy, hero, "Character.Focal.Mouth", "Character.Focal.Mouth", "fxspl_lightning_stream_01")
	Hittable.Hit(hero, {Damage = 100, Knockdown = true, Direction = Physics.GetFacingVector(hero)*-1})
	ScriptFunction.WaitForTimeInSeconds(.500)
	ElectricArcManager.DestroyAllArcsByRefname("FishingZap")
	drummy:Destroy()
	ScriptFunction.WaitForTimeInSeconds(2.5)
end
function IsWaterDeepEnough()
	local targetpos = QuestManager.HeroEntity:GetPosition() + Physics.GetFacingVector(QuestManager.HeroEntity) * 4
	FishingPos = CVector3(targetpos:GetX(), targetpos:GetY(), GetLandscapeHeightAt(targetpos) + GetWaterDepthAt(targetpos))
	return GetWaterDepthAt(FishingPos) > .25
end

function StartFishing()
	if not IsWaterDeepEnough() then
		GUI.DisplayMessageBox("Water not deep enough to fish.")
		ScriptFunction.WaitForTimeInSeconds(.5)
		return
	end
	local world, level = GetLevelLoaded()
	if level == "tatteredspire" then 
		SpireZap()
		return
	end

	local finished = false
	local meterpos = 10
	local direction = 1.5
	local speed_modifier = 1
	local tug_time = 4
	local tug_timer = QuestManager.NewTimer(tug_time)
	local tugging = false
	local hurt_amount = 20
	local left_bound = 12
	local right_bound = 35
	local sway_counter = 0
	local function get_starting_boundsposdir(side)
		local rb, lb, pos, dir
		if side == "left" then
			-- Left start
			rb = 49 - (BaseMeterWidth / 2)
			lb = 0 + (BaseMeterWidth / 2)
			pos = 1 + (BaseMeterWidth / 2)
			dir = 1
		else
			rb = 100 - (BaseMeterWidth / 2)
			lb = 51 + (BaseMeterWidth / 2)
			pos = 99 - (BaseMeterWidth / 2)
			dir = -1
		end
		return lb, rb, pos, dir
	end
	Player.StartInteractionMode(QuestManager.HeroEntity)
	GUI.SetGUIText("ShardHealth", "Fish")
	-- GUI.FadeElementIn("ShardHealth")
	GUI.SetMeterPercentOverTime("ShardHealth", fish_health, 1)

	while not finished do
		-- (Wait for) new fish main loop.
		local spot_to_hero_diff = FishingPos - QuestManager.HeroEntity:GetPosition()
		local spot_to_hero_diff_norm = spot_to_hero_diff
		spot_to_hero_diff_norm:Normalise()
		QuestThreadBase:SetFixedCamera({
			fov = 85,
			blend_in_seconds = 2,
			target_position = FishingPos,
			source_position = FishingPos + CVector3(0,0,3) - spot_to_hero_diff_norm*2,
			pan_angle = .2
		})
		GUI.TurnOffExpressionMeter()
		coroutine.yield()
		GUI.TurnOnExpressionMeter()
		GUI.StartExpressionMeterPip(150, 0, true)

		-- Start timer, bait select for 3 secs, then remove time from timer based on selected bait
		local fish_timer = QuestManager.NewTimer(math.random(MinWaitTime, MaxWaitTime))
		local bait_cancelled = false
		local lurer_level = Upgrades.Lurer.Level
		local chosen_bait = BaitEnum[SelectedBait]
		if lurer_level > 0 then
			GUI.FadeElementIn("ShardHealth")
			GUI.SetGUIText("ShardHealth", chosen_bait.Name)
			local fish_timer_timestamp = Timing.GetWorldFrame()
			local bait_choice_timer = QuestManager.NewTimer(BaitChoiceTime)
			while bait_choice_timer:GetTime() ~= 0 do
				if not HeroHasAnyBait() then
					GUI.AddWorldIconWithOffset("BaitAmount", QuestManager.HeroEntity, FishingPos - QuestManager.HeroEntity:GetPosition() - CVector3(0,0,1), 
						"You Have No Bait", EWorldIconType.WI_TEXT_ONLY)
					break
				end
				if GUI.IsExpressionMeterActive() then
					-- wait
				elseif GUI.IsExpressionMeterCanceled() then
					finished = true
					bait_cancelled = true
					break
				else
					CycleBait()
					chosen_bait = BaitEnum[SelectedBait]
					if SelectedBait ~= 1 then
						GUI.RemoveWorldIcon("BaitAmount", QuestManager.HeroEntity)
						GUI.AddWorldIconWithOffset("BaitAmount", QuestManager.HeroEntity, spot_to_hero_diff, 
							chosen_bait.CustomName .. ": " .. tostring(Inventory.GetNumberOfItemsOfType(QuestManager.HeroEntity,chosen_bait.Item)), EWorldIconType.WI_TEXT_ONLY)
					end
					GUI.SetGUIText("ShardHealth", BaitEnum[SelectedBait].Name)
					GUI.TurnOnExpressionMeter()
					GUI.StartExpressionMeterPip(150, 0, true)
					GUI.TurnOnExpressionDynamicFill(1, 2, 50, 0.00001)
				end
				GUI.SetMeterPercentOverTime("ShardHealth", bait_choice_timer:GetTime() / BaitChoiceTime * 100 , 40)
				coroutine.yield()
			end
			GUI.FadeElementOutSlow("ShardHealth")
		else SelectedBait = 1 end
		if bait_cancelled then
			break
		end
		if Inventory.GetNumberOfItemsOfType(QuestManager.HeroEntity, chosen_bait.Item) <= 0 then
			SelectedBait = 1; chosen_bait = BaitEnum[1]
		end
		local using_bait = SelectedBait ~= 1
		local total_bait_effect = 1
		if using_bait then
			total_bait_effect = chosen_bait.Effectiveness
		end
		-- Remove bait from the player before fishing. It is re-added later if cancelled, or due to the lurer lvl 3 perk if caught.
		if using_bait then
			local old_time = fish_timer:GetTime()
			local new_time = old_time - total_bait_effect * old_time / 4 -- 25% of time removed per bait effectiveness
			fish_timer:SetTime(new_time)
			Inventory.RemoveItemOfType(QuestManager.HeroEntity, chosen_bait.Item)
			--GUI.DisplayMessageBox(tostring(old_time) .. " to " .. tostring(new_time))
		end

		-- Wait for fish loop
		GUI.StartExpressionMeterPip(150, 0, true)
		GUI.TurnOnExpressionDynamicFill(1, 2, 50, 0.00001)
		while fish_timer:GetTime() ~= 0 do
			Draw3DText(FishingPos + Physics.GetFacingVector(QuestManager.HeroEntity), tostring(fish_timer:GetTime()), 1, {DrawInFrontOfScene = true})
			if GUI.IsExpressionMeterActive() then
				-- nothing happening
			elseif GUI.IsExpressionMeterCanceled() then
				Inventory.AddItemOfType(QuestManager.HeroEntity, chosen_bait.Item)
				finished = true
				break
			else
				GUI.StartExpressionMeterPip(150, 0, true)
				GUI.TurnOnExpressionDynamicFill(1, 2, 50, 0.00001)
			end
			coroutine.yield()
		end
		if finished then
			break
		end
		GUI.TurnOffExpressionMeter()
		coroutine.yield()

		-- Catching fish start, & main loop
		CurrentReward = GetLootForArea(level)
		if not CurrentReward then GUI.DisplayMessageBox("Error: Failed to get a reward") return end
		local fishmatch = string.match(CurrentReward, "Fish_(%d)$")
		local reward_record = GDB.GetRecord(CurrentReward)
		if not GDB.RecordExists(CurrentReward) and not GDB.RecordExistsInGlobalDatabase(CurrentReward) then
			GUI.DisplayMessageBox("Error: Failed to get item: " .. tostring(CurrentReward or "no reward"))
			return
		end

		local difficulty
		if level == "wraithmarsh" then
			difficulty = 5
		elseif fishmatch then
			difficulty = tonumber(fishmatch)
		else
			local price = reward_record:GetRecord("ShopItemComponent"):GetS32("BasePrice")
			if price < 50 then
				difficulty = 1
			elseif price < 100 then
				difficulty = 2
			elseif price < 150 then
				difficulty = 3
			elseif price < 200 then
				difficulty = 4
			else
				difficulty = 5
			end
		end
		local fish_health = 100 + difficulty * 10
		local max_health = fish_health

		local fish_caught = false
		local extralifeused = false
		low_red, low_green = 200, 0
		tugging = false
		Catching = true

		while not fish_caught and not finished do
			-- Line reached when new fish or second life
			StartMeter()
			speed_modifier = difficulty * .5

			local start_side
			if math.random(1,2) == 1 then
				start_side = "left"
			else 
				start_side = "right"
			end
			left_bound, right_bound, meterpos, direction = get_starting_boundsposdir(start_side)

			-- Disorientation makes fish cross at start
			local disorientation_level = Upgrades.Disorientation.Level
			if disorientation_level > 0 and math.random(1, 6 - disorientation_level) == 1 then
				local on_left = meterpos < 50
				local opposite_side
				if on_left then
					opposite_side = "right"
				else
					opposite_side = "left"
				end
				left_bound, right_bound = get_starting_boundsposdir(opposite_side)
				low_green, low_red = 200, 0
				GUI.SetLowFillColour(low_red, low_green, 0)
				if GetRandomNumber(3) >= 4 - Upgrades.Attentive.Level then
					Player.AddRumbleFromTable(QuestManager.HeroEntity, {
						ID = ERumbleTypes.RUMBLE_TYPE_SCRIPTED_RUMBLE,
						MaxLevel = .6,
						Smoothness = 0,
						AttackTime = 0,
						DecayTime = 0,
						Duration = 0.1,
						LeaveOpen = false
					})
				end
			end

			local bottle_strength = 0
			while GUI.IsExpressionMeterActive() do
				-- Fishing mode update
				-- If tugging, speed up. Move meter pos. If at either edge, swap direction. If hitting outer edge, have chance to cross.
				local speed = direction * (tugging and 1.5 or 1)
				local move_dist = (speed + (speed * speed_modifier)) * (1 - bottle_strength)
				meterpos = meterpos + move_dist

				if (meterpos >= right_bound and direction > 0) or (meterpos <= left_bound and direction < 0) then
					direction = -direction

					local on_left = meterpos < 50
					if (on_left and direction > 0) or (not on_left and direction < 0) then -- Meter hit the outer edge and is now heading inwards (not necessarily crossing).
						-- Chance to cross over
						sway_counter = sway_counter + 1
						if sway_counter > math.random(1, difficulty) then
							tugging = true
							low_green, low_red = 200, 0
							GUI.SetLowFillColour(low_red, low_green, 0)
							sway_counter = 0
							local opposite_side
							if on_left then
								opposite_side = "right"
							else
								opposite_side = "left"
							end
							left_bound, right_bound = get_starting_boundsposdir(opposite_side)
							-- Attentive
							if Upgrades.Attentive.Level > 0 then
								Player.AddRumbleFromTable(QuestManager.HeroEntity, {
									ID = ERumbleTypes.RUMBLE_TYPE_SCRIPTED_RUMBLE,
									MaxLevel = .6,
									Smoothness = 0,
									AttackTime = 0,
									DecayTime = 0,
									Duration = 0.1,
									LeaveOpen = false
								})
							end
						else
							tugging = false
							low_green, low_red = 0, 200
							GUI.SetLowFillColour(low_red, low_green, 0)
						end
					end
				end
				GUI.TurnOnExpressionDynamicFill(BaseMeterWidth, BaseMeterWidth + 1, meterpos, 0.001)

				if Upgrades.Sedation.Level > 0 and HasPressedX() then
					local drink_entry = MCM.OpenMenu("Throw a Drink", GetAvailableAlcoholMenuEntries, true)
					if drink_entry then
						local drink = drink_entry.Args
						bottle_strength = GDB.GetRecord(drink):GetRecord("InventoryItemComponent"):GetS32("Rating") / 10
					end
				end
				local cam = CameraManager.GetCurrentCamera().Camera
				Draw3DText(cam:GetPosition() + Physics.GetFacingVector(cam) + Camera.GetUpVector(cam) / 2, "Fish speed: " .. tostring(move_dist), 1, {DrawInFrontOfScene = true})

				GUI.SetMeterPercentOverTime("ShardHealth", (fish_health / max_health) * 100, 500)

				coroutine.yield()
			end

			-- Meter inactive. Player either hit or cancelled, else missed
			if GUI.IsExpressionHitTarget() then
				fish_health = 0
			elseif GUI.IsExpressionMeterCanceled() then
				Inventory.AddItemOfType(QuestManager.HeroEntity, chosen_bait.Item)
				finished = true
				GUI.TurnOffExpressionMeter()
			else
				if not extralifeused and math.random(1, 5) <= Upgrades.ReinforcedLine.Level then
					extralifeused = true
					low_red, low_green = 200, 0
				else
					break
				end
			end

			-- Fish caught
			if fish_health <= 0 then
				fish_caught = true
				fish_health = 100
				Sound.PlayEvent(QuestManager.HeroEntity, "SE_SWIM_RESURFACE", "")
				Debug.CreateEntityAtEntitysPosition("FX_Water_DiveSplash_NoSound", "fisheffect", FishEnt)
				
				-- Give Reward
				local should_stall = Inventory.GetNumberOfItemsOfType(QuestManager.HeroEntity, CurrentReward) == 0
				local item = Inventory.AddItemOfType(QuestManager.HeroEntity, CurrentReward)
				GUI.DisplayReceivedItem(item)
				-- Professional upgrade here
				local prof_level = Upgrades.Professional.Level
				if prof_level >= 1 then
					DebugMessage = "About to sell"
					GUI.TurnOffExpressionMeter()
					GUI.FadeElementOutSlow("ShardHealth")
					Catching = false
					if should_stall then
						ScriptFunction.WaitForTimeInSeconds(.6) -- Sigh. The game doesn't remove items from inv quick enough when eaten, so we have to wait a sec.
					end
					PromptSellItem(CurrentReward, reward_record) -- Blocking
					GUI.TurnOnExpressionMeter()
					GUI.FadeElementIn("ShardHealth")
				end
				CurrentXP = CurrentXP + 10 + (difficulty * 2)
				GUI.SetMeterPercentOverTime("ShardHealth", 0, 500)
				-- Remove bait
				if using_bait then
					if lurer_level >= 3 and math.random(1,2) == 2 then
						-- Bait is saved, maybe add a lil message here.
						Inventory.AddItemOfType(QuestManager.HeroEntity, chosen_bait.Item)
					else
						if Inventory.GetNumberOfItemsOfType(QuestManager.HeroEntity, BaitEnum[SelectedBait].Item) <= 0 then
							SelectedBait = 1
						end
					end
				end
			end
			coroutine.yield()
		end
		Catching = false
	end
	-- Player pressed B and fishing has ended
	QuestThreadBase:SetDefaultCamera()
	GUI.FadeElementOutSlow("ShardHealth")
	Player.StopInteractionMode(QuestManager.HeroEntity)
	GUI.TurnOffExpressionMeter()
end
function StartMeter()
	GUI.TurnOnExpressionMeter()
	GUI.SetLowFillColour(low_red, low_green, 0)
	GUI.SetMedFillColour(200, 200, 0)
	GUI.SetHighFillColour(200, 0, 0)
	GUI.SetFillColourPercentages(25, 35) -- Low until 50, med until 99, high after 99.
	GUI.TurnOnExpressionDynamicFill(BaseMeterWidth, BaseMeterWidth + 1, 50, 0.00001) -- Start fill amount, cap, position, fill/drain speed. If fill amount is less than cap and fill speed is positive, it gets bigger.
	GUI.StartExpressionMeterPip(50, 0, true)
end
function CycleBait()
	-- Iterate through baits starting from SelectedBait to select the next one the hero owns.
	local foundavailablebait = false
	while not (SelectedBait >= #BaitEnum) do
		SelectedBait = SelectedBait + 1
		local this_bait = BaitEnum[SelectedBait]
		if Inventory.GetNumberOfItemsOfType(QuestManager.HeroEntity, this_bait.Item) > 0 and this_bait.MinLevel <= Upgrades.Lurer.Level then
			foundavailablebait = true
			break
		end
	end
	if not foundavailablebait then
		SelectedBait = 1
	end
end
function HeroHasAnyBait()
	local lurer_level = Upgrades.Lurer.Level
	for k,v in pairs(BaitEnum) do
		if v ~= BaitEnum[1] and lurer_level >= v.MinLevel then
			if Inventory.GetNumberOfItemsOfType(QuestManager.HeroEntity, v.Item) > 0 then
				return true
			end
		end
	end
	return false
end

function ThrowDrink(item_name, ent)
	ent = ent or QuestManager.HeroEntity
	if Inventory.GetNumberOfItemsOfType(ent, item_name) > 0 then
		local mybottle = Debug.CreateEntityByHero(item_name)
		local cam_pos = CameraManager.GetCurrentCamera().Camera:GetPosition()

		-- We can't set angular velocity and I dont want the bottle to just drop into the water, so here's a really stupid workaround
		-- Thankfully a bottle's hitbox is a sphere so it will roll (the sphere is at the base so it pivots around the bottom which looks strange but whatever).
		mybottle:SetPosition(QuestManager.HeroEntity:GetPosition() + CVector3(0,0,.1))
		Physics.SetVelocity(mybottle, FishingPos - cam_pos)
		ScriptFunction.WaitForTimeInSeconds(.3)
		mybottle:SetPosition(CameraManager.GetCurrentCamera().Camera:GetPosition())
		local timer = QuestManager.NewTimer(1)
		while timer:GetTime() ~= 0 do
			coroutine.yield()
			Draw3DText(mybottle:GetPosition(), "Bottle here!", 2, {DrawInFrontOfScene = true})
		end
		mybottle:Destroy()
		Inventory.RemoveItemOfType(ent, item_name, 1)
	else
		GUI.DisplayMessageBox(tostring("not enough of item " .. tostring(item_name or "noname") .. " to throw?"))
	end
end

-- Controls the fish visuals
function FishUpdate()
	local position_swap_timer = QuestManager.NewTimer(math.random(1,3))
	while not ShouldDie do
		if Catching then
			DestroyOldFish()

			-- Get Initial Fish Swimming Zone Centre
			if not FishingPos then 
				GUI.DisplayMessageBox("Error: Fishing pos almost didn't exist!")
				coroutine.yield()
				FishingPos = QuestManager.HeroEntity:GetPosition() + Physics.GetFacingVector(QuestManager.HeroEntity) * 4
			end
			FishEnt = Debug.CreateEntityAt(CurrentReward, "fishingfish", FishingPos)
			local TargetPos = FishingPos
			FishEnt:SetPosition(TargetPos)

			
			while Catching do
				if not FishEnt or not FishEnt:IsAlive() then
					GUI.DisplayMessageBox(tostring("Fish died while being fished. sus."))
					coroutine.yield()
					FishEnt = Debug.CreateEntityAt(CurrentReward, "fishingfish", FishingPos)
				end

				if position_swap_timer:GetTime() == 0 then
					TargetPos = FishingPos + CVector3(math.random(-2,2), math.random(-2,2), GetRandomFloat(1)*.6)
					Debug.CreateEntityAtEntitysPosition("FX_Water_Out_Splash", "fisheffect", FishEnt)
					position_swap_timer:SetTime(1)
				end

				local FishPos = FishEnt:GetPosition()
				local FinalVel = TargetPos - FishPos
				Physics.SetFacingVector(FishEnt, FinalVel)
				Physics.SetVelocity(FishEnt, FinalVel)

				Draw3DText(FishPos, "Traveling to: " .. tostring(TargetPos) .. 
										"\nfrom here: " .. tostring(FishPos) .. 
										"\nAt speed: " .. tostring(FinalVel), 
										1, {DrawInFrontOfScene = true})
				
				coroutine.yield()
			end
			DestroyOldFish()
		elseif InFishingSetupMode then
			if not IsWaterDeepEnough() then
				GUI.SetLowFillColour(255,0,0)
			else
				GUI.SetLowFillColour(0,255,0)
			end
			GUI.TurnOnExpressionDynamicFill(25, 26, 50, 0.00001)
			--[[DestroyOldFish()
			FishEnt = Debug.CreateEntityAt("ObjectInventoryFoodAndDrinkFish_1", "fishingfish", QuestManager.HeroEntity:GetPosition())
			Physics.SetFacingVector(FishEnt, Physics.GetFacingVector(QuestManager.HeroEntity))

			while InFishingSetupMode and not Catching do
				FishEnt:SetPosition(QuestManager.HeroEntity:GetPosition() + CVector3(0,0,2.5))
				if IsWaterDeepEnough() then
					ScriptFunction.Ghost(FishEnt, .6, 0,255,0)
				else
					ScriptFunction.Ghost(FishEnt, .6, 255,0,0)
				end
				coroutine.yield()
			end
			DestroyOldFish()--]]
		else
			DestroyOldFish()
		end
		coroutine.yield()
	end
end
function DestroyOldFish(fish)
	fish = fish or FishEnt
	if fish and fish:IsAlive() then
		fish:Destroy()
	end
end

function BuyUpgrade(upgrade)
	local cost = GetXPRequiredForUpgrade(upgrade)
	if CurrentXP < cost or upgrade.Level >= upgrade.MaxLevel then
		return
	end
	upgrade.Level = upgrade.Level + 1
	CurrentXP = CurrentXP - cost
end
function GetXPRequiredForUpgrade(upgrade)
	local cost = (upgrade.Level + 1) * 100
	cost = cost * (upgrade.PriceMultiplier or 1)
	return cost
end
function GetLootForArea(area)
	local from_loot_table = "fish table"
	local area_loot_table = LootTables[area] or LootTables.base
	local item_name, item_or_table = GetDropFromTable(area_loot_table, LootTables.base)
	if item_or_table.Table == true then
		item_name, item_or_table = GetDropFromTable(item_or_table, LootTables.base.Loot)
		from_loot_table = "loot table"
	end
	DebugMessage = "Returning " .. tostring(item_name or "nil") .. " as a reward from " .. tostring(from_loot_table or nil)
	return item_name
end
function GetDropFromTable(loot_table, base_table)
	-- Sum up all weights from both the loot_table and the base_table (if it's specified)
	local full_weight = 0
	local function SumUpAllWeight(some_table, priority_table)
		if not some_table then return end
		for k,v in pairs(some_table) do
			if priority_table and priority_table[k] then
				-- If the priority table has the same item then we don't want to process it twice. In most cases, the regional table takes priority over an items weight.
			elseif k ~= "Table" and k ~= "Weight" then -- loot tables contain their own weights and a bool to identify whether it's a table, so we skip them during this process.
				if k == "Loot" then
					full_weight = full_weight + GetLuckyHookWeight(v.Weight * 100) -- If loot table, apply luckyhook.
				else
					full_weight = full_weight + (v.Weight * 100)
				end
			end
		end
	end
	SumUpAllWeight(loot_table)
	SumUpAllWeight(base_table, loot_table)

	local item_num = math.random(full_weight)

	-- Stop when weight sum hits the random number. Go through the loot table then the base loot table.
	full_weight = 0
	local function GetItemFromTableWithLocalValues(some_table, priority_table)
		for k,v in pairs(some_table) do
			if priority_table and priority_table[k] then
				-- If the priority table has the same item then we don't want to process it twice. In most cases, the regional table should take priority over an items weight.
			elseif k ~= "Table" and k ~= "Weight" then
				if k == "Loot" then
					full_weight = full_weight + GetLuckyHookWeight(v.Weight * 100) -- If loot table, apply luckyhook.
				else
					full_weight = full_weight + v.Weight * 100
				end
				if full_weight >= item_num then
					return k,v
				end
			end
		end
	end
	local item_k, item_v = GetItemFromTableWithLocalValues(loot_table)
	if item_k then
		return item_k, item_v
	end
	return GetItemFromTableWithLocalValues(base_table, loot_table)
end
function GetLuckyHookWeight(weight) -- Simply multiplies weight by up to 2.
	return weight + weight / Upgrades.LuckyHook.MaxLevel * Upgrades.LuckyHook.Level
end
function PromptSellItem(item, item_record)
	if Inventory.GetNumberOfItemsOfType(QuestManager.HeroEntity, item) < 1 then
		DebugMessage = "No more " .. item .. "\nHero must have consumed item"
		return
	end
	local name_tag = item_record:GetRecord("InventoryItemComponent"):GetString("NameTag")
	local base_price = item_record:GetRecord("ShopItemComponent"):GetS32("BasePrice")
	local final_price = math.floor(base_price * (.80 + (.10 * (Upgrades.Professional.Level - 1))))
	GUI.DisplayInfoBoxParams({
	  ShowAButton = true,
	  ShowYButton = true,
	  IsHoldAButton = false,
	  DisplayBoxStyle = EDisplayBoxStyle.DBS_OLD_STYLE,
	  Name = "SellCaughtItem",
	  Title = "Sell Item",
	  HelpText = "Don't sell",
	  AcceptText = "Sell For: " .. tostring(final_price or "error: no price")
	}, (name_tag or item or "error: no item"))

	local is_posted, message_sell = false, nil
	while is_posted == false do
		DebugMessage = "Waiting for sell msg"
		is_posted, message_sell = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_INFOBOX, LastMessageID_ButtonBox)
	    if is_posted then
	      LastMessageID_ButtonBox = message_sell:GetID()
	      local extra_data = message_sell:GetExtraDataAsNumber()

	      if extra_data == 1 then
			DebugMessage = "Selling"
			Inventory.RemoveItemOfType(QuestManager.HeroEntity, item, 1)
			Money.Modify(QuestManager.HeroEntity, final_price)
	      elseif extra_data == 4 then
			-- do nothing
	      else
			GUI.DisplayMessageBox("unexpected extra_data from sell msg: " .. tostring(extra_data or "no extradata?"))
	      end
	    end
		coroutine.yield()
	end
	DebugMessage = "Exited sell msg loop"
	GUI.RemoveDisplayBox("SellCaughtItem")
end

function HasPressedX(timestamp, window, context)
	timestamp = timestamp or Timing.GetWorldFrame()
	window = window or 1
	context = context or getfenv(1)

	local is_x_pressed, message_pressed = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_GENERIC_X_BUTTON_PRESSED, context.LastMessageID_PressedXButton)
	return is_x_pressed and (timestamp and timestamp - message_pressed:GetTimeStamp() <= window)
end

function Terminate()
	ShouldDie = true
	Catching = false
	Player.StopInteractionMode(QuestManager.HeroEntity)
	QuestThreadBase:SetDefaultCamera()
	GUI.RemoveDisplayBox("SellCaughtItem")
	GUI.FadeElementOutSlow("ShardHealth")
	GUI.TurnOffExpressionMeter()
	if FishEnt then
		FishEnt:Destroy()
	end
end
function Disable()
	RemoveMCMEntries()
end
function Uninstall()
	Disable()
	return {XP = CurrentXP, Upgrades = Upgrades}
end

function GetMCMEntry()
	return MCM.NewActionEntry("Fishing Mod", true, MCM.OpenMenu, {"Fishing Mod", GetMainMenuEntries}), "FishingModEntries"
end

-- Updating
local passed = {...}
local args = passed[1]
if args then
	CurrentXP = (type(args.XP) == "number" and args.XP) or 0
	for id,upgrade in pairs(args.Upgrades or {}) do
		if Upgrades[id] then
			Upgrades[id].Level = math.min(upgrade.Level, Upgrades[id].MaxLevel)
			-- GUI.DisplayMessageBox("Restoring " .. tostring(id) .. "\nStored: " .. tostring(upgrade.Level) .. "\nMax: " .. tostring(Upgrades[id].MaxLevel))
		else
			GUI.DisplayMessageBox("Failed to restore levels for a no longer existant fishing skill :(\n" .. tostring(Upgrades[id].Name))
		end
	end
	-- GUI.DisplayMessageBox("Finished loading saved args\nSaved XP: " .. tostring(args.XP))
else
	GUI.DisplayMessageBox(tostring("no saved args"))
end
