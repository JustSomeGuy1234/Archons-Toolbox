--[[



--]]

GUI.DisplayMessageBox("Starting Mod Manager!")
local args = ...

local managertab = {}  
local managerfunc = loadfile("scripts/Mod Manager/runner.lua")
if type(managerfunc) ~= "function" then
	GUI.DisplayMessageBox("Mod Manager runner script didn't compile/get found!")
	return
end

setfenv(managerfunc, managertab)  
setmetatable(managertab,managertab)  
managertab.__index = _G  
managertab._G = _G  
local worked, error_message = pcall(managerfunc, args)
-- if true then return end
if not worked then
	GUI.DisplayMessageBox("Manager script errored while starting!\n\n" .. tostring(error_message))
	return
end
GeneralScriptManager.AddScript(managertab)

return managertab