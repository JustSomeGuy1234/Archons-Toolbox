-- Reminder: This script's fenv is set to its own table. To reset it, call CodeLoader.ResetCodeEnv().
local newChecksum = 0
local function CodeToRun()
	local DisplayAllKeys = CodeLoader.ModMisc.DisplayAllKeys
	local hero = QuestManager.HeroEntity
	Sound.PlayEvent(QuestManager.HeroEntity, "SE_HERO_PICKUP_ITEM", "")
	local function GetScriptFromGsmByName(name)
		local l = GeneralScriptManager.CurrentlyRunningScripts
		while l do
			local val = l.value
			if val.ScriptName == name then
				return val
			end
			l = l.next
		end
	end
	local manager = GetScriptFromGsmByName("ModManagerRunner")

	-- Health.Modify(hero, 1000, hero)
	--TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_DOG_PET)
	--Debug.SetTutorialsEnabled(false)
	-- Health.SetAsInvulnerable(GetPlayerHero(), false)
	--SoundTools.StopMainAtmos()
	-- Inventory.AddItemOfType(hero, "ObjectInventory_L_Super")
	-- Experience.Modify(hero, EExperienceType.EXPERIENCE_GENERAL, 10000000)
	-- PlayerAbility.SetAbilityRecord(QuestManager.HeroEntity, "PlayerAbilitiesOneButtonCombat")
	-- Player.SetMapScreenAsEnabled(QuestManager.HeroEntity, true)
	-- Player.SetInventoryScreenAsEnabled(QuestManager.HeroEntity, true)
	-- Player.SetExperienceSpendingAsEnabled(QuestManager.HeroEntity, true)
	-- Player.SetExperienceBarAsEnabled(QuestManager.HeroEntity, true)






-- DisplayAllKeys(Inventory)

-- Debug.EngineTest.SetMainSceneRenderTargetDimensions (lua)0x823B1EE0 (real)0x825da050
-- rbx+94 and rbx+9c points to (0x14252ADA4) (14252AD10 start of data structure)
-- Found at 14252AD7C 1280x720 floats
-- Debug.SetDebugMenuRequiresRightStickClick (lua)  822C9E18 (real) 823A6ED0
-- CreateEntityFromIDAt ; 825B9140



local cam = CameraManager.GetCurrentCamera()


		-- CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_DEFAULT)
		-- GUI.DisplayMessageBox(tostring())
		-- manager.GetModHandleWithName("FishingMod").value.Upgrades.Lurer.Level = 3

		-- DisplayAllKeys(manager.GetModHandleWithName("FirstPersonCamera").value)
		-- RangedCombatCamera.GetDesiredCameraPos = manager.GetModHandleWithName("FirstPersonCamera").value.GetOurCameraPosition
		-- GUI.DisplayMessageBox(tostring(manager.GetModHandleWithName("FirstPersonCamera").value.GetOurCameraPosition()))
		-- Inventory.AddItemOfType(hero, "ObjectInventoryFoodAndDrinkFish_3")

-- local a,b = pcall(SACCamera.FrameUpdate, SACCamera)
-- local a,b = pcall(cam.FrameUpdate, cam)
-- GUI.DisplayMessageBox(tostring(RangedCombatCamera.ZoomFOVOverride))
-- GUI.DisplayMessageBox(tostring(Targeting.GetZoomLevel(hero)))




if false then
	local saved, worked, t
	
	if manager then
		-- saved = manager:Terminate()
		manager:Terminate()
	end
	
	worked,t = pcall(loadfile("scripts/Mod Manager/startrunner.lua"), saved)
	if not worked then
		GUI.DisplayMessageBox(tostring(t))
	end
	--pcall(t.OnSaveLoad)
end

--[[ FISHING MOD TESTING ]]
--[[manager.GetModHandleWithName("FishingMod").VersionMinor = GetRandomNumber(10000000)
manager.ReadInstalledMods()--]]
--[[
fishing = manager.GetModHandleWithName("FishingMod").value
fishing.Upgrades.LuckyHook.Level = 5
fishing.Upgrades.Disorientation.Level = 1
fishing.Upgrades.Professional.Level = 5
fishing.Upgrades.Lurer.Level = 3
fishing.Upgrades.Attentive.Level = 5
fishing.CurrentXP = 3500
fishing.SampleLoot("bloodstone", 15000)
GUI.FadeElementOutSlow("Icon")
GUI.DisplayMessageBox("Icon")
--]]
-- Inventory.AddItemOfType(hero, "ObjectInventoryFoodAndDrinkFish_3")
-- Inventory.AddItemOfType(hero, "ObjectInventoryFoodAndDrinkAlcoholSpirits_5")




--[[ ENV THEMES ]]
-- EnvironmentTheme.SetOverrideBlending(false)
-- EnvironmentTheme.SetColourParameter("SUN_GLARE_SIZE", 0)
-- EnvironmentTheme.SetColourParameter("SUN_BEAMS_INTENSITY", 0)

--[[  EnvironmentTheme.SetColourParameter("WATER_NORMAL_MAP_SPEED0X", .5, 0, 0 )
  EnvironmentTheme.SetColourParameter("WATER_NORMAL_MAP_SPEED1X", .1, 0, 0 )
  EnvironmentTheme.SetColourParameter("WATER_NORMAL_MAP_SCALE0", 1, 0, 0 )
  EnvironmentTheme.SetColourParameter("WATER_NORMAL_MAP_SCALE1", .2, 0, 0 ) --]] 
--[[  EnvironmentTheme.SetColourParameter("WATER_NORMAL_MAP_SPEED0X", .1, 0, 0 )
  EnvironmentTheme.SetColourParameter("WATER_NORMAL_MAP_SPEED1X", .1, 0, 0 )
  EnvironmentTheme.SetColourParameter("WATER_NORMAL_MAP_SCALE0", .1, 0, 0 )
  EnvironmentTheme.SetColourParameter("WATER_NORMAL_MAP_SCALE1", .1, 0, 0 )--]]

-- [[ DEBUG MENU LOADING ]]
if false then
	local menufunc = loadfile("scripts/DebugMenuMod/MyDebugMenu.lua")
	local oldmenu = GetScriptFromGsmByName("DebugMenu")
	if oldmenu then
		oldmenu.ShouldDie = true
	end
	if type(menufunc) ~= "function" then
		GUI.DisplayMessageBox("Couldn't run Debug Menu script!")
		return
	elseif type(loadfile("scripts/DebugMenuMod/DebugMenuEntries.lua")) ~= "function" then
		GUI.DisplayMessageBox("Couldn't run entry definitions script!")
		return
	end
	local menutab = {}
	setfenv(menufunc, menutab)
	setmetatable(menutab,menutab)
	menutab.__index = _G
	menutab._G = _G
	menufunc()
	GeneralScriptManager.AddScript(menutab)
end

-- SE_FLIT_SWITCH_MOVE
-- SE_FLIT_SWITCH_CLOSE
-- SE_FLIT_SWITCH_OPEN


end


return CodeToRun, newChecksum