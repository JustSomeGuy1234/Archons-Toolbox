-- TODO: Add status effects. -- In Progress (vulnerability done, bind in progress)
-- 		 	Bind: Currently caging enemies inbetween 4 items. Might make em invisible and use that shield fx (luciens?), or the shadow tar fx. Also, look at physics for collision to prevent hero.
--					Issue though, if the hero moves away their ai collision is disabled. Maybe make it so their ai is disabled while the hero is far.
--			Stun: Combat.SetCanFight(ent, false) and Combat.SetCanFlee
--			Other incapacitation: Look at the navigation table.
--			Figure out how to apply an effect for a limited time without having the wisp hop. 
--				Or just have the wisp hop to the hero after applying an effect, then wait as a cooldown.


-- TODO: Have particles instead of whatever else to highlight the target. There's a really cool zapping animation called FX_Necromancer_Target
-- Candidate effects: FX_Necromancer_Target, FX_Shadow_Teleport (lingers), FX_Forest_Troll_Travel (good for stun), FX_Blast_Trail (good for targeting), FX_Spell_Fireball (good fire spell)
--					  FX_Clothes_Change (huge quick blue explosion. Maybe freeze?), FX_PotionEffect_Experience_Strength(also good target indicator), FX_PotionEffect_Experience_Skill, FX_PotionEffect_Experience_Will,
--					  FX_XP_Powerup_Effects, FX_Hero_Teleport (blue geyser), FX_Musicbox_Disappear (combo hit effect), FX_HeroCircle_Symbol_S and _Red_S (hero floor symbol, good ultimate), 
-- 					  FX_HeroCircle_Symbol and _Red(particle ring around hero symbol), FX_Wide_Light_Beam (beam in guild hall. Good heal maybe.) and FX_God_Ray (smaller) and FX_Highlight_Beam (even less offensive),
--					  FX_Hammer_Blessing (big shiny sparkles), FX_Lucien_Shockwave (Good for big force/push back), FX_Standard_Teleporter (swirly magic teleporter), 
--					  FX_Magic_Ship_Blast (straight up huge EXPLOSION) or FX_Wood_Explosion (same without sound) or FX_Explosion_Rock (slightly smaller with rock), 
--					  FX_HeroHill_Ranged_S and _Melee_ and _Magic_ and _Hero_ (like hero symbol but smaller and louder), FX_Goodguy_Teleporter (like teleporter but without ring)
--					  FX_HeroHill_Melee _Ranged _Melee _Magic (good for more aggressive targeting), FX_Musicbox_Base (Small gold glowy), FX_HeroHill_Sparkles (aoe bigger sparkles),
--					  FX_Lucien_Shield (sphere of fuzzy stuff, maybe good for bind/stun), FX_Lucien_Shield_Hit, FX_Blocking_Fire (wall of fire), FX_Banshee_Debris_Suck (windy blowing sucky)
--					  FX_Poison_Smoke (green gas)
--					  FX_Ritual_Statue_Water (if you want someone wet), FX_CullisGate_Stage_01 and 02 and 03 (could be very good for targeting)! FX_CullisGate_UpBlast (huge electric "cage"), 
-- 					  FX_Teleporter_Explosion (SMITED), FX_Shadow_Tar (bubbly floor stuff, discrete for targeting) 
--				      fxscr_ribbon_red (red lasery thing, good for drain)
--					  
-- TODO: Either persist between level loads or don't but respawn. Script seems good at not dying, just the wisp ent isn't.
-- TODO: Add menu for configs
-- TODO: Testing

-- I'm unfortunately 99% certain that stopping the wisp sound with the stop sound function works but it just starts again probably due to an animation/timer thing.
-- 		Figured it out! Just set the sound category's pitch to 0!

-- We can spawn the wisp visuals ourselves.
-- Funnily enough it's with ElectricArcManager.CreateNamedEntityDummyEndPointsArc("mywisp", GetPlayerHero(), GetPlayerHero(), "Character.FX.Particle.", "", "FXCRE_Hollowman_Wisp", false)

-- TODO: Work on the bind effect and effect update in general.
-- Currently for cooldown I just set target to hero, but this causes the wisp to try to effect the hero.
--		We should probably get rid of the swap timer and replace it with the cooldown timer or something
-- Fiddle with the cooldowns and enemy swapping. Cage should be removed when enemy dies, causing cooldown.
-- Maybe make an enemy that escapes the cage ragdoll hehe 

-- TODO Priority:
-- Implement Block.ClearBlocking(target). It seems to clear the target's block counter so you can endlessly hit em.
-- Should use it during the status effect update or something that is run every few hundred ms. Should it be applied for specific effects like bind, or all of em?

-- TODO: Combat fluidity
-- Combat.GetNumberOfSuccessiveHits
-- Combat.SetDamageMultiplier()
-- Combat.LaunchedCounterAttack()
-- Combat.IsChargingFlourishAttack()
-- Player.ReloadHeroCombatBalanceData()
-- SpellManager.IsCharging -- works
-- SpellManager.ResetEntityMagic -- works
-- SpellManager.ResetEntityMagicAffects
-- Debug.SetExperienceOrbGeneralXPMultiplier
-- Debug.SetFlourishAddedDamage

require"MultipageMenu"

if wispTab then
	wispTab:KillWisp()
end

wispTab = {}
wispTab.DebugText = "Default Debug Text"
wispTab.ShowDebugText = true
wispTab.ShouldDie = false
wispTab.MaxHeroDistance = 4 			-- Distance the wisp can fall behind the hero before hopping to them.
wispTab.MaxTargetDistance = 1.5			-- Distance wisp can be from target enemy before hopping to them.
wispTab.TargetHeightOffset = .4 		-- Height from entities feet the wisp will hop to.
wispTab.TargetSwapTime = 6 				-- How often the wisp will swap targets to keep things interesting.
wispTab.CombatSpeed = 1 				-- How fast the wisp moves during combat
wispTab.RoamingSpeed = .7 				-- How fast the wisp moves when following the hero
wispTab.InCombat = false				-- While it's something I'd rather keep in a local, it needs to be accessable outside of the AI update too. (could keep it local but have a func that gets it?)
wispTab.WispTarget = GetPlayerHero()	-- Once again something I'd like to keep in a local but it needs to be accessed by the vfx coroutine.
wispTab.WispEffects = {
					   [1] = {Name = "Vulnerability", Cooldown = 4, EffectTime = 5, VFX = ""},
					   [2] = {Name = "Bind", Cooldown = 4, EffectTime = 8, VFX = ""}
					  }
wispTab.EffectEnum = {VULNERABILITY = 1, BIND = 2}
wispTab.BindObjects = {}
wispTab.CurrentEffect = wispTab.EffectEnum.VULNERABILITY
function wispTab:NewWisp()
	self.Entity = Debug.CreateEntityByHero("HollowManWisp", "MyWisp")
	myWisp = self.Entity
	CombatRegister:SetHollowManWispMovement(self.Entity, true)
	CombatRegister:SetHollowManWispSpawn(self.Entity, false)
	Combat.SetCanFight(self.Entity, false)
	Combat.SetCanFlee(self.Entity, false)
	Combat.SetCanBeAttacked(self.Entity, false)
	Follow.SetAsLevelFollowing(self.Entity, true)
	Wisp.SetSpeed(myWisp, self.RoamingSpeed)

end
function wispTab:KillWisp()
	self.ShouldDie = true
	if self.Entity then
		self.Entity:Destroy()
	end
	if self.CurrentVFX then
		self.CurrentVFX:Destroy()
	end
	self:RemoveCage()
end
-- Update coroutine updates the other coroutines. I call this the manager coroutine
-- We currently have... 5 coroutines including the manager.
wispTab.aiworked = false
wispTab.aiwhynot = "AI coroutine hasn't been started yet"
wispTab.vfxworked = false
wispTab.vfxwhynot = "VFX coroutine hasn't been started yet"
wispTab.menuworked = false
wispTab.menuwhynot = "Menu coroutine hasn't been started yet"

-- The normal Update coroutine basically acts as a manager for the wisp AI and VFX coroutines.
-- This "manager" creates the wisp's entity and AI instance, and the VFX coroutine on the first tick.
-- Afterwards, it simply updates them until there's an error.
-- If an error occurs, it will display it and stop.
function wispTab:Update()
	self:NewWisp() 
	self.aiupdate = coroutine.create(self.AIUpdate)
	self.vfxupdate = coroutine.create(self.VFXUpdate)
	self.menuupdate = coroutine.create(self.MenuUpdate)
	while not self.ShouldDie do
		coroutine.yield()
		if self.ShowDebugText then
			Debug.Draw3DText(self.Entity:GetPosition() + CVector3(0,0,.5), self.DebugText, 1.2, {DrawInFrontOfScene = true})
		end
		self:CheckWisp()

		-- Mutes the wisp's whining
		Sound.SetPitchForSoundCategory(self.Entity, "", 0, 1)

		self.aiworked, self.aiwhynot = coroutine.resume(self.aiupdate, self)
		if not self.aiworked then
			GUI.DisplayMessageBox("Wisp errored! Reason:\n " .. tostring(self.aiwhynot))
			self.ShouldDie = true
		end

		self.vfxworked, self.vfxwhynot = coroutine.resume(self.vfxupdate, self)
		if not self.vfxworked then
			GUI.DisplayMessageBox("Wisp FX errored! Reason:\n " .. tostring(self.vfxwhynot))
			self.ShouldDie = true
		end

		self.menuworked, self.menuwhynot = coroutine.resume(self.menuupdate, self)
		if not self.menuworked then
			GUI.DisplayMessageBox("Wisp Menu errored! Reason:\n " .. tostring(self.menuwhynot))
			self.ShouldDie = true
		end
	end
	self:KillWisp()
	coroutine.yield()
end

function wispTab:CheckWisp()
	if not self.Entity or not self.Entity:IsAlive() then
		self:NewWisp()
	end
end
-- AI Update coroutine does the meaty stuff and is updated every tick by the above coroutine.
function wispTab:AIUpdate()
	while not self.ShouldDie do
		-- The beginning is only ever returned to when swapping between roaming and combat modes.
		ScriptFunction.WaitForTimeInSeconds(.25)
		self:CheckWisp()
		self.InCombat = self:AreEnemiesNear()
		if not self.InCombat and not self.ShouldDie then
		-- Roaming Mode
			Wisp.SetSpeed(myWisp, self.RoamingSpeed)
			local tooFar = not IsDistanceBetweenThingsUnder(self.Entity, QuestManager.HeroEntity, self.MaxHeroDistance)
			-- Roaming Loop
			while not self.InCombat do
				ScriptFunction.WaitForTimeInSeconds(.5)
				self:CheckWisp()
				tooFar = not IsDistanceBetweenThingsUnder(self.Entity, QuestManager.HeroEntity, self.MaxHeroDistance)
				if tooFar then
					Wisp.SetDestination(self.Entity, QuestManager.HeroEntity:GetPosition() + CVector3(0,0,3))
					-- While we're moving we don't want to change anything.
					while Wisp.IsMoving(self.Entity) do
						ScriptFunction.WaitForTimeInSeconds(.25)
						self.DebugText = "Roaming\nHopping to Hero"
					end
				end
				self.DebugText = "Roaming\nWaiting for Hero to move"
				self.InCombat = self:AreEnemiesNear()
			end
		elseif self.InCombat and not self.ShouldDie then
		-- Combat Mode
			Wisp.SetSpeed(myWisp, self.CombatSpeed)
			local tooFar = not IsDistanceBetweenThingsUnder(self.Entity, QuestManager.HeroEntity, self.MaxTargetDistance)
			local swapTimer = QuestManager.NewTimer(1) -- Timer used to hop targets, but first loop we want it small so it leaves the hero.
			self.WispTarget = GetPlayerHero()
			self.DebugText = "Entering Combat"
			local applied_timer = QuestManager.NewTimer(0)
			local cooldown_timer = QuestManager.NewTimer(0)
			local hascooled = true
			local originalpos
			-- Combat Loop
			while self.InCombat and not self.ShouldDie do				
				ScriptFunction.WaitForTimeInSeconds(.25)
				-- If it's time to find an enemy, let's try.
				if swapTimer:GetTime() == 0 then
					swapTimer:SetTime(self.TargetSwapTime)
					local newtarget = self:AcquireNewTarget(self.WispTarget)
					self.WispTarget = newtarget
				end
				if self.WispTarget == nil or self.Entity == nil or type(self.MaxTargetDistance) ~= "number" then
					GUI.DisplayMessageBox("Somehow wisp target or self.Entity or self.MaxTargetDistance is nil??? Killing Wisp AI.")
					return
				end
				-- If the previously acquired target is dead we need another one.
				if not self.WispTarget:IsAlive() then
					self:RemoveEffect(self.WispTarget)
					self.WispTarget = self:AcquireNewTarget(self.WispTarget)
				end
				self.DebugText = "Combat waiting target movement\nTarget: " .. (self.WispTarget:GetName() or "noname")
				-- Position update bit. Pause everything while the wisp is moving.
				tooFar = not IsDistanceBetweenThingsUnder(self.Entity, self.WispTarget, self.MaxTargetDistance)
				-- GUI.DisplayMessageBox("debug: toofar checked, " .. tostring(tooFar))
				if tooFar then
					Wisp.SetDestination(self.Entity, self.WispTarget:GetPosition() + CVector3(0,0,3.5))
					-- GUI.DisplayMessageBox("debug: wisp dest set")
					-- While wisp is moving we don't want to change anything. Maybe we can in the future though if the hero targets something else?
					local alreadychangedlog = false
					while Wisp.IsMoving(self.Entity) do
						-- GUI.DisplayMessageBox("beginning of moving loop.")
						if not alreadychangedlog then 
							self.DebugText = "Combat\nHopping to target\n" .. (self.WispTarget:GetName() or "noname")
							alreadychangedlog = true
						end
						wispfree = false;
						coroutine.yield()
						-- GUI.DisplayMessageBox("debug: at end of moving loop, about to check if moving again.")
					end
				end

				-- Effect update
				if cooldown_timer:GetTime() <= 0 then
					if applied_timer:GetTime() <= 0 then
						-- GUI.DisplayMessageBox("debug: applied timer and cooldown timer is 0")
						ScriptFunction.WaitForTimeInSeconds(1)
						if hascooled and self.WispTarget ~= QuestManager.HeroEntity then
							originalpos = self.WispTarget:GetPosition()
							applied_timer:SetTime(self.WispEffects[self.CurrentEffect].EffectTime)
							self:ApplyEffect(self.WispTarget, self.CurrentEffect)
							hascooled = false
						elseif hascooled and self.WispTarget == QuestManager.HeroEntity then
							swapTimer:SetTime(0)
						else
							self:RemoveEffect(self.WispTarget, self.CurrentEffect)
							local cooldown = self.WispEffects[self.CurrentEffect].Cooldown
							cooldown_timer:SetTime(cooldown)
							swapTimer:SetTime(cooldown)
							self.WispTarget = GetPlayerHero()
							hascooled = true
						end
					else
						-- update current effect
						if not originalpos or ((originalpos - CVector3(0,0,0)):GetLength() < 1) then
							GUI.DisplayMessageBox("Wisp is trying to update an effect but originalpos is " .. tostring(target_pos))
							ScriptFunction.WaitForTimeInSeconds(.5)
						end
						self:StatusUpdate(self.WispTarget, originalpos)
						ScriptFunction.WaitForTimeInSeconds(.5)
					end
				end

				-- GUI.DisplayMessageBox("debug: cooldown applied timers end")
				self.InCombat = self:AreEnemiesNear()
			end
			self:RemoveEffect(self.WispTarget, self.CurrentEffect)
		end
	end
end

-- For updating the status effects that get applied to enemies. Called exclusively by AI coroutine.
function wispTab:StatusUpdate(target, center)
	-- GUI.DisplayMessageBox("debug: status update tick")
	if not target or not center then
		GUI.DisplayMessageBox("StatusUpdate was given no target and/or no center!\nTarget:" .. tostring(target) .. "\n\ncenter: " .. tostring(center))
		return
	end
	if self.CurrentEffect == self.EffectEnum.BIND and ((center - target:GetPosition()):GetLength() > 1) then
		self:RemoveEffect(target, self.CurrentEffect)
		self:ApplyEffect(target, self.CurrentEffect)
	end
	-- TODO: Implement the block removal
	-- GUI.DisplayMessageBox("debug: status update end")
end


-- For the vfx that follow the enemy target
function wispTab:VFXUpdate()
	while not self.ShouldDie do
		-- We only return to this bit while we're not in combat. At this point we just wait for combat.
		ScriptFunction.WaitForTimeInSeconds(.5)
		if self.InCombat then
			-- We should have just entered combat. VFX may not exist yet, we need the wisp to choose a target first.

			while self.InCombat and not self.ShouldDie do
				-- Error checking first
				if not self.Entity or not self.Entity:IsAlive() then
					GUI.DisplayMessageBox("VFX update tried to enter combat but there's no wisp entity!\nThis may happen after loading an area while in combat.")
					while not self.Entity or not self.Entity:IsAlive() do
						ScriptFunction.WaitForTimeInSeconds(1)
					end
				end
				-- Now for actual position update stuff.
				if self.CurrentVFX and self.WispTarget then
					self.CurrentVFX:SetPosition(self.WispTarget:GetPosition())
				end
				coroutine.yield()
			end
			-- At this point we just left combat or the AI has stopped.
		end
	end
end

-- Menu system. If the player goes first person, looks at the entity, and presses A then open the menu. TODO: Add the looking at entity bit.
function wispTab:MenuUpdate()
	local function show_menu()
		local main_menu_result
		while main_menu_result ~= 0 do
			main_menu_result = MultipageMenu.ShowMenuBoxWithPages(
				"Wisp Menu Title",
				{ 
					{TextTag = "Say Hello", Enabled = true},
					{TextTag = "Toggle Debug Text " .. "(Enabled: " .. tostring(self.ShowDebugText) .. ")", Enabled = true},
					{TextTag = "Spell Select", Enabled = false} 
				}
			)
			if main_menu_result == 1 then
				GUI.DisplayMessageBox("Hi!")
				return -- Only return if an option doesn't lead to another menu or you don't want the user to have multiple options.
			elseif main_menu_result == 2 then
				self.ShowDebugText = not self.ShowDebugText
			end
		end
	end

	while not self.ShouldDie do
		if not self.InCombat then
			if Player.IsInFirstPerson(QuestManager.HeroEntity) then
				local pressed_a, message = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_GENERIC_A_BUTTON_PRESSED, self.LastMessageID_PressedAButton)
				if pressed_a and (Timing.GetWorldFrame() - message:GetTimeStamp() < 5) then
					self.LastMessageID_PressedAButton = message:GetID()
					show_menu()
				end
			end
		end
		coroutine.yield()
	end
end

function wispTab:SpawnCage(targetpos)
	-- GUI.DisplayMessageBox("debug: spawning cage")
    local sword = Debug.CreateEntityByHero("MetalWork_Minigame_Stage1")
    sword:SetPosition(targetpos + CVector3(-0.5,0,1))
    Physics.SetFacingVector(sword, CVector3(0,0,0))
	GraphicAppearance.SetScale(sword, 1.7)
	self.BindObjects[1] = sword


    sword = Debug.CreateEntityByHero("MetalWork_Minigame_Stage1")
    sword:SetPosition(targetpos + CVector3(0.5,0,1))
    Physics.SetFacingVector(sword, CVector3(0,0,0))
	GraphicAppearance.SetScale(sword, 1.7)
	self.BindObjects[2] = sword

    sword = Debug.CreateEntityByHero("MetalWork_Minigame_Stage1")
    sword:SetPosition(targetpos + CVector3(0,0.5,1))
    Physics.SetFacingVector(sword, CVector3(1,0,0))
	GraphicAppearance.SetScale(sword, 1.7)
	self.BindObjects[3] = sword

    sword = Debug.CreateEntityByHero("MetalWork_Minigame_Stage1")
    sword:SetPosition(targetpos + CVector3(0,-0.5,1))
    Physics.SetFacingVector(sword, CVector3(1,0,0))
	GraphicAppearance.SetScale(sword, 1.7)
	self.BindObjects[4] = sword
	-- GUI.DisplayMessageBox("debug: cage spawned")
end

function wispTab:RemoveCage()
	-- GUI.DisplayMessageBox("debug: removing cage")
	for i=1,#self.BindObjects do
		self.BindObjects[i]:Destroy()
	end
	-- GUI.DisplayMessageBox("debug: cage removed")
end

function wispTab:AreEnemiesNear()
	if SACCamera then
		return #CameraManager.GetFoes(SACCamera:GetMaxSearchDistanceForEnemies()) > 0 -- *sigh* Using this instead of SACCamera's nearby foes because it's not perfect.
	else
		GUI.DisplayMessageBox("SACCamera is nil!")
		self.ShouldDie = true
	end
end

-- This function gets a new target for the wisp to target and hop to.
function wispTab:AcquireNewTarget(oldTarget)
	-- GUI.DisplayMessageBox("debug: AcquireNewTarget start")
	local potentialTargets = CameraManager.GetFoes(SACCamera:GetMaxSearchDistanceForEnemies())
	-- Get a nearby target. In the future, mess around with this to acquire a custom target. Though maybe if manual targetting mode then this shouldn't even be called.
	local target
	if #potentialTargets > 0 then
		target = potentialTargets[math.random(1, #potentialTargets)]
		local moreTargets = #potentialTargets > 1
		local creature_type = Creature.GetCreatureType(target)
		if moreTargets and (target == oldTarget or creature_type == ECreatureType.CREATURE_TROLL or creature_type == ECreatureType.CREATURE_SHARD) then
			-- Already have this target and there's more than one. We want ver eye it ee
			local potentialNewTargets = {}
			for k,v in ipairs(potentialTargets) do
				creature_type = Creature.GetCreatureType(v)
				if oldTarget ~= v and (creature_type ~= ECreatureType.CREATURE_TROLL and creature_type ~= ECreatureType.CREATURE_SHARD) then
					table.insert(potentialNewTargets, k, v)
				end
			end
			target = potentialNewTargets[math.random(1, #potentialNewTargets)]
		end
		if target == nil or not target:IsAlive() then
			target = QuestManager.HeroEntity
			GUI.DisplayMessageBox("Wisp tried to get dead or nil enemy! Given hero instead.\nThis should NEVER happen.")
		end
	else
		-- In the future, when this happens try getting the heroes target if its relation is enemy.
		target = QuestManager.HeroEntity
	end
	-- GUI.DisplayMessageBox("debug: AcquireNewTarget end")
	return target
end

-- This function applies effects to the target entity, and spawns vfx.
function wispTab:ApplyEffect(target, effect)
	if target == QuestManager.HeroEntity then
		GUI.DisplayMessageBox("Wisp tried to apply effect to hero")
		return
	elseif target == nil then
		GUI.DisplayMessageBox("Wisp tried to apply effect to nil")
		return
	end


	if target and target:IsAlive() then
		if effect == self.EffectEnum.VULNERABILITY then
			Health.Modify(target, -Health.Get(target)/2, target)
		elseif effect == self.EffectEnum.BIND then
			self:SpawnCage(target:GetPosition())
		end
	end
	self.CurrentVFX = Debug.CreateEntityAt("FX_CullisGate_Stage_01", "wispfx", target:GetPosition())
end

-- This function removes effects from the target entity.
function wispTab:RemoveEffect(target, effect)
	-- GUI.DisplayMessageBox("debug: Remove effect start")
	if target == QuestManager.HeroEntity then
		return
	end
	if self.EffectEnum == nil then
		GUI.DisplayMessageBox("self.EffectEnum is nil??????????????????????????????\nself: ".. tostring(self))
	end
	if target and target:IsAlive() then
		if effect == self.EffectEnum.VULNERABILITY then
			Health.Modify(target, Health.Get(target), target)
		end
	end
	if effect == self.EffectEnum.BIND then
		self:RemoveCage()
	end
	if self.CurrentVFX then
		self.CurrentVFX:Destroy()
	end
	-- GUI.DisplayMessageBox("debug: Remove effect end")
end

GeneralScriptManager.AddScript(wispTab)