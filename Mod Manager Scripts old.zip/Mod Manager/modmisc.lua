DisplayAllKeys = function(someTable, val) -- table to print, bool for whether to print key or values. Intended to print keys.
	local howManyKeys = 0
	local tmpstr = ""
	for k,v in pairs(someTable) do
		local resultStr = ""
		if val then
			resultStr = tostring(v)
		else
			resultStr = tostring(k)
		end
		tmpstr = tmpstr .. "\n" .. resultStr
		howManyKeys = howManyKeys+1
	end
	if howManyKeys < 1 then
		GUI.DisplayMessageBox("Table had no keys!")
		return
	end
	
	-- Add all keys to a string, seperated by new lines
	local strTable = {}

	for s in tmpstr:gmatch("[^\r\n]+") do
		table.insert(strTable, s)
	end
	
	-- Print 12 lines of a table's keys at a time
	local strBundle = ""
	myI = 0
	for i = 1, #strTable do
		myI = i
		if i % 12 == 0 then
			GUI.DisplayMessageBox(strBundle .. "\nPage " .. tostring(i/12) .. " of " .. tostring(#strTable/12))
			strBundle = ""
		end
		strBundle = strBundle .. tostring(strTable[i]) .. "\n"
	end
	if myI % 12 ~= 0 then
		GUI.DisplayMessageBox(strBundle)
		strBundle = ""
		myI = 0
	end
end

function UnstuckHero(ent)
	if type(ent) ~= "userdata" then
		ent = QuestManager.HeroEntity
	end
	ScriptFunction.SetDefaultCamera()
	Player.StopInteractionMode(ent)
end