--[[

This script contains the logic for either starting the runner, or calling the runner's OnSaveLoad function.

	(GSM/WI are internal) 			(you are here)
			v		  					  v
GeneralScriptManager.LoadFromSave() --> init -----> startrunner -> runner
WeaponInventory->WeaponInventoryOverride-^ 

--]]

-- Arg is either the runner's table, or nil/
-- If runner, call its OnSaveLoad. If no runner, start it.
local args = {...}

local manager = args[1]

if type(manager) == "table" then
	local worked, whynot = pcall(manager.OnSaveLoad)
	if not worked then
		GUI.DisplayMessageBox("Mod Manager OnSaveLoad failure:\n" .. tostring(whynot) .. "\n\n\nSome mods may not work properly.")
	end
else 
	local worked, whynot = pcall(loadfile("scripts/Mod Manager/startrunner.lua"))
	if not worked then
		GUI.DisplayMessageBox("Failed to call startrunner from manager init!")
	end
end
