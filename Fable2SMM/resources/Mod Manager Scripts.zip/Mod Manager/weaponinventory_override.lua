-- This script is run on newgame and saveload.
-- A debug function has been relocated here to make space in gamescripts_r.
-- That space is then used to call this script, the purpose of which is to start the runner.

if IsLoadedFromSaveGame and not IsLoadedFromSaveGame() then
  local manageroverride = {}
  function manageroverride.Update()
    SetGeneralScriptManager(GeneralScriptManager)
    local worked, whynot = pcall(loadfile("scripts/Mod Manager/init.lua"))
    if not worked then
      GUI.DisplayMessageBox("Failed to start Manager runner:\n" .. tostring(whynot))
    end
  end
  SetGeneralScriptManager(manageroverride)
end

--[[

-- This was basically to let us patch the childhood script, but honestly it's more trouble than it's worth.
-- Patching is still introduced through the runner.

  local worked, whynot = pcall(loadfile("scripts/Mod Manager/Patching/DeltaPatchIngame.lua"))
  if not worked then
    GUI.DisplayMessageBox(whynot)
    return
  end

  local overridenrequire, overridewhynot = pcall(_OverrideRequire)
  if not overridenrequire then
    GUI.DisplayMessageBox(tostring("Failed to override `require` for patching:\n" .. tostring(overridewhynot)))
    return
  end

  AddPatch("scripts/quests/qc010_childhood.lua", "scripts/Mods/ChildhoodPatch/patch.lua", "mychildhoodpatch")

--]]

function Debug.AddAllDLC2Items(entity)
  entity = entity or GetPlayerHero()
  Inventory.AddItemOfType(entity, "ObjectWeaponRoyalSceptre")
  Inventory.AddItemOfType(entity, "QD050_Snowglobe")
  Inventory.AddItemOfType(entity, "QD050_Skull")
  Inventory.AddItemOfType(entity, "QD050_SpireStatue")
  Inventory.AddItemOfType(entity, "QD050_ArenaMiniature")
  Inventory.AddItemOfType(entity, "QD060_OastHouseDoorKey")
  Inventory.AddItemOfType(entity, "QD060_RedSeal")
  Inventory.AddItemOfType(entity, "QO890_ColosseumTrophy")
  Inventory.AddItemOfType(entity, "QO890_AAATeddy_Posh")
  Inventory.AddItemOfType(entity, "QO890_AAATeddy_Royal")
  Inventory.AddItemOfType(entity, "QO890_AAATeddy_Wizard")
  Inventory.AddItemOfType(entity, "QD060_ChestyInvite")
  Inventory.AddItemOfType(entity, "QD060_ArchieDiary")
  Inventory.AddItemOfType(entity, "QD060_ChestyNote")
  Inventory.AddItemOfType(entity, "QD060_SchoolDiary")
  Inventory.AddItemOfType(entity, "QD060_RabbitBook")
  Inventory.AddItemOfType(entity, "QD060_Mug")
  Inventory.AddItemOfType(entity, "QD070_Egg")
  Inventory.AddItemOfType(entity, "QD070_Key")
  Inventory.AddItemOfType(entity, "QD060_ChestyFlitswitchNote")
  Inventory.AddItemOfType(entity, "ObjectClothingHatSoldier")
  Inventory.AddItemOfType(entity, "ObjectClothingCoatSoldier")
  Inventory.AddItemOfType(entity, "ObjectClothingTrousersSoldier")
  Inventory.AddItemOfType(entity, "ObjectClothingBootsSoldier")
  Inventory.AddItemOfType(entity, "ObjectClothingHatSkeleton")
  Inventory.AddItemOfType(entity, "ObjectClothingShirtSkeleton")
  Inventory.AddItemOfType(entity, "ObjectClothingTrousersSkeleton")
  Inventory.AddItemOfType(entity, "ObjectClothingGlovesSkeleton")
  Inventory.AddItemOfType(entity, "ObjectClothingBootsSkeleton")
  Inventory.AddItemOfType(entity, "ObjectClothingHatBalverine")
  Inventory.AddItemOfType(entity, "ObjectClothingCoatBalverine")
  Inventory.AddItemOfType(entity, "ObjectClothingBootsBalverine")
  Inventory.AddItemOfType(entity, "ObjectClothingCoatHobbe")
  Inventory.AddItemOfType(entity, "ObjectClothingBootsHobbe")
  Inventory.AddItemOfType(entity, "ObjectClothingHatRoyal")
  Inventory.AddItemOfType(entity, "ObjectClothingCoatRoyal")
  Inventory.AddItemOfType(entity, "ObjectClothingTrousersRoyal")
  Inventory.AddItemOfType(entity, "ObjectClothingBootsRoyal")
  Inventory.AddItemOfType(entity, "ObjectClothingHatWitchFinder")
  Inventory.AddItemOfType(entity, "ObjectSuitSoldier")
  Inventory.AddItemOfType(entity, "ObjectSuitSkeleton")
  Inventory.AddItemOfType(entity, "ObjectSuitBalverine")
  Inventory.AddItemOfType(entity, "ObjectSuitHobbe")
  Inventory.AddItemOfType(entity, "ObjectSuitRoyal")
  Inventory.AddItemOfType(entity, "ObjectHairElvira")
  Inventory.AddItemOfType(entity, "ObjectHairSpiky")
  Inventory.AddItemOfType(entity, "ObjectHairMiddleClassWig")
  Inventory.AddItemOfType(entity, "ObjectHairBunBraidedFemale")
  Inventory.AddItemOfType(entity, "ObjectHairSkinheadFemale")
  Inventory.AddItemOfType(entity, "ObjectMakeupScaryClown")
  Inventory.AddItemOfType(entity, "ObjectMakeupSkeleton")
  Inventory.AddItemOfType(entity, "ObjectMakeupWoad")
  Inventory.AddItemOfType(entity, "ObjectMakeupCrow")
  Inventory.AddItemOfType(entity, "ObjectMakeupHarlequin")
  Inventory.AddItemOfType(entity, "ObjectMakeupPrinceRegent")
  Inventory.AddItemOfType(entity, "ObjectInventoryPotionDogHusky")
  Inventory.AddItemOfType(entity, "ObjectInventoryPotionDogBloodhound")
  Inventory.AddItemOfType(entity, "ObjectInventoryPotionDogDalmation")
  Inventory.AddItemOfType(entity, "ObjectInventoryPotionDogLabrador")
  Inventory.AddItemOfType(entity, "ObjectMurgoSilverStatue_Chicken")
  Inventory.AddItemOfType(entity, "ObjectMurgoSilverStatue_Beg")
  Inventory.AddItemOfType(entity, "ObjectMurgoSilverStatue_DanceSuccess")
  Inventory.AddItemOfType(entity, "ObjectMurgoSilverStatue_Dismiss")
  Inventory.AddItemOfType(entity, "ObjectMurgoSilverStatue_Extort")
  Inventory.AddItemOfType(entity, "ObjectMurgoSilverStatue_Flirty")
  Inventory.AddItemOfType(entity, "ObjectMurgoSilverStatue_Laugh")
  Inventory.AddItemOfType(entity, "ObjectMurgoSilverStatue_MiddleFinger")
  Inventory.AddItemOfType(entity, "ObjectMurgoSilverStatue_ScaryLaugh")
  Inventory.AddItemOfType(entity, "ObjectMurgoSilverStatue_ThumbsUp")
  Inventory.AddItemOfType(entity, "ObjectInventoryDyeDLC2_ChestyRed")
  Inventory.AddItemOfType(entity, "ObjectInventoryDyeDLC2_BalverineBrown")
  Inventory.AddItemOfType(entity, "ObjectInventoryDyeDLC2_WispWhite")
  Inventory.AddItemOfType(entity, "ObjectInventoryDyeDLC2_Hair_Roma")
  Inventory.AddItemOfType(entity, "ObjectInventoryDyeDLC2_Hair_StrawberryBlonde")
  Inventory.AddItemOfType(entity, "ObjectInventoryDyeDLC2_CursedGrey")
  Inventory.AddItemOfType(entity, "ObjectInventoryDyeDLC2_OakvaleGreen")
  Inventory.AddItemOfType(entity, "ObjectInventoryDyeDLC2_OakvaleBlue")
  Inventory.AddItemOfType(entity, "ObjectInventoryDyeDLC2_OakvaleRed")
  Inventory.AddItemOfType(entity, "ObjectInventoryDyeDLC2_OakvaleYellow")
end