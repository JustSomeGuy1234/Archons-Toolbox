-- DeltaPatchApplicator.lua

local args = {...}
local scriptpath = args[1]
local patchpath = args[2]
if not scriptpath or not patchpath then
	error("No source or modded file passed")
end

local scriptdumped = string.dump(loadfile(scriptpath))

local scriptlen,patchoffsets,patchvalues = loadfile(patchpath)()

--  Split entire script up into chars
local scripttable = {}
for i=1,#scriptdumped do
	if scriptlen < i then break end
	scripttable[i] = scriptdumped:sub(i,i)
end

-- Replace the bytes in the script with those provided by the patch
for i=1, #patchoffsets do
	local offset = patchoffsets[i]
	local value = patchvalues[i]
	assert(value, "ERROR: Patch offset had no value! Index: " .. tostring(i))
	scripttable[offset] = string.char(value)
end

local finalstring = table.concat(scripttable)
local finalfunc, err = loadstring(finalstring)
if not finalfunc then
	error(err)
end
return finalfunc