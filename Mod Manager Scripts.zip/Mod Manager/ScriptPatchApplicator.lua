local args = {...}
local scriptpath = args[1]
local patchpath = args[2]
local outputpath = args[3] -- This would be for caching generation
if not scriptpath or not patchpath then
	print("no source file or modded file provided")
	io.input()
	return
end

-- Would be acquired through loadfile based on the requested script, unless we search for a cached version
local scriptdumped = string.dump(loadfile(scriptpath))
local patchtable = loadfile(patchpath)()
local scripttable = {}

-- split script's bytes into table/array
for i=1,#scriptdumped do
	scripttable[i] = scriptdumped:sub(i,i)
end
-- insert/replace each byte from the patch table
for k,v in ipairs(patchtable) do
	scripttable[v[1]] = string.char(tonumber(v[2], 16))
end
-- turn it into string so we can loadstring it
local finalstring = table.concat(scripttable)

if outputpath then
	local out = io.open(outputpath, "w")
	out:write(finalstring)
	out:close()
end

local finalfunc, err = loadstring(finalstring)
return finalfunc, err