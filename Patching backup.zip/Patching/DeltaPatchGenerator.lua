-- DeltaPatchGenerator.lua

--[[
Args:
origpath: The unmodified script path
newpath: The modified script path
outpath: The patch output path

Returns: A table containing each differing byte. This is most likely useless as the table is written to the output path to be loaded later by the game state.
--]]

output = output or print
local args = {...}
local origpath = args[1]
local newpath = args[2]
local outpath = args[3]
if not origpath or not newpath or not outpath then
	print("no source file or modded file or outpath provided")
	io.input()
	return
end

-- Load the original file and dump it into a string. Do the same with the modified version.
local loaded, err = loadfile(origpath)
if not loaded or err then error(err) end
local originaldumped = string.dump(loaded)
local original_length = #originaldumped

loaded, err = loadfile(newpath)
if not loaded or err then error(err) end
local newdumped = string.dump(loaded)


-- For each byte in our modified script, compare to the original. 
-- Any differences will be added to two tables one will contain the offsets, the other will contain the values. Neither will have keys.
-- Offsets will be relative to the last one. This saves a lot of space as instead of {6000,6001,6002,6342,6343}, we'll have {6000,1,1,340,1} which almost halves the size.
-- (A negative offset indicates the number of bytes that we can write consecutively without needing an offset for each)

print("Modified len: " .. tostring(#newdumped))
print("Original len: " .. tostring(original_length))
patchoffsetsegments = {}
patchvaluesegments = {}

-- Used to write a relative offset
local lastoffset = 0

-- Used to track how many bytes were consecutive, saving us from having to write multiple 1's to the offsets
local consecs = 0

-- Used to go backwards to synchronise offsets and values when consecs have shrunk the total number of offsets. 
-- e.g. offsets[100] may represent values[200] if there were 100 totalconsecs starting from offsets[99]
local totalconsecs = 0

local finaloffset = -1

for offset=1, #newdumped do
	local newByte = newdumped:sub(offset, offset)
	local tableindex = #patchvaluesegments + 1
	if offset > original_length or newByte ~= originaldumped:sub(offset, offset) then
		-- Byte is different. Increment consecs, write the value to values, .

		consecs = consecs + 1
		if consecs > 1 then
			totalconsecs = totalconsecs+1
		end

		-- Unused if this is the second+ consec
		finaloffset = offset - lastoffset
		lastoffset = offset

		-- If not consecutive byte then just write the offset
		if consecs == 1 then
			patchoffsetsegments[#patchoffsetsegments+1] = finaloffset
		end
		
		patchvaluesegments[tableindex] = string.byte(newByte)
		finaloffset = offset
	elseif consecs > 1 then
		-- If there is more than one consec, this is a streak and we need to write the number of consecs.
		-- print("breaking consec streak: " .. tostring(consecs))
		patchoffsetsegments[#patchoffsetsegments+1] = (-consecs)+1 -- Add (take) one because we write the first byte's offset.
		consecs = 0
	else
		consecs = 0
	end
	finaloffset = offset
end
print("The last differing byte was at " .. tostring(finaloffset))

if consecs > 1 then
	patchoffsetsegments[#patchoffsetsegments+1] = (-consecs)+1
end
-- print(totalconsecs) -- This should basically be the number of consecs in the offsets table, excluding -1, and the first of each streak

local predictedvalcount = 0
for k,v in ipairs(patchoffsetsegments) do
	if v < 0 then
		predictedvalcount = predictedvalcount + math.abs(v)
	else
		predictedvalcount = predictedvalcount + 1
	end
end

output("Predicted Val Count in patch: " .. tostring(predictedvalcount))
output("Real val count in patch: " .. tostring(#patchvaluesegments))
if predictedvalcount ~= #patchvaluesegments then
	output("PATCH ERROR!!! Predicted val count does not match!!!")
end

for k,v in pairs(patchoffsetsegments) do
	if k > 1 and not patchoffsetsegments[k-1] then
		print("missing byte before " .. tostring(k))
	end
end
 
-- They will be concat'd into string form, creating two "tables" to be written to the patch file.
-- Concat the offset and value tables into two strings.
patchoffsettableconcat = table.concat(patchoffsetsegments, ",")
patchvaluetableconcat = table.concat(patchvaluesegments, ",")

-- Concat all strings to create the final string to write to the patch file
local patchstring = "local len = " .. tostring(#newdumped) .. "\n"
patchstring = patchstring .. "local offsets = {\n    "
patchstring = patchstring .. patchoffsettableconcat .. "\n}\n"

patchstring = patchstring .. "local values = {\n    " .. patchvaluetableconcat .. "\n}\n"

patchstring = patchstring .. "\nreturn len, offsets, values"


local patchfile = io.open(outpath, "w")
patchfile:write(patchstring)
patchfile:close()


-- Go through the patch application process to make sure it works
local app, err = loadfile("GAME:/data/scripts/Mod Manager/Patching/DeltaPatchApplicator.lua")
if not app then
	print("Failed to compile patch applicator from GUI state. Unable to check whether patch works:\n" .. tostring(err))
else
	app(origpath, outpath)
end

return patchstring