function ModUpdate()
	custom_update = coroutine.create(CustomUpdate)
	while not ShouldDie do
		coroutine.yield()
		MyScriptWorked, ScriptWhyNot = coroutine.resume(custom_update)
		if not MyScriptWorked then
			GUI.DisplayMessageBox("Script errored! Reason:\n " .. tostring(ScriptWhyNot))
			ShouldDie = true
		end
	end
	coroutine.yield()
end

function CustomUpdate()
	local checktimer = QuestManager.NewTimer(3)
	local orbs = {}
	local up = CVector3(0,0,1)
	while not ShouldDie do
		coroutine.yield()
		if checktimer:GetTime() == 0 then
			local search = SearchTools.FilterWithEC(SearchTools.StartNewSearch("object"), ExperienceOrb.GetECType())
			orbs = SearchTools.GetSearchResults(search)
			checktimer:SetTime(2.5)
		end
		for i=1,#orbs do
			local orb = orbs[i]
			local orbpos = orb:GetPosition()
			orb:SetPosition(orbpos + (QuestManager.HeroEntity:GetPosition() + up - orbpos) / 60)
		end
	end
end