-- Limitations: 
-- 				None of the following is allowed: 
--					Multi-line comments. Hex values. Functions. Operations. Variable values.  Return marks the end of the file. 
-- 				This is because this file gets interpreted manually by the manager, and I'm not writing a full thing for it (though it feels like I already have).

local runnerversion = 1.05
local installedmods = {
	BetterRaiseDead = {
Enabled = true, Installed = true, ClearData = false,
NameID = "BetterRaiseDead",
StartScriptPath = "main.lua",
VersionMajor = 1,
VersionMinor = 0,
Author = "Guy",
},
	RuntimeCodeRunner = {
Enabled = true, Installed = true, ClearData = false,
NameID = "RuntimeCodeRunner",
StartScriptPath = "CodeLoader.lua",
VersionMajor = 1,
VersionMinor = 1,
Static = false,
Author = "Guy",
},
	OrbSucker = {
Enabled = false, Installed = false, ClearData = false,
NameID = "OrbSucker",
StartScriptPath = "start.lua",
VersionMajor = 1,
VersionMinor = 1,
Static = false,
Author = "Guy",
},
	FishingMod = {
Enabled = false, Installed = false, ClearData = false,
NameID = "FishingMod",
StartScriptPath = "main.lua",
VersionMajor = 1,
VersionMinor = 1,
Static = false,
Author = "Guy",
},
	DogTeleporter = {
Enabled = false, Installed = false, ClearData = false,
NameID = "DogTeleporter",
StartScriptPath = "start.lua",
VersionMajor = 1,
VersionMinor = 1,
Static = true,
Author = "Guy",
},
	DebugMenuMod = {
Enabled = true, Installed = true, ClearData = false,
NameID = "DebugMenuMod",
StartScriptPath = "main.lua",
VersionMajor = 1,
VersionMinor = 3,
Static = false,
Author = "Guy",
},
	
}

local installedmodules = {}
return installedmods, runnerversion