function balls()
	  print("hi")
end