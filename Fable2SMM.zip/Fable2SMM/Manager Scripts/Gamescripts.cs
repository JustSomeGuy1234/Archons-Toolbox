﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fable2SMM
{
    public class Gamescripts
    {
        public static string GamescriptsPath => Path.Combine(ManagerInstallation.DataFolder + @"gamescripts_r.bnk");
        public static string GamescriptsBackupPath => Path.Combine(GamescriptsPath + ".bak");
        public const string GamescriptsOriginalHash = "68A2EF1F703C3C325F268EDCD5CDADBC5C869E96CF7C7E2E38BC017153C876E2";
        public const string GamescriptsManagerHash = "EBC1A579A9166667439310D9300B6D3F44799966B700A607107F30FFD432EC8D";

        public static GamescriptsStatus CurrentGamescriptsStatus { get => _gamescriptsStatus; set { _gamescriptsStatus = value; CurrentGamescriptsStatusChanged?.Invoke(null, EventArgs.Empty); } }
        private static GamescriptsStatus _gamescriptsStatus = GamescriptsStatus.ORIGINAL;
        public static event EventHandler CurrentGamescriptsStatusChanged;
    }
}
