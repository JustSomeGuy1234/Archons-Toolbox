if myWisp then
	-- TODO: Add a restarting thingy here
end
-- TODO: Add the enemy targetting bit. -- Mostly done. Need to prevent same target twice
-- TODO: Add status effects. -- In Progress (vulnerability done)
-- 		 	Bind: Navigation.SetMovementPaused(ent, true)
--			Stun: Combat.SetCanFight(ent, false)
--			Other incapacitation: Look at the navigation table.
--			Figure out how to apply an effect for a limited time without having the wisp hop. 
--				Or just have the wisp hop to the hero after applying an effect, then wait as a cooldown.
-- TODO: Make target highlight a different colour. GraphicAppearance.SetHighlightColour(ent, 0, 0, 255). Unfortunately requires setting *after* hero targets it.
-- TODO: Have particles instead of whatever else to highlight the target. There's a really cool zapping animation called FX_Necromancer_Target
-- Candidate effects: FX_Necromancer_Target, FX_Shadow_Teleport (lingers), FX_Forest_Troll_Travel (good for stun), FX_Blast_Trail (good for targeting), FX_Spell_Fireball (good fire spell)
--					  FX_Clothes_Change (huge quick blue explosion. Maybe freeze?), FX_PotionEffect_Experience_Strength(also good target indicator), FX_PotionEffect_Experience_Skill, FX_PotionEffect_Experience_Will,
--					  FX_XP_Powerup_Effects, FX_Hero_Teleport (blue geyser), FX_Musicbox_Disappear (combo hit effect), FX_HeroCircle_Symbol_S and _Red_S (hero floor symbol, good ultimate), 
-- 					  FX_HeroCircle_Symbol and _Red(particle ring around hero symbol), FX_Wide_Light_Beam (beam in guild hall. Good heal maybe.) and FX_God_Ray (smaller) and FX_Highlight_Beam (even less offensive),
--					  FX_Hammer_Blessing (big shiny sparkles), FX_Lucien_Shockwave (Good for big force/push back), FX_Standard_Teleporter (swirly magic teleporter), 
--					  FX_Magic_Ship_Blast (straight up huge EXPLOSION) or FX_Wood_Explosion (same without sound) or FX_Explosion_Rock (slightly smaller with rock), 
--					  FX_HeroHill_Ranged_S and _Melee_ and _Magic_ and _Hero_ (like hero symbol but smaller and louder), FX_Goodguy_Teleporter (like teleporter but without ring)
--					  FX_HeroHill_Melee _Ranged _Melee _Magic (good for more aggressive targeting), FX_Musicbox_Base (Small gold glowy), FX_HeroHill_Sparkles (aoe bigger sparkles),
--					  FX_Lucien_Shield (sphere of fuzzy stuff, maybe good for bind/stun), FX_Lucien_Shield_Hit, FX_Blocking_Fire (wall of fire), FX_Banshee_Debris_Suck (windy blowing sucky)
--					  FX_Poison_Smoke (green gas)
--					  FX_Ritual_Statue_Water (if you want someone wet), FX_CullisGate_Stage_01 and 02 and 03 (could be very good for targeting)! FX_CullisGate_UpBlast (huge electric "cage"), 
-- 					  FX_Teleporter_Explosion (big pillar-shaped explosion), FX_Shadow_Tar (bubbly floor stuff, discrete for targeting) 
--					  
-- TODO: Either persist between level loads or don't but respawn. Script seems good at not dying, just the wisp ent isn't.
-- TODO: Prevent the same ent from being targetted twice in a row if there's more than one.
-- TODO: Add menu for configs
-- TODO: Testing

	
	if wispTab then
		wispTab:KillWisp()
	end

	wispTab = {}
	wispTab.DebugText = "Default Debug Text"
	wispTab.ShouldDie = false
	wispTab.MaxHeroDistance = 3 			-- Distance the wisp can fall behind the hero before hopping to them.
	wispTab.MaxTargetDistance = 1.3			-- Distance wisp can be from target enemy before hopping to them.
	wispTab.TargetHeightOffset = .4 		-- Height from entities feet the wisp will hop to.
	wispTab.TargetSwapTime = 6 				-- How often the wisp will swap targets to keep things interesting.
	wispTab.CombatSpeed = 1 				-- How fast the wisp moves during combat
	wispTab.RoamingSpeed = .6 				-- How fast the wisp moves when following the hero
	wispTab.InCombat = false				-- While it's something I'd rather keep in a local, it needs to be accessable outside of the AI update too.
	wispTab.WispTarget = GetPlayerHero()	-- Once again something I'd like to keep in a local but it needs to be accessed by the sword coroutine.
	wispTab.CurrentVFX = nil
	wispTab.EffectEnum = {VULNERABILITY = 1}
	wispTab.CurrentEffect = wispTab.EffectEnum.VULNERABILITY
	function wispTab:NewWisp()
		self.Entity = Debug.CreateEntityByHero("HollowManWisp", "MyWisp")
		myWisp = self.Entity
		CombatRegister:SetHollowManWispMovement(self.Entity, true)
		CombatRegister:SetHollowManWispSpawn(self.Entity, false)
		Combat.SetCanFight(self.Entity, false)
		Combat.SetCanFlee(self.Entity, false)
		Combat.SetCanBeAttacked(self.Entity, false)
		Follow.SetAsLevelFollowing(self.Entity, true)
		Follow.FollowEntity(self.Entity, GetPlayerHero(), 3) -- Does nothing :(
		Wisp.SetSpeed(myWisp, self.RoamingSpeed)

	end
	function wispTab:KillWisp()
		self.ShouldDie = true
		if self.Entity then
			self.Entity:Destroy()
		end
		if self.WispSword then
			self.WispSword:Destroy()
			self.WispSword = nil
		end
	end
	-- Update function updates the AI coroutine. Could call this the manager function if your head.
	wispTab.aiworked = true
	wispTab.aiwhynot = "AI coroutine hasn't been started yet"
	wispTab.swordworked = true
	wispTab.swordwhynot = "Sword coroutine hasn't been started yet"
	
	-- The normal Update function (which gets turned into a coroutine and resumed every tick by GeneralScriptManager)
	-- basically acts as a manager for the wisp AI coroutine.
	-- This "manager" coroutine creates the wisp's entity and AI instance on the first tick.
	-- Afterwards, it simply updates the wisp AI until there's an error.
	-- If there's an error in the wisp AI, the manager should display it and stop.
	function wispTab:Update()
		self:NewWisp() 
		self.aiupdate = coroutine.create(self.AIUpdate)
		self.swordupdate = coroutine.create(self.SwordUpdate)
		while not self.ShouldDie and self.aiworked do
			coroutine.yield()
			Debug.Draw3DText(self.Entity:GetPosition() + CVector3(0,0,.5), self.DebugText, 1.2, {DrawInFrontOfScene = true})
			-- Shut the wisp up for a few miliseconds
			Sound.StopSoundCategoryPlaying(self.Entity)
			-- Update wisp AI and check for errors
			self.aiworked, self.aiwhynot = coroutine.resume(self.aiupdate, self)
			if not self.aiworked then
				GUI.DisplayMessageBox("Wisp errored! Reason:\n " .. tostring(self.aiwhynot))
				self.ShouldDie = true
			end
			-- Update sword AI and check for errors, if it hasn't already broken.
			if self.swordworked then
				self.swordworked, self.swordwhynot = coroutine.resume(self.swordupdate, self)
				if not self.swordworked then
					GUI.DisplayMessageBox("Sword errored! Reason:\n " .. tostring(self.swordwhynot))
					self.ShouldDie = true
				end
			end
		end
		wispTab:KillWisp()
		coroutine.yield()
	end
	-- AI Update coroutine does the meaty stuff and is updated every tick by the above coroutine. Yes we have 2 coroutines, one for AI and one for managing it.
	function wispTab:AIUpdate()
		while not self.ShouldDie do
			-- The beginning is only ever returned to when swapping between roaming and combat modes.
			ScriptFunction.WaitForTimeInSeconds(.25)
			self.InCombat = self:AreEnemiesNear()
			if not self.InCombat and not self.ShouldDie then
			-- Roaming Mode
				Wisp.SetSpeed(myWisp, self.RoamingSpeed)
				local tooFar = not IsDistanceBetweenThingsUnder(self.Entity, QuestManager.HeroEntity, self.MaxHeroDistance)
				-- Roaming Loop
				while not self.InCombat do	
					ScriptFunction.WaitForTimeInSeconds(.5)
					tooFar = not IsDistanceBetweenThingsUnder(self.Entity, QuestManager.HeroEntity, self.MaxHeroDistance)
					if tooFar then
						Wisp.SetDestination(self.Entity, QuestManager.HeroEntity:GetPosition() + CVector3(0,0,3))
						-- While we're moving we don't want to change anything.
						while Wisp.IsMoving(self.Entity) do
							ScriptFunction.WaitForTimeInSeconds(.25)
							self.DebugText = "Roaming\nHopping to Hero"
						end
					end
					self.DebugText = "Roaming\nWaiting for Hero to move"
					self.InCombat = self:AreEnemiesNear()
				end
			elseif self.InCombat and not self.ShouldDie then
			-- Combat Mode
				Wisp.SetSpeed(myWisp, self.CombatSpeed)
				local tooFar = not IsDistanceBetweenThingsUnder(self.Entity, QuestManager.HeroEntity, self.MaxTargetDistance)
				local swapTimer = QuestManager.NewTimer(1) -- Timer used to hop targets, but first loop we want it small so it leaves the hero.
				self.WispTarget = GetPlayerHero()
				self.DebugText = "Entering Combat"
				-- Combat Loop
				while self.InCombat and not self.ShouldDie do				
					ScriptFunction.WaitForTimeInSeconds(.25)
					-- If it's time to find an enemy, let's try. In AcquireNewTarget we remove and add effects appropriately.
					if swapTimer:GetTime() == 0 then
						swapTimer:SetTime(self.TargetSwapTime)
						local newtarget = self:AcquireNewTarget(self.WispTarget)
						self.WispTarget = newtarget
					end
					-- If the previously acquired target in nil, we need another one.
					if self.WispTarget == nil or not self.WispTarget:IsAlive() then
						self.WispTarget = self:AcquireNewTarget(self.WispTarget)
					end
					if self.WispTarget == nil or self.Entity == nil or type(self.MaxTargetDistance) ~= "number" then
						GUI.DisplayMessageBox("Somehow wisp target or self.Entity or self.MaxTargetDistance is nil??? Killing Wisp AI.")
						return
					end
					self.DebugText = "Combat waiting target movement\nTarget: " .. (self.WispTarget:GetName() or "noname")
					-- Position update bit. Pause everything while the wisp is moving.
					tooFar = not IsDistanceBetweenThingsUnder(self.Entity, self.WispTarget, self.MaxTargetDistance)
					if tooFar then
						Wisp.SetDestination(self.Entity, self.WispTarget:GetPosition() + CVector3(0,0,3.5))
						-- While wisp is moving we don't want to change anything. Maybe we can in the future though if the hero targets something else?
						while Wisp.IsMoving(self.Entity) do
							self.DebugText = "Combat\nHopping to target\n" .. (self.WispTarget:GetName() or "noname")
							ScriptFunction.WaitForTimeInSeconds(.25)
						end
					end
					self.InCombat = self:AreEnemiesNear()
				end
				self:RemoveEffect(self.WispTarget, self.EffectEnum.VULNERABILITY)
			end
		end
	end
	
	-- Wisps "ghost" sword.
	function wispTab:NewSword()
		self.WispSword = Debug.CreateEntityAt("MetalWork_Minigame_Stage2", "Wisp Sword", self.Entity:GetPosition())
		ScriptFunction.Ghost(self.WispSword, 50, 0, 50, 200)
	end
	function wispTab:DestroySword()
		if self.WispSword then
			self.WispSword:Destroy()
			self.WispSword = nil
		end
	end
	function wispTab:SwordUpdate()
		while not self.ShouldDie do
			-- We only return to this bit while we're not in combat. At this point we just wait for combat.
			ScriptFunction.WaitForTimeInSeconds(.5)
			if self.InCombat then
				-- We should have just entered combat. The sword shouldn't exist so we need to spawn it, then go into the update loop.
				if not self.WispSword then
					self:NewSword()
				else 
					GUI.DisplayMessageBox("Wisp Sword already existed\nbefore entering combat") 
				end
				
				while self.InCombat and not self.ShouldDie do
					-- Sword combat update loop
					-- Error checking first
					if not self.Entity or not self.Entity:IsAlive() then
						GUI.DisplayMessageBox("Sword tried to enter combat but there's no wisp entity!\nThis may happen after loading an area while in combat.")
						while not self.Entity or not self.Entity:IsAlive() do
							self:DestroySword()
							ScriptFunction.WaitForTimeInSeconds(1)
						end
						-- Wisp Entity should be back now, resume updating, and if we're still in combat create the sword.
						if self.InCombat then
							self:NewSword()
						end
					end
					-- Now for actual position update stuff. TODO: MAKE SURE IT WORKS
					local difference = self.WispTarget:GetPosition() - self.Entity:GetPosition()
					difference:Normalise()
					Physics.SetFacingVector(self.WispSword, difference)	  -- TODO: Figure out how to rotate in more than one axis cos wtf
					difference:SetZ(0) -- This prevents the sword from moving downwards
					self.WispSword:SetPosition(self.Entity:GetPosition() + (difference*1.3)) -- TODO: Get fixed distance from wisp and move the sword. 
																		  					 -- 	   difference*circumference? Why does it mostly move on the Y axis? It's like it believes it's directly above but it's not.
					if self.CurrentVFX then
						self.CurrentVFX:SetPosition(self.WispTarget:GetPosition())
					end
					coroutine.yield()
				end
				-- We just left combat or the AI has stopped, so get rid of the sword.
				if self.WispSword then
					self.WispSword:Destroy()
					self.WispSword = nil
				end
			end
		end
	end
	
	function wispTab:AreEnemiesNear()
		if SACCamera and SACCamera.NearbyFoes then
			return #CameraManager.GetFoes(SACCamera:GetMaxSearchDistanceForEnemies()) > 0 -- *sigh* Using this instead of SACCamera's nearby foes because it's not perfect.
		else
			GUI.DisplayMessageBox("SACCamera or nearbyfoes is nil!")
		end
	end
	
	-- This function gets a new target for the wisp to target and hop to.
	-- It also removes any effects from the last target and adds them to the new one.
	function wispTab:AcquireNewTarget(oldTarget)
		-- Get all enemies.
		local potentialTargets = CameraManager.GetFoes(SACCamera:GetMaxSearchDistanceForEnemies())
		-- Get a target from the list. In the future, mess around with this to acquire a custom target. Though maybe if manual targetting mode then this shouldn't even be called.
		local target
		if #potentialTargets > 0 then
			target = potentialTargets[math.random(1, #potentialTargets)] -- In the future perhaps prevent the same ent from being chosen if there's more than one.
			if target == nil or not target:IsAlive() then
				target = QuestManager.HeroEntity
				GUI.DisplayMessageBox("Wisp tried to get dead or nil enemy! Given hero instead.\nThis should NEVER happen.")
			end
		else
			-- In the future, when this happens try getting the heroes target if its relation is enemy.
			target = QuestManager.HeroEntity
		end
		if oldTarget then
			self:RemoveEffect(oldTarget, self.CurrentEffect)
		end
		self:ApplyEffect(target, self.CurrentEffect)
		return target
	end
	
	-- This function applies effects to the target entity. For now we can start with a "vulnerability" effect.
	function wispTab:ApplyEffect(target, effect)
		if target == QuestManager.HeroEntity then
			return
		end
		if effect == self.EffectEnum.VULNERABILITY and target and target:IsAlive() then
			Health.Modify(target, -Health.Get(target)/2, target)
		end
		self.CurrentVFX = Debug.CreateEntityAt("FX_CullisGate_Stage_01", "wispfx", target:GetPosition())
	end
	
	-- This function removes effects from the target entity.
	function wispTab:RemoveEffect(target, effect)
		if target == QuestManager.HeroEntity then
			return
		end
		if effect == self.EffectEnum.VULNERABILITY and target and target:IsAlive() then
			Health.Modify(target, Health.Get(target), target)
		end
		self.CurrentVFX:Destroy()
	end

	GeneralScriptManager.AddScript(wispTab)