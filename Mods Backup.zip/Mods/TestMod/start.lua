--[[
Things you should know:
1. Mod scripts are like modules. Each has its own fenv set to an empty table, and as such any definitions take place in said table.
2. Mod scripts have their metatable set to a custom table implemented by the manager. 
   This allows the mod to access things like the ModHooks table which does not exist in the global table, but instead in the metatable.
   You can also access the mod manager's table itself through "ModManager", though you probably shouldn't ever need to do this.
3. ...
--]]


ModTable = getfenv(1)
DebugText = "Started"

local passed = ...
if type(passed) == "table" then
	RandomNumber = passed.RandomNumber
else
	RandomNumber = GetRandomNumber(1000000)
end


function ModUpdate()
	local do_once = true
	
	local search = SearchTools.FilterWithEC(SearchTools.StartNewSearch("all"), Camera.GetECType())
	local results = SearchTools.GetSearchResults(search)
	local cam1 = results[1]
	local cam2 = results[2]

	while not ShouldDie do
		coroutine.yield()
		if cam1 then
			Debug.Draw3DText(cam1:GetPosition() + Physics.GetFacingVector(cam1), cam1:GetName(), 1, {DrawInFrontOfScene = true})
		end
		if cam2 then
			Debug.Draw3DText(cam2:GetPosition() + Physics.GetFacingVector(cam2), cam2:GetName(), 1, {DrawInFrontOfScene = true})
		end

		Debug.Draw3DText(QuestManager.HeroEntity:GetPosition(), DebugText, 1, {DrawInFrontOfScene = true})
		if do_once then
			do_once = false
			GUI.DisplayMessageBox("Howdy, from TestMod startup")
		end
	end
end

function OnSaveLoad()
	DebugText = "Testmod saveload called"
end
function OnHeroHit()
	DebugText = "Player was hit"
end
function OnLevelLoaded()
	DebugText = "New level has been loaded"
end

function Terminate()
	DebugText = "Mod Terminated"
	ShouldDie = true
end

function Enabled()
	DebugText = "Mod Enabled"
end

function Disabled()
	DebugText = "Mod Disabled"
	GUI.DisplayMessageBox("TestMod Was disabled.")
end

function Uninstall()
	DebugText = "Mod Uninstalled"
	ModHooks.RemoveHook("OnHeroHit", "TestModHeroHit")
	ModHooks.RemoveHook("OnEnterArea", "TestModLevelLoaded")
	GUI.DisplayMessageBox("testmod uninstalled, randomnumber is " .. tostring(RandomNumber))
	return {RandomNumber = RandomNumber}
end

ModHooks.AddHook("OnHeroHit", "TestModHeroHit", OnHeroHit, ModTable)
ModHooks.AddHook("OnEnterArea", "TestModLevelLoaded", OnLevelLoaded, ModTable)
ModHooks.AddHook("OnSaveLoad", "TestModSaveLoad", OnSaveLoad, ModTable)