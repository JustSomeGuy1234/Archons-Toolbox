--[[
This script mostly defines menu data and loot table data.
--]]

local upgrades = {
	Attentive = {Level = 0, MaxLevel = 3, Name = "Attentive"}, -- (done) Rumble when fish starts crossing
	Disorientation = {Level = 0, MaxLevel = 5, Name = "Disorientation"}, -- (precision done) Stun/control meter, or force fish crossing on start
	LuckyHook = {Level = 0, MaxLevel = 5, Name = "Lucky Hook"}, -- (done) Higher drop rate of loot (20/40/60/80/100%)
	Lurer = {Level = 0, MaxLevel = 3, Name = "Lurer"}, -- Use good fish as bait (reduces amount of time between fish? already have luckyhook for loot chance, and it wouldn't make sense)
													   -- Since only t3 and t5 fish are bait, make them the same tier as they're both hard to get depending on location.
													   -- half wait time? from 10-20 to 5-10 seconds? Should bait save time at least equal to time spent catching the bait?
													   -- No because they should be used to grind faster. The fact that they make everything faster is potentially more valuable than the 200 gold.
	Professional = {Level = 0, MaxLevel = 5, Name = "Professional"}, -- (done) Sell stuff immediately for 80/90/100/110/120% of its value
	ReinforcedLine = {Level = 0, MaxLevel = 5, Name = "Reinforced Line"}, -- (done) 20% chance per lvl of saving a miss once
	Sedation = {Level = 0, MaxLevel = 1, Name = "Sedation", PriceMultiplier = 3}, -- (done) toss a bottle of alcohol to sedate the fish, scaling with drink rating

}

-- Todo:
--		Obviously fill in loot tables
--		Avg table values:
--			Low:	  200 Avg. Basically just fish and garbage, but with some definite upside. (wraithmarsh)
--			Medium:	  500 Avg. Good Fish Ok Loot (bowerlake, westcliff)
--			High:	  1000Avg. Rivals top tier blacksmithing (bloodstone)

-- Gold/s (roughly): 
-- At Bloodstone, max professional, max lucky hook, using cod bait: 150/s
-- Same but no lurer: 100/s

-- This is hugely outperforms 5* blacksmithing which is 75 gold/s (if you get to the max combo then fail).
-- Balance isn't a huge concern, at least once you hit bloodstone. This is kind of in line with money coming in from property, and the colosseum.


-- The loot tables are not super balanced, but an average is sampled and repeatedly tweaked for profit, xp, and utility.
local loot_tables = {
	base = {}, -- for unspecified places. generally poor.
	bwsmarket = {}, -- bad fish, jewelery
	bloodstone = {},-- top tier, best loot
	bowerlake = {}, -- good fish, ok loot
	brightwood = {},-- meh fish, xp potions
	dunecrest = {}, -- (rookridge) meh
	ravenscar = {}, -- (oakfield) mediocre but drinks
	wraithmarsh = {},--awful loot, best xp
	westcliff = {},	-- wcfish, decent money
}
local poor_weapon_table = {
	Table = true,
	Weight = 1,
	-- ObjectInventoryCrossbow_Light_Rusty = {Weight = .7},
	ObjectInventoryCrossbow_Light_Iron = {Weight = 1},
	-- ObjectInventoryRifle_Turret_Rusty = {Weight = .7},
	ObjectInventoryRifle_Turret_Iron = {Weight = 1},
	-- ObjectInventoryRifle_Flintlock_Rusty = {Weight = .7},
	ObjectInventoryRifle_Flintlock_Iron = {Weight = 1},
	-- ObjectInventory_L_LongSword_Rusty = {Weight = .7},
	ObjectInventory_L_LongSword_Iron = {Weight = 1},
	ObjectInventory_L_LongSword_Steel = {Weight = 1},
	ObjectInventory_L_Cutlass_Steel = {Weight = 1},
	-- ObjectInventory_L_Katana_Rusty = {Weight = .7},
	ObjectInventory_L_Katana_Iron = {Weight = 1},
	-- ObjectInventory_H_Axe_Rusty = {Weight = .7},
	ObjectInventory_H_Axe_Iron = {Weight = 1},
}
local mediocre_weapon_table = {
	Table = true,
	Weight = 1,
	ObjectInventory_L_Katana_Steel = {Weight = 1},
	ObjectInventory_L_LongSword_Steel = {Weight = 1},
	ObjectInventory_L_Cutlass_Steel = {Weight = 1},
	ObjectInventory_H_Mace_Steel = {Weight = 1},
	ObjectInventoryCrossbow_Heavy_Steel = {Weight = 1},
	ObjectInventoryRifle_Flintlock_Steel = {Weight = 1},
	ObjectInventoryPistol_Flintlock_Steel = {Weight = 1},
}
local fancy_weapon_table = {
	Table = true,
	Weight = 1,
	ObjectInventory_L_Katana_Steel = {Weight = 1},
	ObjectInventory_L_Katana_Master = {Weight = .4},
	ObjectInventory_L_LongSword_Steel = {Weight = 1},
	ObjectInventory_L_LongSword_Master = {Weight = .4},
	ObjectInventory_L_Cutlass_Steel = {Weight = 1},
	ObjectInventory_H_Mace_Steel = {Weight = 1},
	ObjectInventoryCrossbow_Heavy_Steel = {Weight = 1},
	ObjectInventoryRifle_Flintlock_Steel = {Weight = 1},
	ObjectInventoryPistol_Flintlock_Steel = {Weight = 1},
	ObjectInventoryPistol_Flintlock_Master = {Weight = .2},
}

loot_tables.base = {
	ObjectInventoryFoodAndDrinkFish_1 = {Weight = 2},
	ObjectInventoryFoodAndDrinkFish_2 = {Weight = 1},
	ObjectInventoryFoodAndDrinkFish_3 = {Weight = .3},
	ObjectInventoryFoodAndDrinkFish_4 = {Weight = .5},
	ObjectInventoryFoodAndDrinkFish_5 = {Weight = .5},
	Loot = {
		Table = true,
		Weight = 1, -- If the regional table has a loot table, then the weight of the base loot table is pretty much disregarded but the loot is still added to the pool.
		ObjectInventoryPotionHealth_1 = {Weight = 1}
	}
}
loot_tables.brightwood = {
	Loot = {
		Table = true,
		Weight = 1,
		ObjectInventoryPotionLife = {Weight = 1},
		ObjectInventoryPotionExperienceGeneral_2 = {Weight = 2},
		ObjectInventoryPotionExperienceGeneral_3 = {Weight = 2},
		ObjectInventoryPotionExperienceGeneral_4 = {Weight = 2},
		ObjectInventoryPotionExperienceGeneral_5 = {Weight = .8},
		ObjectInventoryPotionExperienceStrength_2 = {Weight = 2},
		ObjectInventoryPotionExperienceStrength_3 = {Weight = 2},
		ObjectInventoryPotionExperienceStrength_4 = {Weight = 2},
		ObjectInventoryPotionExperienceStrength_5 = {Weight = .8},
		ObjectInventoryPotionExperienceSkill_2 = {Weight = 2},
		ObjectInventoryPotionExperienceSkill_3 = {Weight = 2},
		ObjectInventoryPotionExperienceSkill_4 = {Weight = 2},
		ObjectInventoryPotionExperienceSkill_5 = {Weight = .8},
		ObjectInventoryPotionExperienceWill_2 = {Weight = 2},
		ObjectInventoryPotionExperienceWill_3 = {Weight = 2},
		ObjectInventoryPotionExperienceWill_4 = {Weight = 2},
		ObjectInventoryPotionExperienceWill_5 = {Weight = .8}
	}
	-- Avg (lucky 5, prof 5): 880
}
loot_tables.bowerlake = { -- Bower Lake is an ideal fishing spot for catching good fish. It also has augmentations from the nearby camp.
	ObjectInventoryFoodAndDrinkFish_1 = {Weight = 0},
	ObjectInventoryFoodAndDrinkFish_2 = {Weight = 1.5},
	ObjectInventoryFoodAndDrinkFish_5 = {Weight = 1},
	Loot = {
		Table = true,
		Weight = .5,
		ObjectAugmentationFire = {Weight = 2},
		ObjectAugmentationElectric = {Weight = 2},
		ObjectAugmentationWarriorScar = {Weight = 2},
		ObjectAugmentationStoneskin = {Weight = 2},
		ObjectAugmentationRichHex = {Weight = 2},
	--  Total Avg = 600 (LuckyHook 5)
	}
}

local bwsmarketloot = { -- Bowerstone Market's inhabitants are clumsy people who only become clumsier during their nights out. Expect a build-up of everything.
	Table = true,
	Weight = 1,
	ObjectInventoryGiftRing_4 = {Weight = 1},
	ObjectInventoryGiftRing_5Star = {Weight = 1},
	ObjectInventoryGiftGemJet = {Weight = 1},
	ObjectInventoryGiftGemAmethyst = {Weight = 1},
	ObjectInventoryGiftGemEmerald = {Weight = 1},
	ObjectInventoryGiftGemRuby = {Weight = 1},
	ObjectInventoryGiftGemDiamond = {Weight = 1},
	ObjectInventoryGiftJewellery_4 = {Weight = 1},
	ObjectInventoryGiftJewellery_5 = {Weight = 1},
	ObjectAugmentationFire = {Weight = 1},
	ObjectAugmentationElectric = {Weight = 1},
	ObjectAugmentationWarriorScar = {Weight = 1},
	ObjectAugmentationStoneskin = {Weight = 1},
	ObjectInventoryPotionHealth_1 = {Weight = 0},
	ObjectInventoryPotionHealth_2 = {Weight = 0},
}
loot_tables.bwsmarket = {
	ObjectInventoryFoodAndDrinkFish_1 = {Weight = 2},
	ObjectInventoryFoodAndDrinkFish_2 = {Weight = 1},
	ObjectInventoryFoodAndDrinkFish_5 = {Weight = 0.3},
	Loot = bwsmarketloot,	
	-- Avg (prof 5, lucky 5): 1100
}
-- Add the mediocre_weapon_table items to the markets main table 
for k,v in pairs(mediocre_weapon_table) do
	if k ~= "Weight" then
		loot_tables.bwsmarket.Loot[k] = v
	end
end
bwsmarketloot = nil



loot_tables.ravenscar = { -- Oakfield, home of the famous Sandgoose, suffers from a highly alcoholic water supply.
	Loot = {
		Table = true,
		Weight = 1,
		ObjectInventoryFoodAndDrinkAlcoholWine_1 = {Weight = 3},
		ObjectInventoryFoodAndDrinkAlcoholWine_2 = {Weight = 3},
		ObjectInventoryFoodAndDrinkAlcoholWine_3 = {Weight = 3},
		ObjectInventoryFoodAndDrinkAlcoholWine_4 = {Weight = 2},
		ObjectInventoryFoodAndDrinkAlcoholWine_5 = {Weight = 1},
		ObjectInventoryFoodAndDrinkAlcoholBeer_1 = {Weight = 3},
		ObjectInventoryFoodAndDrinkAlcoholBeer_2 = {Weight = 3},
		ObjectInventoryFoodAndDrinkAlcoholBeer_3 = {Weight = 3},
		ObjectInventoryFoodAndDrinkAlcoholBeer_4 = {Weight = 2},
		ObjectInventoryFoodAndDrinkAlcoholBeer_5 = {Weight = 1},
		ObjectInventoryFoodAndDrinkAlcoholSpirits_1 = {Weight = 3},
		ObjectInventoryFoodAndDrinkAlcoholSpirits_2 = {Weight = 3},
		ObjectInventoryFoodAndDrinkAlcoholSpirits_3 = {Weight = 3},
		ObjectInventoryFoodAndDrinkAlcoholSpirits_4 = {Weight = 2},
		ObjectInventoryFoodAndDrinkAlcoholSpirits_5 = {Weight = 1}
	}
}
loot_tables.wraithmarsh = {
	ObjectInventoryFoodAndDrinkCrunchyChick = {Weight = 2},
	ObjectInventoryCondom = {Weight = 2},
	ObjectInventoryFoodAndDrinkFish_5 = {Weight = 0},
	Loot = {
		Table = true,
		Weight = .7,
		ObjectAugmentationEvilHex = {Weight = 1},
		ObjectAugmentationFearfulHex = {Weight = 3}, 
		ObjectAugmentationWarriorLeech = {Weight = 1},

		-- Health potion removal. Scary innit?
		ObjectInventoryPotionHealth_1 = {Weight = 0},
		ObjectInventoryPotionHealth_2 = {Weight = 0}
	}
}
loot_tables.westcliff = {
	ObjectInventoryFoodAndDrinkFish_1 = {Weight = .5},
	ObjectInventoryFoodAndDrinkFish_2 = {Weight = .5},
	ObjectInventoryFoodAndDrinkFish_3 = {Weight = 1},
	ObjectInventoryFoodAndDrinkFish_4 = {Weight = 0},
	Loot = {Table = true, Weight = 1} -- 1 weight
}
for k,v in pairs(poor_weapon_table) do
	if k ~= "Weight" then
		loot_tables.westcliff.Loot[k] = v
	end
end
for k,v in pairs(mediocre_weapon_table) do
	if k ~= "Weight" then
		loot_tables.westcliff.Loot[k] = v
	end
end


loot_tables.bloodstone = {
	ObjectInventoryFoodAndDrinkFish_1 = {Weight = 2},
	ObjectInventoryFoodAndDrinkFish_3 = {Weight = .4},
	ObjectInventoryFoodAndDrinkFish_4 = {Weight = .6},
	ObjectInventoryFoodAndDrinkFish_5 = {Weight = .4},
	ObjectInventoryCondom = {Weight = .3},
	Loot = fancy_weapon_table -- 1 weight
	-- total: (lucky 5, prof 5) 1800 avg
}

function SampleLoot(region, samples)
	local total_loot = {}
	for i=1,samples do
		local item_name, item_value = GetDropFromTable(LootTables[region], LootTables["base"])
		
		if item_name == "Loot" then
			item_name, item_value = GetDropFromTable(item_value, LootTables["base"].Loot)
		end

		if total_loot[item_name] then
			total_loot[item_name] = total_loot[item_name] + 1
		else
			total_loot[item_name] = 1
		end
	end
	local final_loot = {}
	local total_value = 0
	for item_name,count in pairs(total_loot) do
		local item_value = GDB.GetRecord(item_name):GetRecord("ShopItemComponent"):GetS32("BasePrice")
		local stack_value = item_value * count
		total_value = total_value + stack_value
		final_loot[item_name .. ": " .. tostring(count) .. " : " .. tostring(stack_value)] = "item"
	end
	final_loot["Total Value: " .. tostring(total_value) .. "\nAverage: " .. tostring(math.floor(total_value / samples))] = "_final"
	if ModMisc.DisplayAllKeys then
		ModMisc.DisplayAllKeys(final_loot)
	else
		GUI.DisplayMessageBox("no DisplayAllKeys func yet")
	end
	return final_loot
end


function GetAvailableAlcoholMenuEntries()
	local drink_options = {}
	local function add_items(base_item, highest_rating)
		for i=1,highest_rating do
			local drink = base_item .. tostring(i)
			if Inventory.GetNumberOfItemsOfType(QuestManager.HeroEntity, drink) > 0 then
				drink_options[#drink_options+1] = MCM.NewActionEntry(drink, true, ThrowDrink, drink)
			end
		end
	end
	add_items("ObjectInventoryFoodAndDrinkAlcoholBeer_", 5)
	add_items("ObjectInventoryFoodAndDrinkAlcoholWine_", 5)
	add_items("ObjectInventoryFoodAndDrinkAlcoholSpirits_", 5)
	return drink_options
end


local function GetMainMenuEntries()
	local function get_upgrades_title()
		return "Fishing Upgrades | XP: " .. tostring(CurrentXP)
	end
	local function reload_mod()
		ModManager.GetModHandleWithName("FishingMod").VersionMinor = GetRandomNumber(10000000)
		ModManager.ReadInstalledMods()
	end

	local herohasrequiredlurerlevel = Upgrades.Lurer.Level > 0
	local current_bait = BaitEnum[SelectedBait]
	local bait_amount = Inventory.GetNumberOfItemsOfType(QuestManager.HeroEntity, current_bait.Item)
	local bait_option_text = current_bait.CustomName
	if not herohasrequiredlurerlevel then
		bait_option_text = Upgrades.Lurer.Name ..  " Upgrade Not Unlocked"
	elseif current_bait == BaitEnum[1] then
		if not HeroHasAnyBait() then
			bait_option_text = bait_option_text .. ": (None left)"	
		end
	else
		bait_option_text = bait_option_text .. ": " .. tostring(bait_amount)
	end

	return {
		MCM.NewActionEntry("Start Fishing", true, EnterFishingSetupMode, nil),
		MCM.NewActionEntry("Upgrades", true, MCM.OpenMenu, {get_upgrades_title, GetUpgradeMenuEntries}),
		MCM.NewActionEntry(bait_option_text, herohasrequiredlurerlevel and HeroHasAnyBait(), CycleBait, nil),
		MCM.NewActionEntry("Help", true, MCM.OpenMenu, {"Help Menu", GetHelpMenuEntries}),
		MCM.NewActionEntry("DEBUG: Reload Mod", true, reload_mod, nil),
	}
end
local function GetUpgradeMenuEntries()
	local entries = {}
	for k,v in pairs(upgrades) do
		local cost = GetXPRequiredForUpgrade(v)
		local cost_text = ""
		if v.Level < v.MaxLevel then
			cost_text = " Cost: " .. tostring(cost)
		end
		local entry = MCM.NewActionEntry (
			v.Name .. ": " .. tostring(v.Level) .. "/" .. tostring(v.MaxLevel) .. cost_text,
			(v.Level < v.MaxLevel) and (CurrentXP >= (v.Level + 1) * 100), 
			BuyUpgrade, {v}
		)
		entries[#entries + 1] = entry
	end
	return entries
end

function GetMCMEntry()

end

function GetHelpMenuEntries()
	local function show_mb_and_wait(display_text, time, show_page)
		-- If display_text is not table put it into one
		local pages = ( type(display_text) == "table" and display_text ) or {display_text}

		for i=1,#pages do
			GUI.DisplayMessageBox(pages[i] .. (show_page and "\n\nPage " .. tostring(i) .. "/" .. tostring(#pages) or ""))
			ScriptFunction.WaitForTimeInSeconds(time or 0.5)
		end
	end

	return {
		MCM.NewActionEntry("Fishing Mode", true, show_mb_and_wait, 
			"When you enter <b>Fishing Mode</b> the expression meter will appear. You are free to move around in this mode.\n\n" ..
			"You can fish from where you're standing if the meter is <s2>green</s2>, but not if it's <s1>red</s1>.\n\n" ..
			"Press <a_img> to start fishing. Press <b_img> to exit Fishing Mode.\n" ..
			"Be sure to face the water you're trying to fish in. When you stop fishing you will be put back into Fishing Mode."
		),
		MCM.NewActionEntry("Fishing", true, show_mb_and_wait, 
			"Fishing is simple. The pip stays in the middle of the meter while the fish sways back and forth on one side just out of reach. "..
			"After some time the fish will cross over the middle, giving you a moment to catch it if you act fast enough. The meter will turn green as this happens.\n\n" ..
			"More valuable fish and items have a higher catch difficulty. More difficult fish are much harder to catch, but grant more xp. " ..
			"If you're struggling to catch a fish you should spend your XP on an upgrade or two.\n\n" .. 
			"TIP: It is better to reel in sooner rather than later."
		),
		MCM.NewActionEntry("Upgrades & XP", true, show_mb_and_wait, {
			{"Catching an item or fish gives you XP depending on the difficulty of the catch and the region you're in.\n\n" ..
			  "Upgrades make fishing a lot easier and a lot nicer so if you're struggling see if these help..."
			 ,
			 "<bullet.img>Attentive:\n33% Chance per level for controller rumble when the fish starts crossing.\n\n"..
			 "<bullet.img>Disorientation:\n20% Chance per level to make the fish cross immediately on start.\n\n" ..
			 "<bullet.img>Lucky Hook:\nIncreases the chance of hitting the loot table by 20% per level.\n\n"..
			 "<bullet.img>Lurer:\nUse fish as bait to greatly reduce the time it takes to find a fish.\n1: Magnificent Tuna | 2: Westcliff Cod | 3: Save Bait",
			 "<bullet.img>Reinforced Line:\n20% Chance per level to not lose the fish if you miss. Activates once per fish.\n\n"..
			 "<bullet.img>Professional:\nAbility to sell a caught item immediately for 80/90/100/110/120% of its value.\n\n"..
			 "<bullet.img>Sedation:\nDebilitate your fish by tossing alcohol into the water. Potentially halve its speed depending on drink rating. Press <x_img> to activate."
			}, 0.3, true}
		),
		MCM.NewActionEntry("Regions", true, show_mb_and_wait,
			{{
			"Most regions have unique drop tables or mechanics which you can read about in the following pages. They have a huge impact on your overall profits and experience gain.",
			"Bowerlake is a prime spot for top tier fish. Perhaps you'll be lucky enough to catch an augment too.\n\n"..
			"Westcliff, home of the Westcliff Cod, is a great place to catch... Westcliff Cod. A recent incident involving the skin of an exotic fruit has sent a small trading wagon into the sea. The wagon happened to be transporting the items of unsuccessful Crucible contestants.\n\n"..
			"Oakfield's water supply, despite being located next to an ocean, is polluted with alcohol. Thankfully it's still bottled.\n\n",
			"Wraithmarsh's inherent danger has bred fish that are incredibly resilient and hard to catch, making it a perfect place to become more experienced. Just don't expect to catch anything nice.\n\n"..
			"Bloodstone is known for its inhospitable people, and its equally inhospitable fish. Unsurprisingly, not many even let Bloodstone enter their minds. This inactivity has caused an incredible build up of lost valuables over the years, giving you the chance to catch the waterlogged belongings of felled duelists and fallen drunkards.\n\n"
			}}
		),
		MCM.NewActionEntry("Bait", true, show_mb_and_wait,
			{{
				"The bait skill lets you use certain fish to greatly reduce the time it takes to get a catch.\n\n"..
				"Level 1: Magnificent Tuna - Good Bait\nLevel 2: Westcliff Cod - Perfect Bait\nLevel 3: 50% Chance to save the fish"
				,
				"Instructions:\nWhile waiting for a fish you can press A to cycle through available baits. The name of the bait you have selected will be shown at the bottom above the health bar.\n\n"..
				"The health bar indicates how much time you have to select your bait before it's locked in. If you stop fishing at any time you keep your bait."
			}}
		)
	}
end


return loot_tables, upgrades, GetMainMenuEntries, GetUpgradeMenuEntries


--[[
Drop table logic:
	Base table contains Fish 1-5. Say Fish 5 is 1 weight.
	region table creates a key for Fish 5. Fish 5 is 2 (doubling the likelyhood)
	same table creates a key for Fish 1. Fish 1 is 0 (removing all likelyhood)

	Loot function does this:
	Iterate through region table and add weights to total.
	Iterate through base table and add weights to total IF item name is not also stored in region table.
	Generate random item number with max of weight total
	Iterate through region table and see if each item's weight is above item number
	If not, iterate through base table and see if item weight is above item number

--]]