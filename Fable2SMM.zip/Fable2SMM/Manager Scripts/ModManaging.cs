﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Diagnostics;
using System.Windows;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;

namespace Fable2SMM
{

    public static class ModManaging
    {
        public static bool RealtimeSaving = false;
        public static bool InstallIsDirty = false;
        public static string GameFolder
        {
            get => _gameFolder;
            set 
            { 
                if (value == "/" || value == "\\" || string.IsNullOrEmpty(value))
                {
                    _gameFolder = value;
                    EnumerateAllMods();
                    OnGameFolderChanged(); // This needs to be called to empty the listview after being reset
                    return;
                }
                if (!value.EndsWith(@"\") && !value.EndsWith("/")) value += @"\";
                if (!Directory.Exists(value))
                {
                    System.Media.SystemSounds.Hand.Play();
                    MessageBox.Show("Game Path does not exist!");
                    return;
                }

                // TODO: Add some error handling here. There's a decent chance this will throw an error if set to something that doesn't have the runner installed. Obviously this will need to happen TO install the runner.
                if (!Directory.Exists(Path.Combine(value, @"Data\")))
                {
                    MessageBox.Show("Invalid game path. The given folder does not contain /data/\n" + Path.Combine(value, @"Data\"));
                    return;
                }

                if (InstallIsDirty)
                {
                    MessageBoxResult result = MessageBox.Show("Would you like to save changes to the current installation before swapping?", "Save Changes?", MessageBoxButton.YesNoCancel);
                    if (result == MessageBoxResult.Yes)
                        SaveChanges();
                    else if (result == MessageBoxResult.Cancel)
                        return;
                }
                _gameFolder = value; OnGameFolderChanged(); Trace.WriteLine("Changing GameFolder to " + value);
                AppSettings.SettingsAreDirty = true;
                ModManaging.InstallIsDirty = false;

                if (File.Exists(Mod.InstalledModsPath))
                {
                    LuaParsing.ReadInstalledModsIntoContentAndDict();
                    EnumerateAllMods();
                }
                if (File.Exists(DirManifest.DirManifestPath))
                {
                    DirManifest.CurrentDirManifestContent = File.ReadAllText(DirManifest.DirManifestPath);
                }
                else
                {
                    MessageBox.Show("There's no dir.manifest file in your game installation. This will cause problems.");
                    Trace.WriteLine("dir.manifest not found! At: " + DirManifest.DirManifestPath);
                }

                string currentGamescriptsHash = GetFileHash(Gamescripts.GamescriptsPath);
                if (currentGamescriptsHash == Gamescripts.GamescriptsManagerHash)
                    Gamescripts.CurrentGamescriptsStatus = GamescriptsStatus.MANAGERINSTALLED;
                else if (currentGamescriptsHash == Gamescripts.GamescriptsOriginalHash)
                    Gamescripts.CurrentGamescriptsStatus = GamescriptsStatus.ORIGINAL;
                else if (!string.IsNullOrEmpty(currentGamescriptsHash))
                    Gamescripts.CurrentGamescriptsStatus = GamescriptsStatus.MODIFIED;
                else
                    Gamescripts.CurrentGamescriptsStatus = GamescriptsStatus.MISSING;
                    
            }
        }
        static string _gameFolder = "";
        public static event EventHandler GameFolderChanged;
        private static void OnGameFolderChanged()
        { GameFolderChanged?.Invoke(null, EventArgs.Empty); }

        public static string DataFolder { get { return Path.Combine(GameFolder, @"Data\"); }}
        public static string ScriptsFolder { get { return Path.Combine(DataFolder, @"scripts\"); } }
        public static string ModsFolder { get { return Path.Combine(ScriptsFolder, @"Mods\"); } }
        public static string RunnerFolder { get { return Path.Combine(ScriptsFolder, @"Mod Manager\"); } }
        public const string ScriptsZipPath = "./resources/Mod Manager Scripts.zip";
        public const string RunnerFileName = @"runner.lua";

        public static string unchangedInstalledmodsHash = "";

        public static ObservableCollection<Mod> ModList { get { return _modList; } set { _modList = value; ModListChanged?.Invoke(null, EventArgs.Empty); Trace.WriteLine("Setting ModList to something else"); } }
        private static ObservableCollection<Mod> _modList = new ObservableCollection<Mod>();
        public static event EventHandler ModListChanged;

        public static string CurrentInstalledModsContent { get { return _currentInstalledModsContent; } set { _currentInstalledModsContent = value; OnInstalledModsContentChanged(EventArgs.Empty); } }
        static string _currentInstalledModsContent = "";
        public static event EventHandler CurrentInstalledModsContentChanged;
        private static void OnInstalledModsContentChanged(EventArgs e)
        {CurrentInstalledModsContentChanged?.Invoke(null, e);}

        public static Dictionary<string, object> InstalledModsFileDict { get { return _installedModsDict; } set { _installedModsDict = value; } }
        static Dictionary<string, object> _installedModsDict = new Dictionary<string, object>();


        public static void SaveChanges()
        {
            // TODO: Error handling
            if (File.Exists(Mod.InstalledModsPath))
                File.WriteAllText(Mod.InstalledModsPath, ModManaging.CurrentInstalledModsContent);
            if (File.Exists(DirManifest.DirManifestPath) && DirManifest.CurrentDirManifestContent.Length > 0)
                File.WriteAllText(DirManifest.DirManifestPath, DirManifest.CurrentDirManifestContent);
            string settingsContent = System.Text.Json.JsonSerializer.Serialize(AppSettings.Inst, ManifestParser.JsonOptions);
            File.WriteAllText(AppSettings.SettingsPath, settingsContent);
        }

        /// <summary>
        /// Compares installedmods and loose mods in the Mods folder to see what needs updating/removing.
        /// </summary>
        /// <remarks>Perhaps this method shouldn't exist, and instead mods should only be marked as different when something changes (files are missing, or an intentional act through the manager)</remarks>
        /// <param name="installedmodsDict"></param>
        /// <returns>
        /// <list type="bullet">
        /// <item>outOfDateMods - Mods with a differing version in the folder</item>
        /// <item>neverInstalledMods - Mods that are found in folder but not installedmods</item>
        /// <item>uninstalledMods - Mods that are found within installedmods but not folder</item>
        /// </list>
        /// </returns>
        /// 
        public static void EnumerateAllMods()
        {
            if (string.IsNullOrEmpty(CurrentInstalledModsContent))
                //throw new Exception("CurrentInstalledModsContent variable is empty!");
                return;
            if (InstalledModsFileDict == null)
                throw new Exception("InstalledModsFileDict is null, but CurrentInstalledModsContent is not!");

            List<Mod> installedmodsList = LuaParsing.GetAllModsFromInstalledModsFileDict(InstalledModsFileDict);
            List<Mod> loosemodsList = ManifestParser.ConvertManifestsToMods(ManifestParser.GetAllManifestsInModFolder());
            List<Mod> FinalModList = new List<Mod>();

            Dictionary<string, Mod> installedModsDict = new Dictionary<string, Mod>();

            foreach (Mod installedmod in installedmodsList)
            {
                if (installedModsDict.ContainsKey(installedmod.NameID))
                    throw new Exception("Somehow a mod with the same nameID was found twice! " + installedmod.NameID);
                installedModsDict.Add(installedmod.NameID, installedmod);

                installedmod.IsDeleted = !Directory.Exists(ModsFolder + installedmod.NameID);
                if (installedmod.IsDeleted)
                {
                    // TODO: This will show two prompts.
                    // TODO: Add an ignore option to prevent any further prompts in the config. Or something.
                    if (MessageBox.Show("The folder for " + installedmod.NameID + " is missing. Delete the mod?", "Missing Files", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        installedmod.DeleteModCompletely();
                        continue;
                    }
                }
                FinalModList.Add(installedmod);
            }

            foreach (Mod looseMod in loosemodsList)
            {
                if (installedModsDict.ContainsKey(looseMod.NameID))
                {
                    Mod installedmod = installedModsDict[looseMod.NameID];

                    // Found existing mod
                    if (installedmod.VersionMajor != looseMod.VersionMajor || installedmod.VersionMinor != looseMod.VersionMinor)
                    {
                        installedmod.IsOutOfDate = true;
                        Console.WriteLine("Versions differ for mod: " + installedmod.NameID);
                    }

                }
                else
                    FinalModList.Add(looseMod);

            }

            ModList = new ObservableCollection<Mod>(FinalModList);
            // We now have every mod processed from both lists, let's concat them while making sure there's no duplicates and that they retain their management status'

        }

        static void UpdateAllOutOfDateMods()
        {
            EnumerateAllMods();

            foreach (Mod oldMod in ModList)
            {
                Console.WriteLine("Updating " + oldMod.NameID);
                if (oldMod.IsOutOfDate)
                    oldMod.UpdateMod();
            }
        }



        public static void WriteToInstalledMods(string content)
        {
            if (!Directory.Exists(Mod.InstalledModsPath.Substring(0, Mod.InstalledModsPath.LastIndexOf('\\'))))
                throw new Exception("Mod Manager folder doesn't exist. TODO: Handle this properly");
            File.WriteAllText(Mod.InstalledModsPath, content);
        }


        

        public static string GetFileHash(string filePath)
        {
            string curFileHashString;
            using (SHA256 sha = SHA256.Create())
            {
                if (File.Exists(filePath))
                {
                    using (FileStream stream = File.OpenRead(filePath))
                    {
                        byte[] curFileHashBytes = sha.ComputeHash(stream);
                        curFileHashString = string.Join("", curFileHashBytes.Select(x => x.ToString("X2")));
                    }
                }
                else
                    return "";
            }
            return curFileHashString;
        }

        public static string GetRunnerVersion()
        {
            string RunnerPath = RunnerFolder + RunnerFileName;
            if (!File.Exists(RunnerPath))
                throw new Exception($"Failed to find the runner file at\n`{RunnerPath}`");
            string fileContent = File.ReadAllText(RunnerPath);
            if (fileContent.Length <= 0)
                throw new Exception("runner file is empty! (no lines)");

            Regex versionRegex = new Regex(@"Version = ([\d\.]+)", RegexOptions.Singleline);
            Match match = versionRegex.Match(fileContent);

            if (match.Success)
            {
                if (match.Groups.Count < 1)
                {
                    Trace.WriteLine("Error: (Updating) Caught Version line but not version number!");
                    return "";
                }
                string ver = match.Groups[1].Value;
                Trace.WriteLine("Got installed runner version: " + ver);
                return ver;
            }
            else
            {
                Trace.WriteLine("Error: Failed to get Version from Runner file!");
                return "";
            } 
        }

        public static void WriteFilesToModFolders(Dictionary<string, byte[]> files)
        {
            bool wantsToOverwrite = false;
            foreach (string relativeFilePath in files.Keys)
            {
                string folderPath = Path.Combine(ModsFolder, Path.GetDirectoryName(relativeFilePath));
                string fullFilePath = Path.Combine(ModsFolder, relativeFilePath);
                if (Directory.Exists(folderPath))
                    Console.WriteLine($"A mod with the folder {folderPath} exists, but this is probably okay.");
                else
                    Directory.CreateDirectory(folderPath);
                if (!wantsToOverwrite && File.Exists(fullFilePath))
                {
                    Console.WriteLine($"Also, a file already exists here. nWould you like to update? y/n");
                    if (Console.ReadKey(false).Key != ConsoleKey.Y)
                        return;

                    wantsToOverwrite = true;
                }

                File.WriteAllBytes(fullFilePath, files[relativeFilePath]);
            }
        }

        public static Dictionary<string, byte[]> GetZipFileContents(string zipPath)
        {
            Dictionary<string, byte[]> files = new Dictionary<string, byte[]>();

            using (Stream fs = File.OpenRead(zipPath))
            {
                ZipArchive archive = new ZipArchive(fs);
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    byte[] filecontent = new byte[entry.Length];
                    using (Stream entryStream = entry.Open())
                    {
                        entryStream.Read(filecontent, 0, filecontent.Length);
                    }
                    files.Add(entry.FullName, filecontent);
                }
            }
            return files;
        }
        public static (Mod, string manifestContent, Dictionary<string, byte[]>) GetModFromZip(string zipPath)
        {
            Mod modFromManifest = null;
            string manifestContent = "";
            var files = GetZipFileContents(zipPath);
            foreach (string filePath in files.Keys)
            { 
                if (filePath.Split(new char[] { '/', '\\' }).Contains("modmanifest.json"))
                {
                    string contentString = ASCIIEncoding.ASCII.GetString(files[filePath]);
                    modFromManifest = ManifestParser.ConvertManifestToMod(contentString);
                    manifestContent = contentString;
                }
            }
            if (modFromManifest == null)
                throw new Exception("Failed to find mod manifest from zip file " + zipPath);
            return (modFromManifest, manifestContent, files);
        }
        public static Mod InstallModFromZip(string zipPath)
        {
            (Mod zipMod, string manifestContent, var zipFilesDict) = GetModFromZip(zipPath);
            WriteFilesToModFolders(zipFilesDict);
            if (LuaParsing.IsModInInstalledMods(zipMod.NameID))
            {
                Mod existingMod = ModList.Where(x => x.NameID == zipMod.NameID).First();
                if (existingMod == null)
                    throw new NullReferenceException("Mod is already in InstalledMods but can't be found in the ModList to update???\nI think I did something stupid here so this error may be made in error.");
                existingMod.UpdateMod();
                return existingMod;
            }
            zipMod.InstallModIntoInstalledModsAndAddToList(manifestContent);
            return zipMod;
        }

        public static (Mod, string, Dictionary<string, byte[]>) GetModFromFolder(string passedPath)
        {
            string folderPath = passedPath;
            if (!folderPath.EndsWith("/") || !folderPath.EndsWith("\\"))
                folderPath += "\\";
            string modManPath = Path.Combine(folderPath + "modmanifest.json");
            if (!File.Exists(modManPath))
            {
                MessageBox.Show("Folder doesn't contain a mod manifest: " + folderPath);
                return (null, null, null);
            }

            string modManContent = File.ReadAllText(modManPath);
            Mod mod = ManifestParser.ConvertManifestToMod(modManContent);
            Dictionary<string, byte[]> fileDict = new Dictionary<string, byte[]>();


            string[] fullPaths = Directory.GetFiles(folderPath, "*", SearchOption.AllDirectories);
            foreach (string fullpath in fullPaths)
            {
                byte[] content = File.ReadAllBytes(fullpath);
                string relPath = fullpath.Replace(folderPath.Replace('/', '\\'), "");
                fileDict.Add(relPath, content);
            }



            return (mod, modManContent, fileDict);
        }
        public static Mod InstallModFromFolder(string folderPath)
        {
            (Mod folderMod, string modManContent, Dictionary<string, byte[]> fileDict) = GetModFromFolder(folderPath);
            if (folderMod == null)
                return null;
            if (LuaParsing.IsModInInstalledMods(folderMod.NameID))
            {
                Mod existingMod = ModList.Where(x => x.NameID == folderMod.NameID).First();
                if (existingMod == null)
                    throw new NullReferenceException("Mod is already in InstalledMods but can't be found in the ModList to update???\nI think I did something stupid here so this error may be made in error.");
                existingMod.UpdateMod();
                return existingMod;
            }
            else
            {
                WriteFilesToModFolders(fileDict);
                folderMod.InstallModIntoInstalledModsAndAddToList(modManContent);
                return folderMod;
            }
        }

        public static void InstallRunner()
        {
            if (!File.Exists(ScriptsZipPath))
            {
                MessageBox.Show("ModManagerScripts.zip is missing from the manager's resource folder!\nRedownload the mod manager to fix this.", "Missing File", MessageBoxButton.OK, MessageBoxImage.Hand);
                return;
            }    


            string currentGamescriptsHash = GetFileHash(Gamescripts.GamescriptsPath);
            bool gamescriptsExists = File.Exists(Gamescripts.GamescriptsPath);
            bool gamescriptsIsOriginal = currentGamescriptsHash == Gamescripts.GamescriptsOriginalHash;
            bool gamescriptsHasManager = currentGamescriptsHash == Gamescripts.GamescriptsManagerHash;
            string currentBackupHash = GetFileHash(Gamescripts.GamescriptsBackupPath);
            bool backupExists = File.Exists(currentBackupHash);
            bool backupIsOriginal = currentBackupHash == Gamescripts.GamescriptsOriginalHash;
            bool backupHasManager = currentBackupHash == Gamescripts.GamescriptsManagerHash;

            // Make sure the gamescripts_r bnk is patchable, make a backup, or restore one if available.
            // TODO: Add an option to override the patching checks
            if (gamescriptsExists)
            {
                // Gamescripts is original and there's no backup
                if (gamescriptsIsOriginal && !backupExists)
                {
                    File.Copy(Gamescripts.GamescriptsPath, Gamescripts.GamescriptsBackupPath);
                    Gamescripts.CurrentGamescriptsStatus = GamescriptsStatus.ORIGINAL;
                }
                // Gamescripts is original, backup exists but is not original
                else if (gamescriptsIsOriginal && backupExists && !backupIsOriginal)
                {
                    if (MessageBox.Show("The gamescripts_r.bnk backup is not original. Would you like to overwrite it with the original version?", "Unoriginal backup", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                    {
                        File.Copy(Gamescripts.GamescriptsPath, Gamescripts.GamescriptsBackupPath);
                    }
                    Gamescripts.CurrentGamescriptsStatus = GamescriptsStatus.ORIGINAL;
                }
                else if (!gamescriptsIsOriginal && !gamescriptsHasManager)
                {
                    if (backupExists && (backupIsOriginal || backupHasManager))
                    {
                        if (MessageBox.Show("Current gamescripts_r.bnk is not compatible, but the backup is. Would you like to restore the backup?", "Incompatible File", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                        {
                            File.Copy(Gamescripts.GamescriptsBackupPath, Gamescripts.GamescriptsPath);
                            if (backupHasManager)
                                gamescriptsHasManager = true;
                            else if (backupIsOriginal)
                                gamescriptsIsOriginal = true;
                        }

                    }
                }
            }
            // Neither gamescripts nor backup exists
            else if (!gamescriptsExists && !backupExists)
            {
                MessageBox.Show("gamescripts_r.bnk is missing from the game directory, and there is no backup.", "Missing File", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            // Gamescripts is not suitable or it's missing but there is a backup, original or otherwise
            else if ((!gamescriptsExists || (!gamescriptsIsOriginal && !gamescriptsHasManager)) && backupExists)
            {
                if ((backupIsOriginal || backupHasManager) && MessageBox.Show("gamescripts_r.bnk is missing or incompatible.\n\nHowever, a suitable backup exists. Would you like to restore it?", "Missing File & Corrupt Backup",
                                                                            MessageBoxButton.YesNo, MessageBoxImage.Error) == MessageBoxResult.Yes)
                {
                    File.Copy(Gamescripts.GamescriptsBackupPath, Gamescripts.GamescriptsPath);
                    gamescriptsExists = true;
                    gamescriptsIsOriginal = backupIsOriginal;
                    gamescriptsHasManager = backupHasManager;

                }
            }

            if (gamescriptsIsOriginal)
                Gamescripts.CurrentGamescriptsStatus = GamescriptsStatus.ORIGINAL;
            else if (gamescriptsHasManager)
                Gamescripts.CurrentGamescriptsStatus = GamescriptsStatus.MANAGERINSTALLED;
            else
                Gamescripts.CurrentGamescriptsStatus = GamescriptsStatus.MODIFIED;

            // Extract mod manager/runner scripts
            ExtractRunnerScripts();

            // By now the bnk is either original, already patched, or the user has declined to use a compatible bnk. 
            if (gamescriptsIsOriginal || (!gamescriptsHasManager && gamescriptsExists && MessageBox.Show(
                "You are using a probably-incompatible gamescripts_r.bnk file. Would you like to try patching anyway? This may break your game."
                ) == MessageBoxResult.Yes))
                    Patching.Patcher.Patch(Gamescripts.GamescriptsPath, "./looseresources/Fable2ModManager.patch");



            // TODO: Modify this so that the manager scripts aren't added by the forced file, and are instead added automatically.
            if (File.Exists(DirManifest.DirManifestForcedPath))
            {
            replacemanifestloop:
                Console.WriteLine("\n\nYou have an old dir.forced.manifest file. Would you like to overwrite it?\nIf you have customized it, copy the lines somewhere safe and reinsert them after install." +
                    "\nIf you're unsure, or are updating and already have it backed up, press Y. Otherwise, press N." +
                    "\nNOTICE: If you're updating you really should press Y, as the manager uses the forced file for new manager-related files.");
                if (Console.ReadKey().Key == ConsoleKey.Y)
                    File.Copy(Gamescripts.GamescriptsPath, Gamescripts.GamescriptsBackupPath, true);
                else if (Console.ReadKey().Key != ConsoleKey.N)
                    goto replacemanifestloop;
            }
            else
                File.Copy(Gamescripts.GamescriptsPath, Gamescripts.GamescriptsBackupPath);
            // TODO: Test this
            DirManifest.AddForcedFilesToDirManifest();
            File.WriteAllText(DirManifest.DirManifestPath, DirManifest.CurrentDirManifestContent);
        }
        public static void ExtractRunnerScripts()
        {
            string zipFolder = Path.GetDirectoryName(ScriptsZipPath);
            if (!Directory.Exists(zipFolder) || !File.Exists(ScriptsZipPath))
            {
                MessageBox.Show("The runner zip file is missing!\n\nThis should have been included with the manager. Redownload it to fix this.", "Missing File", MessageBoxButton.OK, MessageBoxImage.Hand);
                Trace.WriteLine("Error: ScriptsZipPath (or the resources folder) is missing!");
                return;
            }
            ZipArchive modManagerScripts = new ZipArchive(File.OpenRead(ScriptsZipPath));
            foreach (ZipArchiveEntry entry in modManagerScripts.Entries)
            {
                string finalEntryPath = ScriptsFolder + entry.FullName;
                string finalEntryFolder = Path.GetDirectoryName(finalEntryPath);

                if (entry.Name == Mod.InstalledModsName && File.Exists(Mod.InstalledModsPath))
                    continue;

                byte[] buffer;
                Stream entryStream = entry.Open();
                entryStream.Read(buffer = new byte[entry.Length], 0, (int)entry.Length);
                Directory.CreateDirectory(finalEntryFolder);
                File.WriteAllBytes(finalEntryPath, buffer);
            }
            MessageBox.Show("Updated!");
        }
    }
}
