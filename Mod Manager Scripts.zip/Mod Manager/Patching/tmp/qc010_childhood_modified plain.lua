module((...), package.seeall)
QuestManager.NewQuestThread("QC010_Childhood")
Gameflow.ChildhoodVars = Gameflow.ChildhoodVars or {}
Gameflow.ChildhoodVars.PhaseTypes = CreateEnum({
  "IDLE",
  "BUSY",
  "WANTED_SEARCHING",
  "WINO_SEARCHING"
})
Gameflow.ChildhoodVars.RoseStateTypes = CreateEnum({
  "DEFAULT",
  "QC010_ROSE_SMASH",
  "QC010_ROSE_INTERACT",
  "QC010_ROSE_IDLE",
  "QC020_APPROACH",
  "QC020_ACCEPT",
  "QC020_NO_EXPRESSION",
  "QC020_NASTY_EXPRESSION",
  "QC020_ENDING_NICE",
  "QC020_ENDING_EVIL",
  "QC020_GOLD_FIRST_NICE",
  "QC020_GOLD_FIRST_EVIL",
  "QC020_END_HERO_NEAR_ALLEY",
  "QC030_APPROACH",
  "QC030_WAIT_FOR_HERO",
  "QC030_ENDING_NICE",
  "QC030_ENDING_EVIL",
  "QC030_GOLD_SECOND_NICE",
  "QC030_GOLD_SECOND_EVIL",
  "QC030_GOLD_THIRD_NICE",
  "QC030_GOLD_THIRD_EVIL",
  "QC030_GOLD_FORTH_NICE",
  "QC030_GOLD_FORTH_EVIL",
  "QC040_REX_ROSE",
  "QC040_ROSE_GET_UP",
  "QC040_ROSE_DOG",
  "QC045_MONTY_INTRO",
  "QC045_NEAR_HOUSE",
  "QC045_WAIT_DOOR",
  "QC045_ROSE_READ_LETTER",
  "QC045_DEIDRE_OPEN_DOOR",
  "QC045_DEIDRE_GOT_MONEY",
  "QC045_ENTER_HOUSE",
  "QC045_WAIT_HOUSE",
  "QC045_APPROACH_BELINDA",
  "QC045_WAIT_DOWNSTAIRS",
  "QC045_WAIT_UPSTAIRS",
  "QC045_WAIT_DOWNSTAIRS_END",
  "QC045_ENDING_NICE",
  "QC045_ENDING_EVIL",
  "QC045_GOLD_FIFTH_NICE",
  "QC045_GOLD_FIFTH_EVIL",
  "QC050_SEARCHING_INTERACT",
  "QC050_CALL_OVER",
  "QC050_APPROACH",
  "QC050_ACCEPT",
  "QC050_ROSE_START",
  "QC050_ROSE_START2",
  "QC050_ROSE_SPOT_DOG",
  "QC050_ROSE_PRAISE_DOG",
  "QC050_ARFUR_INTRO",
  "QC050_ARFUR_TARGETED_1_SHOT",
  "QC050_ARFUR_TARGETED_1_HELP",
  "QC050_ARFUR_TARGETED_1",
  "QC050_ARFUR_TARGETED_2",
  "QC050_ARFUR_TARGETED_3",
  "QC050_ARFUR_NOT_TARGETED_1",
  "QC050_ARFUR_NOT_TARGETED_2",
  "QC050_ARFUR_WALK_AWAY",
  "QC050_ROSE_RETURN",
  "QC050_NEAR_STUCK_WARRANT",
  "QC050_WARRANT_SPOTTED",
  "QC050_WARRANT_FIRST",
  "QC050_WARRANT_SECOND",
  "QC050_WARRANT_THIRD",
  "QC050_WARRANT_FORTH",
  "QC050_ENDING_NICE",
  "QC050_ENDING_EVIL",
  "QC050_GOLD_THIRD_NICE",
  "QC050_GOLD_THIRD_EVIL",
  "QC050_GOLD_FORTH_NICE",
  "QC050_GOLD_FORTH_EVIL",
  "QC055_SEARCHING_INTERACT",
  "QC055_APPROACH",
  "QC055_CLOSE_WITH_BOOZE",
  "QC055_ACCEPT",
  "QC055_NEAR_MAGPIE_ALLEY",
  "QC055_WAIT_SNEAKING",
  "QC055_FAILED_SNEAKING",
  "QC055_FAILED_SNEAKING2",
  "QC055_GOT_BOTTLE",
  "QC055_ENDING_NICE",
  "QC055_ENDING_EVIL",
  "QC055_GOLD_SECOND_NICE",
  "QC055_GOLD_SECOND_EVIL",
  "QC055_GOLD_THIRD_NICE",
  "QC055_GOLD_THIRD_EVIL",
  "QC055_FIND_MORE_WARRANTS"
})
Gameflow.ChildhoodVars.RoseRequestLock = false
Gameflow.ChildhoodVars.RoseRequestState = nil
Gameflow.ChildhoodVars.RoseRequestAck = false
function Gameflow.ChildhoodVars.RequestRoseState(req_state)
  assert(req_state, "No / nil request state passed to Rose")
  if not Gameflow.ChildhoodVars.RoseRequestLock then
    Gameflow.ChildhoodVars.RoseRequestLock = true
    Gameflow.ChildhoodVars.RoseRequestState = req_state
    coroutine.yield()
    if Gameflow.ChildhoodVars.RoseRequestAck then
      Gameflow.ChildhoodVars.RoseRequestLock = false
      Gameflow.ChildhoodVars.RoseRequestAck = false
      return true
    else
      Gameflow.ChildhoodVars.RoseRequestLock = false
      return false
    end
  else
    return false
  end
end
function Gameflow.ChildhoodVars.InvalidateRoseState(req_state)
  assert(req_state, "No / nil invalidate request state passed to Rose")
  if Gameflow.ChildhoodVars.RoseQuestState == req_state then
    Gameflow.ChildhoodVars.InvalidateRoseQuestState = true
  end
end
function Gameflow.ChildhoodVars.InitCounter()
  if not Gameflow.E3Demo2008Childhood then
    GUI.SetCounter("ChildhoodGoldCounter", "TEXT_QUEST_QC010_GOLD_10", Gameflow.ChildhoodVars.Gold)
  end
end
function Gameflow.ChildhoodVars.GiveGold()
  Sound.PlayEvent(QuestManager.HeroEntity, "SE_GOLD_PAYMENT", "")
  Gameflow.ChildhoodVars.Gold = Gameflow.ChildhoodVars.Gold + 1
  Money.Set(QuestManager.HeroEntity, Money.Get(QuestManager.HeroEntity) + 1)
  if not Gameflow.E3Demo2008Childhood then
    GUI.SetCounter("ChildhoodGoldCounter", "TEXT_QUEST_QC010_GOLD_10", Gameflow.ChildhoodVars.Gold)
  end
  if Gameflow.ChildhoodVars.Gold == 5 then
    Stats.UnlockAchievement(QuestManager.HeroEntity, EAchievementType.ACHIEVEMENT_WHIPPERSNAPPER)
  end
end
function Gameflow.ChildhoodVars.TakeGold()
  Gameflow.ChildhoodVars.Gold = Gameflow.ChildhoodVars.Gold - 1
  Money.Set(QuestManager.HeroEntity, Money.Get(QuestManager.HeroEntity) - 1)
  if not Gameflow.E3Demo2008Childhood then
    GUI.SetCounter("ChildhoodGoldCounter", "TEXT_QUEST_QC010_GOLD_10", Gameflow.ChildhoodVars.Gold)
  end
end
function Gameflow.ChildhoodVars.PayForBox()
  Sound.PlayEvent(QuestManager.HeroEntity, "SE_GOLD_PAYMENT", "")
  Gameflow.ChildhoodVars.Gold = Gameflow.ChildhoodVars.Gold - 5
  Money.Set(QuestManager.HeroEntity, Money.Get(QuestManager.HeroEntity) - 5)
  GUI.RemoveCounter("ChildhoodGoldCounter")
end
function Gameflow.ChildhoodVars.HideCounters()
  GUI.RemoveCounter("ChildhoodGoldCounter")
  if QuestTracker.IsActive(QuestManager.HeroEntity, "QC050_Wanted") then
    GUI.RemoveCounter("WantedWarrantCounter")
  end
end
function Gameflow.ChildhoodVars.ShowCounters()
  if not Gameflow.E3Demo2008Childhood then
    GUI.SetCounter("ChildhoodGoldCounter", "TEXT_QUEST_QC010_GOLD_10", Gameflow.ChildhoodVars.Gold)
  end
  if QuestTracker.IsActive(QuestManager.HeroEntity, "QC050_Wanted") and not Gameflow.E3Demo2008Childhood then
    GUI.SetCounter("WantedWarrantCounter", "TEXT_QUEST_QC050_WARRANTS_10", Gameflow.ChildhoodVars.WarrantsCollected)
  end
end
function Gameflow.ChildhoodVars.SkipToWino()
  Gameflow.ChildhoodVars.PoseForPictureCompleted = true
  Gameflow.ChildhoodVars.BulliesAndDogCompleted = true
  Gameflow.ChildhoodVars.Gold = 1
  if not Gameflow.E3Demo2008Childhood then
    GUI.SetCounter("ChildhoodGoldCounter", "TEXT_QUEST_QC010_GOLD_10", Gameflow.ChildhoodVars.Gold)
  end
end
function Gameflow.ChildhoodVars.SkipToLL()
  Gameflow.ChildhoodVars.WantedCompleted = true
  Gameflow.ChildhoodVars.BeetleHunterCompleted = true
  Gameflow.ChildhoodVars.WinoCompleted = true
  Gameflow.ChildhoodVars.PoseForPictureCompleted = true
  Gameflow.ChildhoodVars.Gold = 4
  if not Gameflow.E3Demo2008Childhood then
    GUI.SetCounter("ChildhoodGoldCounter", "TEXT_QUEST_QC010_GOLD_10", Gameflow.ChildhoodVars.Gold)
  end
end
function Gameflow.ChildhoodVars.SkipToLL2()
  QuestTracker.SetAsPrimary(QuestManager.HeroEntity, "QC045_LoveLetter")
end
function Gameflow.ChildhoodVars.SkipToBuyMusicBox()
  Gameflow.ChildhoodVars.WantedCompleted = true
  Gameflow.ChildhoodVars.BeetleHunterCompleted = true
  Gameflow.ChildhoodVars.WinoCompleted = true
  Gameflow.ChildhoodVars.PoseForPictureCompleted = true
  Gameflow.ChildhoodVars.RoseCommentedOnLoveLetter = true
  Gameflow.ChildhoodVars.Gold = 5
  if not Gameflow.E3Demo2008Childhood then
    GUI.SetCounter("ChildhoodGoldCounter", "TEXT_QUEST_QC010_GOLD_10", Gameflow.ChildhoodVars.Gold)
  end
  GUI.RemoveCounter("WantedWarrantCounter")
  GUI.RemoveCounter("ChildhoodGoldCounter")
  Gameflow.ChildhoodVars.SkippingToMusicBox = true
  if not Gameflow.E3Demo2008Childhood then
    if GetDog() and GetDog():IsAlive() then
      Action.FinishAllActions(GetDog())
      Gameflow.ChildhoodVars.DogName = GetDog():GetName()
      ScriptFunction.PutEntityInLimbo(GetDog())
    else
      ScriptFunction.CreateDog()
      Gameflow.ChildhoodVars.DogName = GetDog():GetName()
      ScriptFunction.PutEntityInLimbo(GetDog())
    end
  end
end
function Gameflow.ChildhoodVars.SkipToLuciensStudy()
  Gameflow.ChildhoodVars.RoseNoFollow = true
  Gameflow.ChildhoodVars.WantedCompleted = true
  Gameflow.ChildhoodVars.BeetleHunterCompleted = true
  Gameflow.ChildhoodVars.WinoCompleted = true
  Gameflow.ChildhoodVars.PoseForPictureCompleted = true
  Gameflow.ChildhoodVars.RoseCommentedOnLoveLetter = true
  Gameflow.ChildhoodVars.Gold = 5
  GUI.RemoveCounter("ChildhoodGoldCounter")
  GUI.RemoveCounter("WantedWarrantCounter")
  Follow.StopFollowing(ScriptFunction.GetEntityWithName("QC010_Rose", "creature"))
  CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_DEFAULT, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS)
  Action.FinishAllActions(QuestManager.HeroEntity)
  SetLevelDisplayName("FairfaxCastleGardens", "TEXT_LEVEL_FAIRFAX_CASTLE")
  Debug.LoadLevel("Albion", "FairfaxCastleGardens", "QC010_FCGStartFromBWSSlums")
  Layers.ActivateLayer("QC010_LucienHeroCircleLayer")
  Gameflow.ChildhoodVars.SkippingToLuciensStudy = true
end
function Gameflow.ChildhoodVars.TableContains(table, entry)
  for i, v in ipairs(table) do
    if v == entry then
      return true
    end
  end
  return false
end
function Gameflow.ChildhoodVars.LockAllDoors(locked)
  local search = SearchTools.StartNewSearch("")
  SearchTools.FilterWithEC(search, Door.GetECType())
  local doors = SearchTools.GetSearchResults(search)
  local script_doors = {
    "QC045_Door",
    "QC045_DoorBalcony"
  }
  for i, door in ipairs(doors) do
    if not Gameflow.ChildhoodVars.TableContains(script_doors, door:GetName()) then
      Door.SetLocked(door, locked)
      Targeted.SetAsTargetable(door, not locked)
    end
  end
end
function Gameflow.ChildhoodVars.SetTargetableAllBeds(targetable)
  local search = SearchTools.StartNewSearch("")
  SearchTools.FilterWithEC(search, Bed.GetECType())
  local beds = SearchTools.GetSearchResults(search)
  local script_beds = {
    "QC010_Bedroll",
    "QC010_Bedroll2"
  }
  for i, bed in ipairs(beds) do
    if not Gameflow.ChildhoodVars.TableContains(script_beds, bed:GetName()) then
      Targeted.SetAsTargetable(bed, targetable)
    end
  end
end
Gameflow.ChildhoodVars.QuestsActive = false
Gameflow.ChildhoodVars.Gold = 0
Gameflow.ChildhoodVars.GoldNeeded = 5
function QC010_Childhood:Init()
  GUI.DisplayMessageBox("WORKED!")
  self.NumberOfVillagersInCrowd = 16
  self.MissionSucceeded = false
  self.MissionFailed = false
  self.QuestName = "QC010_Childhood"
  self.HeroThroughArch = false
  self.HeroInCrowd = false
  self.MurgoPitchDone = false
  self.GotBox = false
  self.EndPhase = false
  self.Morning = false
  self.GoToBed = false
  self.GuardWoken = false
  self.WishPerformed = false
  self.JeevesInStudy = false
  self.BedUsed = false
  self.BeginMurgoExpressions = false
  self.CrowdIndex = 1
  self.RearCrowdIndex = 1
  self.DisperseCrowd = false
  self.CrowdTable = {}
  self.RearCrowdTable = {}
  self.HeroReactions = CreateEnum({
    "CHEER",
    "BOO",
    "NONE"
  })
  Gameflow.ChildhoodVars.DEBUG_MODE = false
  if Gameflow.ChildhoodVars.DEBUG_MODE then
    GUI.DisplayInfoBox("Childhood script in debug mode, skipping ahead to 'collect 5 gold' stage. Slap Dave C")
  end
  self:StartNewEntityThread("QC010_Rose", QC010_Rose, true)
  self:StartNewEntityThread("QC010_Arfur", QC010_Arfur, true)
  self:StartNewEntityThread("QC010_Murgo", QC010_Murgo, true)
  self:StartNewEntityThread("QC010_Theresa", QC010_Theresa, true)
  self:StartNewEntityThread("QC010_HeroThroughArchTrigger", QC010_HeroThroughArchTrigger)
  self:StartNewEntityThread("QC010_HeroInCrowdTrigger", QC010_HeroInCrowdTrigger)
  self:StartNewEntityThread("QC010_MusicBoxWish", QC010_MusicBoxWish)
  self:StartNewEntityThread("QC010_Bedroll2", QC010_Bedroll)
  self:StartNewEntityThread("QC010_Guard", QC010_Guard, true)
  self:StartNewEntityThread("QC010_Jeeves", QC010_Jeeves)
  self:StartNewEntityThread("QC010_Lucien", QC010_Lucien)
  self:StartNewEntityThread("QC010_Garth", QC010_Garth)
  self:StartNewEntityThread("QC010_CircleTrigger", QC010_CircleTrigger)
  self:StartNewEntityThread("QC010_RoseCircleTrigger", QC010_RoseCircleTrigger)
  self:StartNewEntityThread("QC010_HeroPassedWall", QC010_HeroPassedWall)
  self:StartNewEntityThread("QC010_RoseCallingTrigger", QC010_RoseCallingTrigger)
  self:StartNewEntityThread("QC010_EscortGuardFairfax", QC010_EscortGuardFairfax)
  self:StartNewEntityThread("QC010_StudyTrigger", QC010_StudyTrigger)
  self:StartNewEntityThread("QC010_CorridorTrigger", QC010_CorridorTrigger)
  self:StartNewEntityThread("QC010_BanisterTrigger", QC010_BanisterTrigger)
  self.PackRatThread = QC010_PackRatThread:new()
  self.PackRatThread.ParentQuest = self
  QuestTracker.Register(QuestManager.HeroEntity, self.QuestName, "Quest_QC010_Childhood")
  QuestTracker.Unlock(QuestManager.HeroEntity, self.QuestName, false)
  QuestTracker.SetAsActive(QuestManager.HeroEntity, self.QuestName, true)
end
function QC010_Childhood:Update()
  local pause_menu_disabled_key = Player.DisableFullPauseMenu(QuestManager.HeroEntity)
  if not Gameflow.ChildhoodVars.DEBUG_MODE then
    GUI.FadeScreenOut(0)
    GUI.LockScreenFade()
  else
    GUI.FadeScreenOut(0)
    GUI.LockScreenFade()
  end
  if Gameflow.E3Demo2008Childhood then
    TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_MULTIPLAYER_ORB)
  end
  TutorialManager.SetTutorialsEnabled(false)
  Breadcrumber.SetParticleAlphaMultiplier(2)
  Stats.AddUnlockedTitle(GetPlayerHero(), "")
  Stats.SetTitleRecord(GetPlayerHero(), "")
  if not Gameflow.E3Demo2008Childhood then
    AutoSaveGame(true, true)
  end
  coroutine.yield()
  if Gender.Get(QuestManager.HeroEntity) == EGender.EG_MALE then
    Player.ChangePlayerEntityType(QuestManager.HeroEntity, "CreatureHeroChild")
    Gameflow.ChildhoodVars.Male = true
  else
    Player.ChangePlayerEntityType(QuestManager.HeroEntity, "CreatureHeroFemaleChild")
    Gameflow.ChildhoodVars.Male = false
  end
  Layers.ActivateLayer("QC010_Childhood")
  Layers.ActivateLayer("QC010_CrowdBlockageA")
  Layers.ActivateLayer("QC010_MurgoCrowd")
  AmbientPopulationManager.SetRewardsEnabled(false)
  AmbientPopulationManager.SetCrimeEnabled(false)
  Vaulting.SetAsEnabled(QuestManager.HeroEntity, false)
  Player.SetFastTravelStopActivationAsEnabled(QuestManager.HeroEntity, false)
  ScriptFunction.SetExclusionZoneAsActive("FirstAreaExclusion", true)
  ScriptFunction.SetExclusionZoneAsActive("MurgoCaravanExclusion", true)
  ExperienceOrb.SetAsEnabled(false)
  Player.SetExperienceSpendingAsEnabled(QuestManager.HeroEntity, false)
  GUI.SetDPadEnabled(false)
  Player.SetMapScreenAsEnabled(QuestManager.HeroEntity, false)
  Player.SetPauseMenuInfoPageAsEnabled(QuestManager.HeroEntity, false)
  Gameflow.ChildhoodVars.SetTargetableAllBeds(false)
  Player.SetSafetyModeSuggestable(QuestManager.HeroEntity, false)
  Health.SetAsInvulnerable(QuestManager.HeroEntity, true)
  bws_gate = self:GetEntityWithName("BowerstoneMarketExit_Gate", "object")
  Door.SetOpen(bws_gate, false, true)
  Door.SetLocked(bws_gate, true)
  Targeted.SetAsTargetable(bws_gate, false)
  Timing.SetTimeOfDay(12)
  self.StopTimeKey = Timing.SetTimeAsStopped(true)
  do
    local item = Inventory.AddItemOfType(QuestManager.HeroEntity, Gameflow.WeaponNames.ChildMelee)
    local melee = Inventory.InstantiateItemOfType(QuestManager.HeroEntity, Gameflow.WeaponNames.ChildMelee, "No_Name_Needed")
    Carrying.PutEntityInSlot(QuestManager.HeroEntity, Carrying.GetSlotToSheatheWeapon(QuestManager.HeroEntity, melee), melee)
  end
  do
    local item = Inventory.AddItemOfType(QuestManager.HeroEntity, Gameflow.WeaponNames.ChildRanged)
    local ranged = Inventory.InstantiateItemOfType(QuestManager.HeroEntity, Gameflow.WeaponNames.ChildRanged, "No_Name_Needed")
    Carrying.PutEntityInSlot(QuestManager.HeroEntity, Carrying.GetSlotToSheatheWeapon(QuestManager.HeroEntity, ranged), ranged)
  end
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_USEABLE_ITEM)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_EXPRESSION_SUCCESS)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_EXPRESSION_FAIL)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_EXPRESSION_RELEASE)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_EXPRESSION_EXTEND_10)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_EXPRESSION_EARN)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_HIGHLIGHT_PURPLE)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_HIGHLIGHT_INTRO)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_ATTENTION)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_TARGET_LOCKED)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_COMBAT_BLOCK_MISSING)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_MARRIAGE_1)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_FLIRT_BACK)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_EXPRESSION_EARN)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_EXPRESSION_SUGGESTED)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_FLIRT_WRONG)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_FLIRT_BACK)
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_OPINION_ATTRACTED)
  self:StartNewThread(self.PackRatThread)
  if not Gameflow.ChildhoodVars.DEBUG_MODE then
    self.QC010_GenericEventManager = QC010_GenericEventManager:new()
    self.QC010_GenericEventManager.ParentQuest = self
    self:StartNewThread(self.QC010_GenericEventManager)
    local number_of_villagers = 0
    GroupEvent.CreateCrowdControl("QC010_MurgoCrowd")
    local villagers_to_preload = {}
    do
      local vill = self:GetEntityWithName("QC010_VillagerA", "creature")
      self:StartNewEntityThread(vill:GetName(), QC010_VillagerA)
      GossipEC.AddLabel(vill, "ChildhoodCrowdMember")
      OpinionReaction.SetCanDrawOpinionIcons(vill, false)
      OpinionReaction.SetRespondToExpressions(vill, false)
      PhysicsCharacter.SetAsPushableByHero(vill, false)
      Health.SetAsInvulnerable(vill, true)
      Navigation.StopMoving(vill)
      Navigation.SetMovementPaused(vill, true)
      number_of_villagers = number_of_villagers + 1
      table.insert(villagers_to_preload, vill)
    end
    do
      local vill = self:GetEntityWithName("QC010_VillagerB", "creature")
      self:StartNewEntityThread(vill:GetName(), QC010_VillagerB)
      GossipEC.AddLabel(vill, "ChildhoodCrowdMember")
      OpinionReaction.SetCanDrawOpinionIcons(vill, false)
      OpinionReaction.SetRespondToExpressions(vill, false)
      PhysicsCharacter.SetAsPushableByHero(vill, false)
      Health.SetAsInvulnerable(vill, true)
      Navigation.StopMoving(vill)
      Navigation.SetMovementPaused(vill, true)
      number_of_villagers = number_of_villagers + 1
      table.insert(villagers_to_preload, vill)
    end
    do
      local villagers = self:GetAllEntitiesWithNameIncluding("QC010_CrowdMember", "creature")
      for i, vill in ipairs(villagers) do
        GossipEC.AddLabel(vill, "ChildhoodCrowdMember")
        OpinionReaction.SetCanDrawOpinionIcons(vill, false)
        OpinionReaction.SetRespondToExpressions(vill, false)
        PhysicsCharacter.SetAsPushableByHero(vill, false)
        Health.SetAsInvulnerable(vill, true)
        Navigation.StopMoving(vill)
        Navigation.SetMovementPaused(vill, true)
        self:StartNewEntityThread(vill:GetName(), QC010_CrowdMember)
        number_of_villagers = number_of_villagers + 1
        table.insert(villagers_to_preload, vill)
        if number_of_villagers >= self.NumberOfVillagersInCrowd then
          break
        end
      end
    end
    GUI.PlayMovie("Intro.bik")
    GraphicAppearance.SetFadedByCamera(QuestManager.HeroEntity, false)
    self:PooCam()
    SoundTools.PlayMusicAndAtmosForLevel(false)
    SoundTools.SetMusicAndAtmosToStartOnNextLevelLoad(true)
    GUI.UnlockScreenFade()
    GUI.FadeScreenIn(1)
    self:WaitFor(function()
      return self.StartHeroPooScene
    end)
    self:PlayPoo(villagers_to_preload)
  else
    GUI.UnlockScreenFade()
    GUI.FadeScreenIn(1)
  end
  Player.ReEnableFullPauseMenu(QuestManager.HeroEntity, pause_menu_disabled_key)
  if Gameflow.ChildhoodVars.DEBUG_MODE then
    Layers.DeactivateLayer("QC010_CrowdBlockageA")
    Layers.DeactivateLayer("QC010_CrowdBlockageB")
  end
  self:WaitFor(function()
    return self.DisperseCrowd
  end)
  if not Gameflow.ChildhoodVars.SkippingToLuciensStudy then
    self.QC010_CrowdMemberManager = QC010_CrowdMemberManager:new()
    self.QC010_CrowdMemberManager.ParentQuest = self
    self:StartNewThread(self.QC010_CrowdMemberManager)
  end
  self:WaitFor(function()
    return self.MurgoPitchDone
  end)
  GroupEvent.EndCrowdControl("QC010_MurgoCrowd")
  Gossip.ActivateGossipItem("ScriptGossip", "QC010_MurgoAfter")
  while Gameflow.ChildhoodVars.Gold < 5 and not self.GotBox do
    if Gameflow.ChildhoodVars.WinoStarted and not Gameflow.ChildhoodVars.WinoCompleted and Gameflow.ChildhoodVars.BeetleHunterStarted and not Gameflow.ChildhoodVars.BeetleHunterCompleted and QuestTracker.GetPrimaryQuestName(QuestManager.HeroEntity) ~= Gameflow.ChildhoodVars.BeetleHunterQuestName then
      QuestTracker.SetAsPrimary(QuestManager.HeroEntity, Gameflow.ChildhoodVars.BeetleHunterQuestName)
    end
    if Gameflow.ChildhoodVars.BeetleHunterCompleted and Gameflow.ChildhoodVars.WinoCompleted and not Gameflow.ChildhoodVars.WantedCompleted and QuestTracker.GetPrimaryQuestName(QuestManager.HeroEntity) ~= Gameflow.ChildhoodVars.WantedQuestName then
      QuestTracker.SetAsPrimary(QuestManager.HeroEntity, Gameflow.ChildhoodVars.WantedQuestName)
    end
    if not Gameflow.ChildhoodVars.WinoCompleted and Gameflow.ChildhoodVars.BeetleHunterCompleted and QuestTracker.GetPrimaryQuestName(QuestManager.HeroEntity) ~= Gameflow.ChildhoodVars.WinoQuestName then
      QuestTracker.SetAsPrimary(QuestManager.HeroEntity, Gameflow.ChildhoodVars.WinoQuestName)
    end
    if not Gameflow.ChildhoodVars.WinoCompleted and Gameflow.ChildhoodVars.WinoStarted and (not Gameflow.ChildhoodVars.BeetleHunterStarted or Gameflow.ChildhoodVars.BeetleHunterCompleted) and QuestTracker.GetPrimaryQuestName(QuestManager.HeroEntity) ~= Gameflow.ChildhoodVars.WinoQuestName then
      QuestTracker.SetAsPrimary(QuestManager.HeroEntity, Gameflow.ChildhoodVars.WinoQuestName)
    end
    if not Gameflow.ChildhoodVars.BeetleHunterCompleted and Gameflow.ChildhoodVars.WinoCompleted and QuestTracker.GetPrimaryQuestName(QuestManager.HeroEntity) ~= Gameflow.ChildhoodVars.BeetleHunterQuestName then
      QuestTracker.SetAsPrimary(QuestManager.HeroEntity, Gameflow.ChildhoodVars.BeetleHunterQuestName)
    end
    self:WaitForTimeInSeconds(0.25)
  end
  coroutine.yield()
  QuestTracker.SetAsPrimary(QuestManager.HeroEntity, self.QuestName)
  while not self.Morning do
    coroutine.yield()
  end
  if not Gameflow.ChildhoodVars.SkippingToLuciensStudy then
    bws_gate = self:GetEntityWithName("BowerstoneMarketExit_Gate", "object")
    Door.SetOpen(bws_gate, true, true)
    Door.SetLocked(bws_gate, false)
    Targeted.SetAsTargetable(bws_gate, true)
  end
  self:WaitFor(function()
    return self.GoToCastle
  end)
  SetLevelDisplayName("FairfaxCastleGardens", "TEXT_LEVEL_FAIRFAX_CASTLE")
  Layers.ActivateLayer("QC010_JeevesVaultLineLayer")
  if not Gameflow.ChildhoodVars.SkippingToLuciensStudy then
    self:LoadAndWaitForLevel("Albion", "FairfaxCastleGardens", "QC010_FCGStartFromBWSSlums")
    GUI.FadeScreenIn(1)
  end
  SetLevelDisplayName("FairfaxCastleGardens", "TEXT_LEVEL_FAIRFAX_CASTLE_GARDENS")
  Gameflow.ChildhoodVars.DogName = GetDog():GetName()
  ScriptFunction.PutEntityInLimbo(GetDog())
  self:WaitFor(function()
    return self.CircleActive
  end)
  Layers.ActivateLayer("QC010_LucienHeroCircleLayer")
  self:WaitFor(function()
    return self.EndChildhood
  end)
  do
    local door = self:GetEntityWithName("FF_Door_Luciens", "object")
    Sound.StopSoundCategoryPlaying(door, "ROSE_CIRCLE", 200)
    Sound.StopSoundCategoryPlaying(door, "HERO_CIRCLE", 200)
  end
  GUI.FadeScreenOut(0.2)
  self:WaitForTimeInSeconds(0.2)
  GUI.LockScreenFade()
  self:ClearLookAtCamera()
  Breadcrumber.SetParticleAlphaMultiplier(1)
  if Gender.Get(QuestManager.HeroEntity) == EGender.EG_MALE then
    GUI.PlayLocalisedMovie("Fall_m.bik")
  else
    GUI.PlayLocalisedMovie("Fall_f.bik")
  end
  if Gameflow.E3Demo2008Childhood then
    coroutine.yield()
    GUI.PlayLocalisedMovieWithGenderedVoice("NewBeginnings.bik")
  end
  while Gameflow.E3Demo2008Childhood do
    if not self.GameflowEndSet then
      self:AddScriptRules(EInteractiveCutsceneRule.CUTSCENE_RULE_NO_HERO_MOVE + EInteractiveCutsceneRule.CUTSCENE_RULE_NO_INTERACTIONS + EInteractiveCutsceneRule.CUTSCENE_RULE_NO_EXPRESSIONS + EInteractiveCutsceneRule.CUTSCENE_RULE_NO_SPELLS + EInteractiveCutsceneRule.CUTSCENE_RULE_NO_WEAPONS, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS)
      GUI.DisplayInfoBoxParams({
        Name = "E3DEMOEND",
        ShowYButton = false,
        DisplayBoxStyle = EDisplayBoxStyle.DBS_QUEST_ACCEPTANCE
      }, "THANK YOU FOR PLAYING FABLE II")
      self.GameflowEndSet = true
    else
      local is_posted, message_skip = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_INFOBOX, self.LastMessageID_ButtonBox)
      if is_posted then
        self.LastMessageID_ButtonBox = message_skip:GetID()
        if message_skip:GetExtraDataAsNumber() == 1 then
          GUI.RemoveDisplayBox("E3DEMOEND")
          print("GAME SHOULD END NOW, THEY PRESSED THE BUTTON")
          Debug.QuitToFrontEnd()
        end
      end
    end
    coroutine.yield()
  end
  SoundTools.SetMusicAndAtmosToStartOnNextLevelLoad(false)
  self:SetDefaultCamera()
  self.MissionSucceeded = true
  GUI.SetDPadEnabled(true)
  while not self.MissionSucceeded and not self.MissionFailed do
    coroutine.yield()
  end
  if self.MissionSucceeded and Gameflow.GameflowMode then
    QuestTracker.SetAsCompleted(QuestManager.HeroEntity, self.QuestName, true)
  else
  end
  Timing.SetTimeAsStopped(false, self.StopTimeKey)
  if Gameflow.ChildhoodVars.Male then
    Player.ChangePlayerEntityType(QuestManager.HeroEntity, "CreatureHero")
  else
    Player.ChangePlayerEntityType(QuestManager.HeroEntity, "CreatureHeroFemale")
  end
  Inventory.AddInitialItems(QuestManager.HeroEntity)
  AppearanceModifierManager.AddInitialItems(QuestManager.HeroEntity)
  Gameflow.ChildhoodVars.SetTargetableAllBeds(true)
  Player.SetFastTravelStopActivationAsEnabled(QuestManager.HeroEntity, true)
  ExperienceOrb.SetAsEnabled(true)
  Player.SetExperienceSpendingAsEnabled(QuestManager.HeroEntity, true)
  Player.SetMapScreenAsEnabled(QuestManager.HeroEntity, true)
  Player.SetPauseMenuInfoPageAsEnabled(QuestManager.HeroEntity, true)
  AmbientPopulationManager.SetCrimeEnabled(true)
  Vaulting.SetAsEnabled(QuestManager.HeroEntity, true)
  Player.SetSafetyModeSuggestable(QuestManager.HeroEntity, true)
  Health.SetAsInvulnerable(QuestManager.HeroEntity, false)
  if Inventory.GetNumberOfItemsOfType(QuestManager.HeroEntity, "QC010_Rose_Diary") == 0 then
    if Gameflow.ChildhoodResolutionEvil then
      Layers.ActivateLayer("QC010_RoseDiaryLayer_Slums")
    else
      Layers.ActivateLayer("QC010_RoseDiaryLayer_Posh")
    end
  end
end
function QC010_Childhood:TravellingCam(start_point, start_focus, speed, increase)
  local start_point = CVector3(203.29, 101.68, 54.43)
  local forward = CVector3(-0.148, -0.989, 0.02)
  local dir = CVector3(forward)
  dir:Normalise()
  local velocity = dir * speed
  local acceleration = dir * increase
  function TravellingPoint(table_of_data, time)
    local start_point = table_of_data.StartPos or CVector3(0, 0, 0)
    local velocity = table_of_data.Velocity or CVector3(0, 0, 0)
    local acceleration = table_of_data.Acceleration or CVector3(0, 0, 0)
    return start_point + velocity * time + acceleration * (0.5 * time * time)
  end
  local position_function = CameraFunctions.CreateGenericClosure(TravellingPoint, {
    StartPos = start_point,
    Velocity = velocity,
    Acceleration = acceleration
  })
  local focus_function = CameraFunctions.CreateGenericClosure(TravellingPoint, {
    StartPos = start_point + forward,
    Velocity = velocity,
    Acceleration = acceleration
  })
  CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
    PositionFunction = position_function,
    FocusFunction = focus_function,
    BlendInTime = 0
  })
end
function QC010_Childhood:PooCam()
  function WatchFallingPoint(table_of_data, time)
    local start_point = table_of_data.StartPos or CVector3(0, 0, 0)
    local velocity = table_of_data.Velocity or CVector3(0, 0, 0)
    local acceleration = table_of_data.Acceleration or CVector3(0, 0, 0)
    return start_point + velocity * time + acceleration * (0.5 * time * time)
  end
  local start_point = QuestManager.HeroEntity:GetPosition() + CVector3(0, 0, 24)
  local velocity = CVector3(0, 0, -8)
  local acceleration = CVector3(0, 0, -9.81)
  local position_function = CameraFunctions.CreateGenericClosure(WatchFallingPoint, {
    StartPos = start_point,
    Velocity = velocity,
    Acceleration = acceleration
  })
  local focus_function = CameraFunctions.CreateGenericClosure(WatchFallingPoint, {
    StartPos = start_point + CVector3(-0.01, -0.08, -1),
    Velocity = velocity,
    Acceleration = acceleration
  })
  CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
    PositionFunction = position_function,
    FocusFunction = focus_function,
    BlendInTime = 0,
    BlendOutTime = 1
  })
end
function QC010_Childhood:WakeHeroUp()
  self.WakeUpSparrow = true
end
function QC010_Childhood:DogWhimper()
  ScriptFunction.DogWhimper(false)
end
function QC010_Childhood:FinishMurgoPitch()
  self.MurgoFinished = true
end
function QC010_Childhood:RoseShotMusic()
  self:ClearLookAtCamera()
  self:SetFixedCamera({
    blend_in_seconds = 2,
    source_position = CVector3(31.5, 246.78, 152.82),
    target_position = CVector3(31, 245.97, 152.53),
    fov = 60
  })
  local time_multiplier = 0.75
  Timing.SetWorldSecondsPerSecondCrescendo(time_multiplier)
  self.RoseShotMusic = SoundTools.PlayMusic("MUSIC_QC010_ROSE_SHOT")
end
function QC010_Childhood:LucienAngryMusic()
  self.LucienAngryMusic = SoundTools.PlayMusic("MUSIC_QC010_LUCIEN_ANGRY")
  self:SetLookAtCamera({
    blend_in_seconds = 2,
    source_position = CVector3(30.45, 241.69, 152.87),
    target_position = CVector3(29.68, 241.14, 152.57),
    fov = 60
  })
end
function QC010_Childhood:FinishBoxCamera()
  self:SetLookAtCamera({
    blend_in_seconds = 5,
    blend_out_seconds = 2,
    target_position = CVector3(172.68, 148.78, 51.8),
    source_position = CVector3(173.62, 149.13, 51.78)
  })
end
function QC010_Childhood:GunLookAtPosition()
  local hero_head = ScriptFunction.TrackDummy(QuestManager.HeroEntity, "Character.Focal.Mouth") + CVector3(-0.2, 0, 0)
  local lucien_hand = ScriptFunction.TrackDummy(self:GetEntityWithName("QC010_Lucien", "creature"), "Character.Carry.Hand.Right")
  local facing = hero_head - lucien_hand
  facing:Normalise()
  local cam_pos = lucien_hand + facing * 1 + CVector3(0, 0, 0.18)
  return cam_pos
end
function QC010_Childhood:FinishJeeves()
  self.JeevesIntroduced = true
end
function QC010_Childhood:PaintItRed()
  self.PaintCirleFXRed = true
end
function QC010_Childhood:StartGunCamera()
  local time_multiplier = 1
  Timing.SetWorldSecondsPerSecondCrescendo(time_multiplier)
  self.LuciensGun = SoundTools.PlayMusic("MUSIC_QC010_LUCIENS_GUN")
  self:SetFixedCamera({
    blend_in_seconds = 5,
    source_function = function()
      return self:GunLookAtPosition()
    end,
    target_function = function()
      return ScriptFunction.TrackDummy(self:GetEntityWithName("QC010_Lucien", "creature"), "Character.Carry.Hand.Right")
    end,
    fov = 45,
    pan_angle = 0
  })
end
function QC010_Childhood:FinishStudyScene()
  self.EndChildhood = true
  ScriptFunction.StopInteractiveCutscene("QC010_LucienCircle")
end
function QC010_Childhood:StartMurgoExpressions()
  if not Player.GetLookAtButtonDown(QuestManager.HeroEntity) then
    TutorialManager.DisplayTutorial(ETutorialType.TUTORIAL_LEFT_TRIGGER)
  end
  self.BeginMurgoExpressions = true
end
function QC010_Childhood:AllowHeroToWalk()
  self.AllowHeroToMove = true
end
function QC010_Childhood:FinishMurgoExpressions()
  SoundTools.PlayMusic("MUSIC_QC010_MURGO_INTRODUCE_MUSIC_BOX")
  self.EndMurgoExpressions = true
end
function QC010_Childhood:FirstTheresaCam()
  local theresa = self:GetEntityWithName("QC010_Theresa", "creature")
  PhysicsCharacter.SetAsAbleToPushCharacters(theresa, true)
  CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
    BlendInSeconds = 20,
    Position = CVector3(177.42, 143.8, 51.53),
    Focus = CVector3(176.5, 144.11, 51.35),
    FOV = 70,
    DOFFocusEntity = ScriptFunction.GetEntityWithName("QC010_Theresa", "creature"),
    DOFCloseOffset = 5,
    DOFFarOffset = 5,
    DOFStrength = CameraValues.DOFStrength.LOW,
    DOFSize = CameraValues.DOFSize.LOW,
    PanAngle = 0.1,
    SupercedesCombat = true
  })
  self:AddScriptRules(EInteractiveCutsceneRule.CUTSCENE_RULE_NO_HERO_MOVE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS)
  Player.StartScriptControlMode(QuestManager.HeroEntity)
  self.LookAtTarget = ScriptFunction.SetHeroLookTarget(theresa)
  local hero_pos = QuestManager.HeroEntity:GetPosition()
  local theresa_pos = theresa:GetPosition()
  local hero_face = theresa_pos - hero_pos
  hero_face:Normalise()
  NavigatorControl.TurnToFaceDirection(QuestManager.HeroEntity, hero_face)
end
function QC010_Childhood:SecondTheresaCam()
  CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
    BlendInSeconds = 0,
    Position = CVector3(173.44, 143.03, 51.15),
    Focus = CVector3(173.63, 144.01, 51.03),
    FOV = 70,
    DOFFocusEntity = ScriptFunction.GetEntityWithName("QC010_Rose", "creature"),
    DOFCloseOffset = 5,
    DOFFarOffset = 5,
    DOFStrength = CameraValues.DOFStrength.LOW,
    DOFSize = CameraValues.DOFSize.LOW,
    PanAngle = 0.1,
    SupercedesCombat = true
  })
  self.TheresaAndRoseOnCamera = true
  self.DisperseCrowd = true
end
function QC010_Childhood:ThirdTheresaCam()
  local theresa = ScriptFunction.GetEntityWithName("QC010_Theresa", "creature")
  CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
    BlendInSeconds = 0,
    Position = CVector3(174.08, 144.59, 51.17),
    Focus = CVector3(173.09, 144.46, 51.13),
    FOV = 60,
    DOFFocusEntity = theresa,
    DOFCloseOffset = 5,
    DOFFarOffset = 5,
    DOFStrength = CameraValues.DOFStrength.LOW,
    DOFSize = CameraValues.DOFSize.LOW,
    PanAngle = 0.1,
    SupercedesCombat = true
  })
  local hero_marker = ScriptFunction.GetEntityWithName("QC010_HeroInCrowdMarker", "marker")
  Physics.TeleportToPosition(QuestManager.HeroEntity, hero_marker:GetPosition())
  local rose_marker = ScriptFunction.GetEntityWithName("QC010_RoseInCrowdMarker", "marker")
  local rose = ScriptFunction.GetEntityWithName("QC010_Rose", "creature")
  Physics.TeleportToPosition(rose, rose_marker:GetPosition())
  ScriptFunction.SetFacingVector(rose, Physics.GetFacingVector(rose_marker))
  local hero_pos = QuestManager.HeroEntity:GetPosition()
  local theresa_pos = theresa:GetPosition()
  local hero_face = theresa_pos - hero_pos
  hero_face:Normalise()
  NavigatorControl.TurnToFaceDirection(QuestManager.HeroEntity, hero_face)
end
function QC010_Childhood:FourthTheresaCam()
  local theresa = ScriptFunction.GetEntityWithName("QC010_Theresa", "creature")
  CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
    BlendInSeconds = 20,
    FocusEntity = theresa,
    Position = CVector3(174.09, 147.31, 50.62),
    FOV = 70,
    DOFFocusEntity = theresa,
    DOFCloseOffset = 5,
    DOFFarOffset = 5,
    DOFStrength = CameraValues.DOFStrength.LOW,
    DOFSize = CameraValues.DOFSize.LOW,
    PanAngle = 0.1,
    SupercedesCombat = true
  })
  self.TheresaWalkingAway = true
  local hero_pos = QuestManager.HeroEntity:GetPosition()
  local theresa_pos = theresa:GetPosition()
  local hero_face = theresa_pos - hero_pos
  hero_face:Normalise()
  NavigatorControl.TurnToFaceDirection(QuestManager.HeroEntity, hero_face)
end
function QC010_Childhood:FifthTheresaCam()
  local theresa = ScriptFunction.GetEntityWithName("QC010_Theresa", "creature")
  local theresa_pos = theresa:GetPosition()
  local theresa_facing = Physics.GetFacingVector(theresa)
  theresa_facing:Normalise()
  local cam_pos = theresa_pos - theresa_facing + CVector3(0, 0, 1.5)
  local hero_pos = QuestManager.HeroEntity:GetPosition()
  local hero_face = theresa_pos - hero_pos
  hero_face:Normalise()
  NavigatorControl.TurnToFaceDirection(QuestManager.HeroEntity, hero_face)
  CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
    BlendInSeconds = 0,
    Position = cam_pos,
    Focus = ScriptFunction.TrackDummy(theresa, "Character.Focal.Mouth"),
    FOV = 65,
    DOFFocusEntity = theresa,
    DOFCloseOffset = 5,
    DOFFarOffset = 5,
    DOFStrength = CameraValues.DOFStrength.LOW,
    DOFSize = CameraValues.DOFSize.LOW,
    PanAngle = 0.1,
    SupercedesCombat = true
  })
end
function QC010_Childhood:EndTheresaScene()
  self.StopTheresaRoseScene = true
end
function QC010_Childhood:CreateLuciensGun()
  local luciens_gun = Debug.CreateEntityAt("ObjectInventoryPistol_Flintlock_Master", "", CVector3(0, 0, 0))
  local lucien = self:GetEntityWithName("QC010_Lucien", "creature")
  Carrying.PutEntityInSlot(lucien, DummyObjects.HAND_RIGHT, luciens_gun)
end
function QC010_Childhood:BreadcrumbToShack()
  self.BCToShack = true
end
function QC010_Childhood:BreadcrumbTrailToExit()
  self.BreadcrumbToExit = true
end
function QC010_Childhood:PlayPoo(villagers_to_preload)
  self.PooMusic = SoundTools.PlayMusic("MUSIC_QC010_BIRD_POO")
  local poo = {
    Type = EScriptableAction.PLAY_ANIMATION,
    Anim = "HeroReactsToPoo"
  }
  local fire_loop = {
    Type = EScriptableAction.LOOP,
    Priority = EActionPriority.PRIORITY_INTERACTION,
    LoopAction = {
      Type = EScriptableAction.PLAY_ANIMATION,
      Anim = "HeroWarmingUpLoop"
    },
    OutOfAction = {
      Type = EScriptableAction.PLAY_ANIMATION,
      Anim = "HeroWarmingUpOutOf"
    },
    NumLoops = 0
  }
  Action.FinishAllActions(QuestManager.HeroEntity)
  Action.SetCurrentAction(QuestManager.HeroEntity, poo)
  Timing.Wait(1.25)
  Sound.PlayEvent(QuestManager.HeroEntity, "SE_CHILDHOOD_BIRD_POO_SPLAT", "")
  local poo2_particle = Debug.CreateEntityAtPosition("FX_Bird_Poo_Splat", "poo", ScriptFunction.TrackDummy(QuestManager.HeroEntity, "Character.FX.Particle.Effect_1."))
  self:SetFixedCamera({
    blend_in_seconds = 0,
    source_position = CVector3(199.21, 93.1, 53.9),
    target_position = CVector3(199.93, 92.43, 53.74)
  })
  coroutine.yield()
  self:SetFixedCamera({
    blend_in_seconds = 400,
    source_position = CVector3(198.8, 93.57, 54),
    target_position = CVector3(199.52, 92.9, 53.84)
  })
  Timing.Wait(1.5)
  self.RoseComment = true
  Timing.Wait(4)
  self:SetFixedCamera({
    blend_in_seconds = 0,
    source_position = CVector3(201.86, 92.91, 53.84),
    target_position = CVector3(201.23, 92.12, 53.86)
  })
  while Action.IsPerformingAnyAction(QuestManager.HeroEntity) do
    coroutine.yield()
  end
  self.HeroByFireLoop = Action.SetCurrentAction(QuestManager.HeroEntity, fire_loop)
  Timing.Wait(2)
  local velocity = CVector3(202.72, 100.9, 54.27)
  velocity:Normalise()
  self:TravellingCam(CVector3(203.19, 102.07, 54.32), CVector3(203.17, 101.09, 54.37), 0.05, 0)
  Timing.Wait(10)
  self:ClearLookAtCamera()
  TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_LEFT_TRIGGER)
  self:SetFixedCamera({
    blend_in_seconds = 0,
    blend_out_seconds = 20,
    source_position = CVector3(203.2, 89.67, 54.55),
    target_position = CVector3(202.33, 90.14, 54.4)
  })
  StartPreloadingMeshesForEntities(villagers_to_preload)
  self:WaitFor(function()
    return self.IntroFinished
  end)
  self:SetDefaultCamera()
  SACCamera.SetBehindHero = true
  GraphicAppearance.SetFadedByCamera(QuestManager.HeroEntity, true)
end
function QC010_Childhood:GoToCastleQuestion()
  while not self.GoToCastleAccepted do
    if self.GoToCastleBoxShowing then
      if not IsDistanceBetweenThingsUnder(QuestManager.HeroEntity, self:GetEntityWithName("QC010_Guard", "creature"), 5) then
        GUI.RemoveDisplayBox(self.castle_box_tag)
        self.GoToCastleBoxShowing = false
      else
        local is_posted, message_skip = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_INFOBOX, self.LastMessageID_ButtonBox)
        if is_posted then
          self.LastMessageID_ButtonBox = message_skip:GetID()
          if message_skip:GetExtraDataAsNumber() == 1 then
            GUI.RemoveDisplayBox(self.castle_box_tag)
            self.GoToCastleAccepted = true
            self.GoToCastleBoxShowing = false
          end
        end
      end
    elseif IsDistanceBetweenThingsUnder(QuestManager.HeroEntity, self:GetEntityWithName("QC010_Guard", "creature"), 5) then
      self.castle_box_tag = "GoToCastle"
      GUI.DisplayInfoBoxParams({
        Name = self.castle_box_tag,
        ShowYButton = false,
        DisplayBoxStyle = EDisplayBoxStyle.DBS_QUEST_ACCEPTANCE,
        IsHoldAButton = true
      }, "TEXT_QUEST_QC010_QUESTION_CARRIAGE_10")
      self.GoToCastleBoxShowing = true
    end
    coroutine.yield()
  end
  if self.GoToCastleBoxShowing then
    GUI.RemoveDisplayBox(self.castle_box_tag)
    self.GoToCastleBoxShowing = false
  end
  return self.GoToCastleAccepted
end
function QC010_Childhood:OnExit()
  Layers.DeactivateLayer("QC010_Childhood")
  Age.SetAgeGroup(GetPlayerHero(), EAgeGroup.EAGE_GROUP_ADULT)
end
QuestManager.NewEntityThread("QC010_Rose")
function QC010_Rose:Init()
  self.CurrentState = 0
  self.MainStateTypes = CreateEnum({
    "START",
    "QUESTS",
    "END"
  })
  self.MainState = self.MainStateTypes.START
  self.RST = Gameflow.ChildhoodVars.RoseStateTypes
  Gameflow.ChildhoodVars.RoseNoFollow = false
  self.WhingeTime = 60
end
function QC010_Rose:SetHeroByFire()
  local hero_marker = self:GetEntityWithName("QC010_ChildhoodStart", "marker")
  Physics.TeleportToPosition(QuestManager.HeroEntity, hero_marker:GetPosition())
  ScriptFunction.SetFacingVector(QuestManager.HeroEntity, Physics.GetFacingVector(hero_marker))
  local fire_loop = {
    Type = EScriptableAction.LOOP,
    Priority = EActionPriority.PRIORITY_INTERACTION,
    IntoAction = {
      Type = EScriptableAction.PLAY_ANIMATION,
      Anim = "HeroWarmingUpInto"
    },
    LoopAction = {
      Type = EScriptableAction.PLAY_ANIMATION,
      Anim = "HeroWarmingUpLoop"
    },
    NumLoops = 0
  }
  Action.SetCurrentAction(QuestManager.HeroEntity, fire_loop)
end
function QC010_Rose:ShowMusicBoxAcceptance()
  if self.MusicBoxAcceptanceShowing then
    local radius = Trigger.GetBoundingRadius(self:GetEntityWithName("QC010_MusicBoxObjective", "marker"))
    if not IsDistanceBetweenThingsUnder(QuestManager.HeroEntity, self:GetEntityWithName("QC010_BoxHolderCrate", "object"), radius) then
      if self.MusicBoxWait then
        SoundTools.StopMusic(self.MusicBoxWait)
        self.MusicBoxWait = nil
      end
      if not self.rose_following then
        local rose = self:GetEntityWithName("QC010_Rose", "creature")
        Follow.FollowEntity(rose, QuestManager.HeroEntity, 1.5)
        self.rose_following = true
      end
      GUI.RemoveDisplayBox(self.music_box_tag)
      self.MusicBoxAcceptanceShowing = false
    else
      local is_posted, message_skip = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_INFOBOX, self.LastMessageID_ButtonBox)
      if is_posted then
        self.LastMessageID_ButtonBox = message_skip:GetID()
        if message_skip:GetExtraDataAsNumber() == 1 then
          GUI.RemoveDisplayBox(self.music_box_tag)
          self.MusicBoxAcceptanceShowing = false
          self.ParentQuest.HeroWished = true
        end
      end
    end
  else
    local radius = Trigger.GetBoundingRadius(self:GetEntityWithName("QC010_MusicBoxObjective", "marker"))
    if IsDistanceBetweenThingsUnder(QuestManager.HeroEntity, self:GetEntityWithName("QC010_BoxHolderCrate", "object"), radius) then
      local rose = self:GetEntityWithName("QC010_Rose", "creature")
      if self.rose_following and IsDistanceBetweenThingsUnder(rose, self:GetEntityWithName("QC010_BoxHolderCrate", "object"), 2) then
        Follow.StopFollowing(rose)
        Navigation.StopMoving(rose)
        Action.FinishAllActions(rose)
        self.rose_following = false
      end
      self.MusicBoxWait = SoundTools.PlayMusic("MUSIC_QC010_MUSIC_BOX_WAIT")
      self.music_box_tag = "INV_ITEM_MUSIC_BOX_DESC"
      GUI.DisplayInfoBoxParams({
        Name = self.music_box_tag,
        ShowYButton = false,
        DisplayBoxStyle = EDisplayBoxStyle.DBS_QUEST_ACCEPTANCE,
        IsHoldAButton = true
      }, "TEXT_QUEST_QC010_QUESTION_WISH_10")
      self.MusicBoxAcceptanceShowing = true
    end
  end
end
function QC010_Rose:CustomUpdate()
  local StateInvalid = function()
    return Gameflow.ChildhoodVars.InvalidateRoseQuestState
  end
  Navigation.SetIsImportant(self.Entity, true)
  PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
  OpinionReaction.SetRespondToExpressions(self.Entity, false)
  Health.SetAsInvulnerable(self.Entity, true)
  self.WhingeTimer = QuestManager.NewTimer(0)
  if Gameflow.ChildhoodVars.DEBUG_MODE then
    self.ParentQuest.DisperseCrowd = true
    OpinionReaction.SetRespondToExpressions(self.Entity, true)
    self.ParentQuest.MurgoPitchDone = true
    Gameflow.ChildhoodVars.GoldNeeded = 5
    Gameflow.ChildhoodVars.QuestsActive = true
    self.CurrentState = 20
  end
  if Gameflow.ChildhoodVars.SkippingToLuciensStudy then
    Follow.StopFollowing(self.Entity)
    Action.FinishAllActions(self.Entity)
    self.ParentQuest:ClearScriptRules()
  end
  if IsLevelLoaded("FairfaxCastleGardens") then
    self:WaitForTimeInSeconds(2)
    self.MainState = self.MainStateTypes.END
    self.CurrentState = 20
    if Gameflow.ChildhoodVars.SkippingToLuciensStudy then
      self.CurrentState = 20
      self.ParentQuest.DisperseCrowd = true
      self.ParentQuest.MurgoPitchDone = true
      self.ParentQuest.Morning = true
      self.ParentQuest.CarriageBoarded = true
      self.ParentQuest.GoToCastle = true
      Gameflow.ChildhoodVars.DogName = GetDog():GetName()
      ScriptFunction.PutEntityInLimbo(GetDog())
    else
      self.CurrentState = 20
    end
  end
  while self.MainState == self.MainStateTypes.START do
    if self.CurrentState == 0 then
      self:SetHeroByFire()
      self.ParentQuest:AddScriptRules(EInteractiveCutsceneRule.CUTSCENE_RULE_NO_SPELLS, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS)
      self:PlayCutscene({
        Cutscene = "QC010_SetRoseMode"
      })
      self.ParentQuest.StartHeroPooScene = true
      self:WaitFor(function()
        return self.ParentQuest.RoseComment
      end)
      self:PlayCutscene({
        Cutscene = "QC010_RosePoo"
      })
      self.ParentQuest:SetLookAtCamera({
        blend_in_seconds = 7,
        blend_out_seconds = 2,
        source_position = CVector3(200.46, 88.71, 55.23),
        target_position = CVector3(200.32, 87.73, 55.39),
        dof_focus_position = CVector3(173, -72, 92),
        fov = 50,
        dof_far = 150,
        dof_close = 150,
        dof_size = CameraValues.DOFSize.LOW,
        dof_strength = CameraValues.DOFStrength.LOW
      })
      TutorialManager.SetTutorialsEnabled(true)
      TutorialManager.DisplayTutorial(ETutorialType.TUTORIAL_LEFT_TRIGGER)
      local timer = QuestManager.NewTimer(3)
      while 0 < timer:GetTime() and not Player.GetLookAtButtonDown(QuestManager.HeroEntity) do
        coroutine.yield()
      end
      self:PlayCutscene({
        Cutscene = "QC010_RosePoo3"
      })
      self.ParentQuest.PlayCrowdSound = true
      self.CurrentState = 1
    elseif self.CurrentState == 1 then
      local arfur = self:GetEntityWithName("QC010_Arfur", "creature")
      Navigation.SetMovementPaused(self.Entity, true)
      ScriptFunction.StartScriptControlledMovement(self.Entity, CVector3(183.72, 120.4, 50.31), false, ENavigationSpeed.NAV_SPEED_FAST_RUN, nil, arfur)
      self:WaitForTimeInSeconds(1)
      Action.BreakSequence(QuestManager.HeroEntity, self.ParentQuest.HeroByFireLoop)
      self:PlayCutscene({
        Cutscene = "QC010_RoseLookSquare"
      })
      Navigation.SetMovementPaused(self.Entity, false)
      self.CurrentState = 2
    elseif self.CurrentState == 2 then
      ScriptFunction.WaitForCurrentActionToFinish(QuestManager.HeroEntity)
      local radius = Trigger.GetBoundingRadius(self:GetEntityWithName("QC010_HeroInCrowdTrigger", "marker"))
      QuestTracker.SetObjectiveBreadcrumbMaxAreaDrawRadius(QuestManager.HeroEntity, self.ParentQuest.QuestName, 2)
      QuestTracker.SetObjectiveBreadcrumbLargeAreaDrawLength(QuestManager.HeroEntity, self.ParentQuest.QuestName, 3)
      QuestTracker.SetObjectiveBreadcrumbAreaInitialAngle(QuestManager.HeroEntity, self.ParentQuest.QuestName, 2.2)
      QuestTracker.SetObjectiveBreadcrumbRadius(QuestManager.HeroEntity, self.ParentQuest.QuestName, radius)
      self:UpdateObjectiveEntity(self:GetEntityWithName("QC010_HeroInCrowdTrigger", "marker"))
      TutorialManager.DisplayTutorial(ETutorialType.TUTORIAL_BREADCRUMB_TRAIL)
      self.ParentQuest.IntroFinished = true
      self:WaitFor(function()
        return self.ParentQuest.RosePassedWall
      end)
      ScriptFunction.StopScriptControlledMovement(self.Entity)
      coroutine.yield()
      self:MoveAndRotateToMarkerNamed("QC010_RoseNearArfurMarker")
      coroutine.yield()
      ScriptFunction.SetFacingVector(self.Entity, Physics.GetFacingVector(self:GetEntityWithName("QC010_RoseNearArfurMarker", "marker")))
      self.CurrentState = 3
    elseif self.CurrentState == 3 then
      if ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC010_ArfurOffer") then
        self:PlayCutscene({
          Cutscene = "QC010_ArfurOffer"
        })
        ScriptFunction.StopScriptControlledMovement(self.Entity)
        self.CurrentState = 4
      end
    elseif self.CurrentState == 4 then
      ScriptFunction.StartScriptControlledMovement(self.Entity, self:GetPositionOfEntity("QC010_RoseInCrowdMarker", "marker"), false, ENavigationSpeed.NAV_SPEED_SPRINT)
      self.CurrentState = 5
    elseif self.CurrentState == 5 then
      if self.ParentQuest.HeroInCrowd then
        self.CurrentState = 7
      elseif self.ParentQuest.HeroThroughArch then
        self:PlayCutscene({
          Cutscene = "QC010_RoseCreep"
        })
        self.CurrentState = 7
      else
        self:PlayCutscene({
          Cutscene = "QC010_RoseBeckonsToCrowd"
        })
        ScriptFunction.StartScriptControlledMovement(self.Entity, self:GetPositionOfEntity("QC010_RoseInCrowdMarker", "marker"), false, ENavigationSpeed.NAV_SPEED_SPRINT)
        self:PlayCutscene({
          Cutscene = "QC010_RoseCreep"
        })
        self.CurrentState = 7
      end
    elseif self.CurrentState == 7 then
      if ScriptFunction.IsAvailableToSayLine(self.Entity) and self.ParentQuest.HeroInCrowd then
        if ScriptFunction.IsPerformingInteractiveCutscene("QC010_MurgoPitch1") then
          local murgo_pos = self:GetPositionOfEntity("QC010_Murgo", "creature")
          local rose_facing = murgo_pos - self.Entity:GetPosition()
          rose_facing:Normalise()
          NavigatorControl.TurnToFaceDirection(self.Entity, rose_facing)
          Navigation.SetIsImportant(self.Entity, false)
          self:PlayCutscene({
            Cutscene = "QC010_RoseLookingOverCrowd",
            UntilCondition = function()
              return self.ParentQuest.MurgoFinished
            end
          })
          self.CurrentState = 9
        else
          self:PlayCutscene({
            Cutscene = "QC010_RoseArrivedAtMurgo"
          })
          ScriptFunction.StartScriptControlledMovement(self.Entity, self:GetPositionOfEntity("QC010_RoseInCrowdMarker", "marker"), false, ENavigationSpeed.NAV_SPEED_SPRINT)
          local murgo_pos = self:GetPositionOfEntity("QC010_Murgo", "creature")
          local rose_facing = murgo_pos - self.Entity:GetPosition()
          rose_facing:Normalise()
          NavigatorControl.TurnToFaceDirection(self.Entity, rose_facing)
          Navigation.SetIsImportant(self.Entity, false)
          self:PlayCutscene({
            Cutscene = "QC010_RoseLookingOverCrowd",
            UntilCondition = function()
              return self.ParentQuest.MurgoFinished
            end
          })
          self.CurrentState = 9
        end
      end
    elseif self.CurrentState == 9 then
      if self.ParentQuest.MurgoFinished then
        self:PlayCutscene({
          Cutscene = "QC010_TheresaRose"
        })
        self.ParentQuest.LookAtTarget = ScriptFunction.SetHeroLookTarget(self.Entity)
        local rose_pos = self.Entity:GetPosition()
        local hero_pos = QuestManager.HeroEntity:GetPosition()
        local facing = rose_pos - hero_pos
        facing:Normalise()
        CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
          BlendInSeconds = 0,
          Position = CVector3(173.91, 142.49, 50.79),
          Focus = CVector3(174.12, 143.45, 50.62),
          DOFFocusEntity = self:GetEntityWithName("QC010_Rose", "creature"),
          DOFCloseOffset = 5,
          DOFFarOffset = 5,
          DOFStrength = CameraValues.DOFStrength.LOW,
          DOFSize = CameraValues.DOFSize.LOW,
          PanAngle = 0.25,
          SupercedesCombat = true
        })
        NavigatorControl.TurnToFaceDirection(QuestManager.HeroEntity, facing)
        Timing.SetTimeOfDay(23.3)
        EnvironmentTheme.BlendToEnvironmentTheme("EnvThemeNewCombatHighIntensity", 0, 3)
        self:PlayCutscene({
          Cutscene = "QC010_TheresaRose2"
        })
        ScriptFunction.ClearHeroLookTarget(self.ParentQuest.LookAtTarget)
        self.ParentQuest.TheresaAndRoseFinished = true
        self.CurrentState = 10
      end
    elseif self.CurrentState == 10 then
      Follow.FollowEntity(self.Entity, QuestManager.HeroEntity, 1.5)
      OpinionReaction.SetRespondToExpressions(self.Entity, true)
      Gameflow.ChildhoodVars.QuestsActive = true
      local direction = CVector3(-0.526486, 0.850184, 0)
      ScriptFunction.SetFacingVector(QuestManager.HeroEntity, direction)
      Player.StartScriptControlMode(QuestManager.HeroEntity)
      NavigatorControl.TurnToFaceDirection(QuestManager.HeroEntity, direction)
      ScriptFunction.WaitForCurrentActionToFinish(QuestManager.HeroEntity)
      Player.StopScriptControlMode(QuestManager.HeroEntity)
      self.ParentQuest:RemoveScriptRules(EInteractiveCutsceneRule.CUTSCENE_RULE_NO_HERO_MOVE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS)
      CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_DEFAULT, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {BlendInSeconds = 3})
      SACCamera.SetBehindHero = true
      self:PlayCutscene({
        Cutscene = "QC010_RoseGetMoney"
      })
      Player.SetInterestingHighlightingAsEnabled(QuestManager.HeroEntity, true)
      self.CurrentState = 20
    elseif self.CurrentState == 20 then
      self.CurrentState = 0
      self.MainState = self.MainStateTypes.QUESTS
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
      Gameflow.ChildhoodVars.Phase = Gameflow.ChildhoodVars.PhaseTypes.IDLE
      Gameflow.ChildhoodVars.InitCounter()
    end
    coroutine.yield()
  end
  while self.MainState == self.MainStateTypes.QUESTS do
    if Gameflow.ChildhoodVars.RoseQuestState == self.RST.DEFAULT then
      print("Rose State: DEFAULT")
      Gameflow.ChildhoodVars.InvalidateRoseQuestState = false
      self.LastMessageID_Broken = MessageEvents.GetMostRecentMessageID()
      if not Gameflow.ChildhoodVars.RoseNoFollow then
        Follow.FollowEntity(self.Entity, QuestManager.HeroEntity, 1.5)
      end
      self.WhingeTimer:SetTime(self.WhingeTime)
      while true do
        if Gameflow.ChildhoodVars.RoseRequestLock then
          if Gameflow.ChildhoodVars.RoseRequestState then
            Gameflow.ChildhoodVars.RoseQuestState = Gameflow.ChildhoodVars.RoseRequestState
            Gameflow.ChildhoodVars.RoseRequestAck = true
            break
          else
            assert(false, "Rose request locked but no state set")
          end
        end
        if Gameflow.ChildhoodVars.Gold == Gameflow.ChildhoodVars.GoldNeeded and Gameflow.ChildhoodVars.RoseCommentedOnLoveLetter then
          self.MainState = self.MainStateTypes.END
          self.ParentQuest.EndPhase = true
          break
        end
        local is_posted, message = MessageEvents.IsMessageSentBy(EMessageEventType.MESSAGE_EVENT_BROKEN, QuestManager.HeroEntity, self.LastMessageID_Broken)
        if is_posted then
          self.LastMessageID_Broken = message:GetID()
          Gameflow.ChildhoodVars.RoseQuestState = self.RST.QC010_ROSE_SMASH
          break
        end
        if self.Interacted then
          if Gameflow.ChildhoodVars.Phase == Gameflow.ChildhoodVars.PhaseTypes.IDLE then
            Gameflow.ChildhoodVars.RoseQuestState = self.RST.QC010_ROSE_INTERACT
            break
          elseif Gameflow.ChildhoodVars.Phase == Gameflow.ChildhoodVars.PhaseTypes.WANTED_SEARCHING then
            Gameflow.ChildhoodVars.RoseQuestState = self.RST.QC050_SEARCHING_INTERACT
            break
          elseif Gameflow.ChildhoodVars.Phase == Gameflow.ChildhoodVars.PhaseTypes.WINO_SEARCHING then
            Gameflow.ChildhoodVars.RoseQuestState = self.RST.QC055_SEARCHING_INTERACT
            break
          end
        end
        if self.WhingeTimer:GetTime() == 0 and Gameflow.ChildhoodVars.Phase == Gameflow.ChildhoodVars.PhaseTypes.IDLE then
          Gameflow.ChildhoodVars.RoseQuestState = self.RST.QC010_ROSE_IDLE
          break
        end
        coroutine.yield()
      end
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC010_ROSE_SMASH then
      print("Rose State: QC010_ROSE_SMASH")
      self:PlayCutscene({
        Cutscene = "QC010_RoseSmash",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC010_ROSE_INTERACT then
      print("Rose State: QC010_ROSE_INTERACT")
      self:PlayCutscene({
        Cutscene = "QC010_RoseIdleInteract",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC010_ROSE_IDLE then
      print("Rose State: QC010_ROSE_IDLE")
      self:PlayCutscene({
        Cutscene = "QC010_RoseIdle",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC020_APPROACH then
      print("Rose State: QC020_APPROACH")
      Follow.StopFollowing(self.Entity)
      self:PlayCutscene({
        Cutscene = "QC020_BarnumApproach",
        NoSkipBox = true,
        UntilCondition = StateInvalid
      })
      Follow.FollowEntity(self.Entity, QuestManager.HeroEntity, 1.5)
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC020_ACCEPT then
      print("Rose State: QC020_ACCEPT")
      self:PlayCutscene({
        Cutscene = "QC020_BarnumAccept",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC020_NO_EXPRESSION then
      print("Rose State: QC020_NO_EXPRESSION")
      self:PlayCutscene({
        Cutscene = "QC020_RoseIntoPose",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseInPose = true
      self:PlayCutscene({
        Cutscene = "QC020_BarnumNoExpression",
        UntilCondition = StateInvalid
      })
      self:WaitFor(function()
        return Gameflow.ChildhoodVars.PictureTaken
      end)
      self:WaitForTimeInSeconds(0.4)
      self:PlayCutscene({
        Cutscene = "QC020_RoseOutOfPose"
      })
      Gameflow.ChildhoodVars.RoseInPose = nil
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC020_NASTY_EXPRESSION then
      print("Rose State: QC020_NASTY_EXPRESSION")
      self:PlayCutscene({
        Cutscene = "QC020_BarnumReleaseNasty",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC020_ENDING_NICE then
      print("Rose State: QC020_ENDING_NICE")
      self:PlayCutscene({
        Cutscene = "QC020_RoseComplete",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC020_ENDING_EVIL then
      print("Rose State: QC020_ENDING_EVIL")
      self:PlayCutscene({
        Cutscene = "QC020_RoseComplete2",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC020_GOLD_FIRST_NICE then
      print("Rose State: QC020_GOLD_FIRST_NICE")
      self:PlayCutscene({
        Cutscene = "QC020_RoseGoldFirstNice",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC020_GOLD_FIRST_EVIL then
      print("Rose State: QC020_GOLD_FIRST_EVIL")
      self:PlayCutscene({
        Cutscene = "QC020_RoseGoldFirstEvil",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC020_END_HERO_NEAR_ALLEY then
      print("Rose State: QC020_END_HERO_NEAR_ALLEY")
      self:PlayCutscene({
        Cutscene = "QC020_RoseEndHeroNearAlley",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC030_APPROACH then
      print("Rose State: QC030_APPROACH")
      Follow.StopFollowing(self.Entity)
      self:PlayCutscene({
        Cutscene = "QC030_BalthazarApproach",
        NoSkipBox = true,
        UntilCondition = StateInvalid
      })
      Talk.StopTalking(self.Entity, 0)
      Follow.FollowEntity(self.Entity, QuestManager.HeroEntity, 1.5)
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC030_WAIT_FOR_HERO then
      print("Rose State: QC030_WAIT_FOR_HERO")
      Combat.SetCanFight(self.Entity, false)
      Combat.SetCanFlee(self.Entity, false)
      Follow.StopFollowing(self.Entity)
      self:WaitFor(function()
        return Gameflow.ChildhoodVars.HeroOutWarehouse
      end)
      Gameflow.ChildhoodVars.HeroOutWarehouse = nil
      Combat.SetCanFight(self.Entity, true)
      Combat.SetCanFlee(self.Entity, true)
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC030_ENDING_NICE then
      print("Rose State: QC030_ENDING_NICE")
      self:PlayCutscene({
        Cutscene = "QC030_RoseComplete",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC030_ENDING_EVIL then
      print("Rose State: QC030_ENDING_EVIL")
      self:PlayCutscene({
        Cutscene = "QC030_RoseComplete2",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC030_GOLD_SECOND_NICE then
      print("Rose State: QC030_GOLD_SECOND_NICE")
      self:PlayCutscene({
        Cutscene = "QC030_RoseGoldSecondNice",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC030_GOLD_SECOND_EVIL then
      print("Rose State: QC030_GOLD_SECOND_EVIL")
      self:PlayCutscene({
        Cutscene = "QC030_RoseGoldSecondEvil",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC030_GOLD_THIRD_NICE then
      print("Rose State: QC030_GOLD_THIRD_NICE")
      self:PlayCutscene({
        Cutscene = "QC030_RoseGoldThirdNice",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC030_GOLD_THIRD_EVIL then
      print("Rose State: QC030_GOLD_THIRD_EVIL")
      self:PlayCutscene({
        Cutscene = "QC030_RoseGoldThirdEvil",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC030_GOLD_FORTH_NICE then
      print("Rose State: QC030_GOLD_FORTH_NICE")
      self:PlayCutscene({
        Cutscene = "QC030_RoseGoldForthNice",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC030_GOLD_FORTH_EVIL then
      print("Rose State: QC030_GOLD_FORTH_EVIL")
      self:PlayCutscene({
        Cutscene = "QC030_RoseGoldForthEvil",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC040_REX_ROSE then
      print("Rose State: QC040_REX_ROSE")
      self:PlayCutscene({
        Cutscene = "QC040_RexRose",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC040_ROSE_GET_UP then
      print("Rose State: QC040_ROSE_GET_UP")
      self:PlayCutscene({
        Cutscene = "QC040_RoseGetUp",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC040_ROSE_DOG then
      print("Rose State: QC040_ROSE_DOG")
      self:PlayCutscene({
        Cutscene = "QC040_RoseDog",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseNoFollow = false
      Gameflow.ChildhoodVars.RoseDogDone = true
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_MONTY_INTRO then
      print("Rose State: QC045_MONTY_INTRO")
      Follow.StopFollowing(self.Entity)
      self:PlayCutscene({
        Cutscene = "QC045_MontyIntro",
        NoSkipBox = true,
        UntilCondition = StateInvalid
      })
      Follow.FollowEntity(self.Entity, QuestManager.HeroEntity, 1.5)
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_ROSE_READ_LETTER then
      print("Rose State: QC045_ROSE_READ_LETTER")
      self:PlayCutscene({
        Cutscene = "QC045_RoseReadLetter",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_NEAR_HOUSE then
      print("Rose State: QC045_NEAR_HOUSE")
      self:PlayCutscene({
        Cutscene = "QC045_RoseNearHouse",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_WAIT_DOOR then
      print("Rose State: QC045_WAIT_DOOR")
      self:PlayCutscene({
        Cutscene = "QC045_RoseWaitDoor",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_DEIDRE_OPEN_DOOR then
      print("Rose State: QC045_DEIDRE_OPEN_DOOR")
      self:PlayCutscene({
        Cutscene = "QC045_DeidreOpenDoor",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_DEIDRE_GOT_MONEY then
      print("Rose State: QC045_DEIDRE_GOT_MONEY")
      self:PlayCutscene({
        Cutscene = "QC045_RoseDeidreGotMoney",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_ENTER_HOUSE then
      print("Rose State: QC045_ENTER_HOUSE")
      self:PlayCutscene({
        Cutscene = "QC045_RoseEnterHouse",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_WAIT_HOUSE then
      print("Rose State: QC045_WAIT_HOUSE")
      self:PlayCutscene({
        Cutscene = "QC045_RoseWaitHouse",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_APPROACH_BELINDA then
      print("Rose State: QC045_APPROACH_BELINDA")
      self:PlayCutscene({
        Cutscene = "QC045_RoseApproachBelinda",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_WAIT_DOWNSTAIRS then
      print("Rose State: QC045_WAIT_DOWNSTAIRS")
      self:PlayCutscene({
        Cutscene = "QC045_RoseWaitDownstairs",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_WAIT_UPSTAIRS then
      print("Rose State: QC045_WAIT_UPSTAIRS")
      self:PlayCutscene({
        Cutscene = "QC045_RoseWaitUpstairs",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_WAIT_DOWNSTAIRS_END then
      print("Rose State: QC045_WAIT_DOWNSTAIRS_END")
      self:PlayCutscene({
        Cutscene = "QC045_RoseWaitDownstairsEnd",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_ENDING_NICE then
      print("Rose State: QC045_ENDING_NICE")
      self:PlayCutscene({
        Cutscene = "QC045_RoseMoveOn2",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_ENDING_EVIL then
      print("Rose State: QC045_ENDING_EVIL")
      self:PlayCutscene({
        Cutscene = "QC045_RoseComplete",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_GOLD_FIFTH_NICE then
      print("Rose State: QC045_GOLD_FIFTH_NICE")
      self:PlayCutscene({
        Cutscene = "QC045_RoseGoldFifthNice",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC045_GOLD_FIFTH_EVIL then
      print("Rose State: QC045_GOLD_FIFTH_EVIL")
      self:PlayCutscene({
        Cutscene = "QC045_RoseGoldFifthEvil",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_SEARCHING_INTERACT then
      print("Rose State: QC050_SEARCHING_INTERACT")
      self:PlayCutscene({
        Cutscene = "QC050_RoseSearchingInteract",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_CALL_OVER then
      print("Rose State: QC050_CALL_OVER")
      Follow.StopFollowing(self.Entity)
      Gameflow.ChildhoodVars.RoseNoFollow = true
      self:PlayCutscene({
        Cutscene = "QC050_DerekCallOver",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_APPROACH then
      if ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC050_DerekApproach") then
        self:PlayCutscene({
          Cutscene = "QC050_DerekApproach",
          NoSkipBox = true,
          UntilCondition = StateInvalid
        })
      end
      if StateInvalid() then
        Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
      end
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ACCEPT then
      print("Rose State: QC050_ACCEPT")
      self:PlayCutscene({
        Cutscene = "QC050_DerekAccept",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ROSE_START then
      print("Rose State: QC050_ROSE_START")
      self:PlayCutscene({
        Cutscene = "QC050_RoseStart",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ROSE_START2 then
      print("Rose State: QC050_ROSE_START2")
      self:PlayCutscene({
        Cutscene = "QC050_RoseStart2",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ROSE_SPOT_DOG then
      print("Rose State: QC050_ROSE_SPOT_DOG")
      self:PlayCutscene({
        Cutscene = "QC050_RoseSpotDog",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ROSE_PRAISE_DOG then
      print("Rose State: QC050_ROSE_PRAISE_DOG")
      Follow.StopFollowing(self.Entity)
      self:PlayCutscene({
        Cutscene = "QC050_RoseGotDogWarrant",
        UntilCondition = StateInvalid
      })
      Follow.FollowEntity(self.Entity, QuestManager.HeroEntity, 1.5)
      Gameflow.ChildhoodVars.HeroGotDogWarrant_CommentDone = true
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ARFUR_INTRO then
      print("Rose State: QC050_ARFUR_INTRO")
      self:PlayCutscene({
        Cutscene = "QC050_ArfurConfront",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ARFUR_TARGETED_1_SHOT then
      print("Rose State: QC050_ARFUR_TARGETED_1_SHOT")
      self:PlayCutscene({
        Cutscene = "QC050_ArfurTargeted1Shot",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ARFUR_TARGETED_1_HELP then
      print("Rose State: QC050_ARFUR_TARGETED_1_HELP")
      self:PlayCutscene({
        Cutscene = "QC050_ArfurTargeted1Help",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ARFUR_TARGETED_1 then
      print("Rose State: QC050_ARFUR_TARGETED_1")
      self:PlayCutscene({
        Cutscene = "QC050_ArfurTargeted1",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ARFUR_TARGETED_2 then
      print("Rose State: QC050_ARFUR_TARGETED_2")
      self:PlayCutscene({
        Cutscene = "QC050_ArfurTargeted2",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ARFUR_TARGETED_3 then
      print("Rose State: QC050_ARFUR_TARGETED_3")
      self:PlayCutscene({
        Cutscene = "QC050_ArfurTargeted3",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ARFUR_NOT_TARGETED_1 then
      print("Rose State: QC050_ARFUR_NOT_TARGETED_1")
      self:PlayCutscene({
        Cutscene = "QC050_ArfurNotTargeted1",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ARFUR_NOT_TARGETED_2 then
      print("Rose State: QC050_ARFUR_NOT_TARGETED_2")
      self:PlayCutscene({
        Cutscene = "QC050_ArfurNotTargeted2",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ARFUR_WALK_AWAY then
      print("Rose State: QC050_ARFUR_WALK_AWAY")
      self:PlayCutscene({
        Cutscene = "QC050_ArfurWalkAway",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ROSE_RETURN then
      print("Rose State: QC050_ROSE_RETURN")
      self:PlayCutscene({
        Cutscene = "QC050_RoseGotWarrants",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_NEAR_STUCK_WARRANT then
      print("Rose State: QC050_NEAR_STUCK_WARRANT")
      self:PlayCutscene({
        Cutscene = "QC050_RoseSpotStuckWarrant",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ENDING_NICE then
      print("Rose State: QC050_ENDING_NICE")
      self:PlayCutscene({
        Cutscene = "QC050_RoseCompleteDerek",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_ENDING_EVIL then
      print("Rose State: QC050_ENDING_EVIL")
      self:PlayCutscene({
        Cutscene = "QC050_RoseCompleteArfur",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_GOLD_THIRD_NICE then
      print("Rose State: QC050_GOLD_THIRD_NICE")
      self:PlayCutscene({
        Cutscene = "QC050_RoseGoldThirdNice",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_GOLD_THIRD_EVIL then
      print("Rose State: QC050_GOLD_THIRD_EVIL")
      self:PlayCutscene({
        Cutscene = "QC050_RoseGoldThirdEvil",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_GOLD_FORTH_NICE then
      print("Rose State: QC050_GOLD_FORTH_NICE")
      self:PlayCutscene({
        Cutscene = "QC050_RoseGoldForthNice",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_GOLD_FORTH_EVIL then
      print("Rose State: QC050_GOLD_FORTH_EVIL")
      self:PlayCutscene({
        Cutscene = "QC050_RoseGoldForthEvil",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_SEARCHING_INTERACT then
      print("Rose State: QC055_SEARCHING_INTERACT")
      self:PlayCutscene({
        Cutscene = "QC055_RoseSearchingInteract",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_APPROACH then
      print("Rose State: QC055_APPROACH")
      while not ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC055_BettyApproach") and not StateInvalid() do
        coroutine.yield()
      end
      if not StateInvalid() then
        self:PlayCutscene({
          Cutscene = "QC055_BettyApproach",
          NoSkipBox = true,
          UntilCondition = StateInvalid
        })
      end
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_CLOSE_WITH_BOOZE then
      print("Rose State: QC055_CLOSE_WITH_BOOZE")
      self:PlayCutscene({
        Cutscene = "QC055_BettyApproachBooze",
        UntilCondition = StateInvalid,
        SkipTitle = "TEXT_QUEST_QC055_NAME"
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_ACCEPT then
      print("Rose State: QC055_ACCEPT")
      self:PlayCutscene({
        Cutscene = "QC055_AcceptRose",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_NEAR_MAGPIE_ALLEY then
      print("Rose State: QC055_NEAR_MAGPIE_ALLEY")
      Follow.StopFollowing(self.Entity)
      Gameflow.ChildhoodVars.RoseNoFollow = true
      self:PlayCutscene({
        Cutscene = "QC055_RoseSpotMagpie",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_WAIT_SNEAKING then
      print("Rose State: QC055_WAIT_SNEAKING")
      self:PlayCutscene({
        Cutscene = "QC055_RoseWaitMagpie",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_FAILED_SNEAKING then
      print("Rose State: QC055_FAILED_SNEAKING")
      self:PlayCutscene({
        Cutscene = "QC055_RoseFail",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_FAILED_SNEAKING2 then
      print("Rose State: QC055_FAILED_SNEAKING2")
      self:PlayCutscene({
        Cutscene = "QC055_RoseFail2",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_GOT_BOTTLE then
      print("Rose State: QC055_GOT_BOTTLE")
      self:PlayCutscene({
        Cutscene = "QC055_RoseGotBottle",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_ENDING_NICE then
      print("Rose State: QC055_ENDING_NICE")
      self:PlayCutscene({
        Cutscene = "QC055_RoseCompleteBetty",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_ENDING_EVIL then
      print("Rose State: QC055_ENDING_EVIL")
      self:PlayCutscene({
        Cutscene = "QC055_RoseCompletePete",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_GOLD_SECOND_NICE then
      print("Rose State: QC055_GOLD_SECOND_NICE")
      self:PlayCutscene({
        Cutscene = "QC055_RoseGoldSecondNice",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_GOLD_SECOND_EVIL then
      print("Rose State: QC055_GOLD_SECOND_EVIL")
      self:PlayCutscene({
        Cutscene = "QC055_RoseGoldSecondEvil",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_GOLD_THIRD_NICE then
      print("Rose State: QC055_GOLD_THIRD_NICE")
      self:PlayCutscene({
        Cutscene = "QC055_RoseGoldThirdNice",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_GOLD_THIRD_EVIL then
      print("Rose State: QC055_GOLD_THIRD_EVIL")
      self:PlayCutscene({
        Cutscene = "QC055_RoseGoldThirdEvil",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC055_FIND_MORE_WARRANTS then
      print("Rose State: QC055_FIND_MORE_WARRANTS")
      self:PlayCutscene({
        Cutscene = "QC055_RoseCompleteWarrant",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_WARRANT_SPOTTED then
      print("Rose State: QC050_WARRANT_SPOTTED")
      self:PlayCutscene({
        Cutscene = "QC050_RoseSpotWarrant",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_WARRANT_FIRST then
      print("Rose State: QC050_WARRANT_FIRST")
      self:PlayCutscene({
        Cutscene = "QC050_RoseFindWarrantFirst",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_WARRANT_SECOND then
      print("Rose State: QC050_WARRANT_SECOND")
      self:PlayCutscene({
        Cutscene = "QC050_RoseFindWarrantSecond",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_WARRANT_THIRD then
      print("Rose State: QC050_WARRANT_THIRD")
      self:PlayCutscene({
        Cutscene = "QC050_RoseFindWarrantThird",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    elseif Gameflow.ChildhoodVars.RoseQuestState == self.RST.QC050_WARRANT_FORTH then
      print("Rose State: QC050_WARRANT_FORTH")
      self:PlayCutscene({
        Cutscene = "QC050_RoseFindWarrantForth",
        UntilCondition = StateInvalid
      })
      Gameflow.ChildhoodVars.RoseQuestState = self.RST.DEFAULT
    else
      assert(false, "Rose in a state she can't cope with, Rose now locked up")
    end
    coroutine.yield()
  end
  while self.MainState == self.MainStateTypes.END do
    if self.CurrentState == 0 then
      self:PlayCutscene({
        Cutscene = "QC010_RoseEnoughMoney"
      })
      self:UpdateObjectiveEntity(self:GetEntityWithName("QC010_VillagerMarker_10", "marker"))
      QuestTracker.SetObjectiveBreadcrumbMaxAreaDrawRadius(QuestManager.HeroEntity, self.ParentQuest.QuestName, 3)
      QuestTracker.SetObjectiveBreadcrumbLargeAreaDrawLength(QuestManager.HeroEntity, self.ParentQuest.QuestName, 3.5)
      QuestTracker.SetObjectiveBreadcrumbAreaInitialAngle(QuestManager.HeroEntity, self.ParentQuest.QuestName, 3.7)
      QuestTracker.SetObjectiveBreadcrumbRadius(QuestManager.HeroEntity, self.ParentQuest.QuestName, 3)
      self.BreadcrumbTimer = QuestManager.NewTimer(120)
      self.CurrentState = 1
    elseif self.CurrentState == 1 then
      if ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC010_MurgoBuy") then
        self.CurrentState = 2
      elseif self.BreadcrumbTimer:GetTime() == 0 then
        Breadcrumber.SetAsActive(GetBreadcrumbEntity(), true)
        self.CurrentState = 2
      elseif self.Interacted then
        self:PlayCutscene({
          Cutscene = "QC010_RoseEnoughMoneyShort"
        })
      end
    elseif self.CurrentState == 2 then
      if ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC010_MurgoBuy") then
        Layers.ActivateLayer("QC010_ChildhoodAlt")
        local crate = self:GetEntityWithName("QC010_BoxHolderCrate", "object")
        Gameflow.ChildhoodVars.RoseNoFollow = true
        self:PlayCutscene({
          Cutscene = "QC010_MurgoBuy"
        })
        local MusicBoxTrigger = self:GetEntityWithName("QC010_MusicBoxObjective", "marker")
        Trigger.SetToTriggerOnSpecificEntity(MusicBoxTrigger, QuestManager.HeroEntity)
        self:UpdateObjectiveEntity(MusicBoxTrigger, self:GetEntityWithName("QC010_VillagerMarker_10", "marker"))
        local radius = Trigger.GetBoundingRadius(MusicBoxTrigger)
        QuestTracker.SetObjectiveBreadcrumbMaxAreaDrawRadius(QuestManager.HeroEntity, self.ParentQuest.QuestName, 2)
        QuestTracker.SetObjectiveBreadcrumbLargeAreaDrawLength(QuestManager.HeroEntity, self.ParentQuest.QuestName, 12)
        QuestTracker.SetObjectiveBreadcrumbAreaInitialAngle(QuestManager.HeroEntity, self.ParentQuest.QuestName, 4.8)
        QuestTracker.SetObjectiveBreadcrumbRadius(QuestManager.HeroEntity, self.ParentQuest.QuestName, radius)
        Breadcrumber.SetAsActive(GetBreadcrumbEntity(), true)
        self.CurrentState = 3
      end
    elseif self.CurrentState == 3 then
      local radius = Trigger.GetBoundingRadius(self:GetEntityWithName("QC010_MusicBoxObjective", "marker"))
      self:WaitFor(function()
        return Trigger.IsTriggerEntityInsideTriggerVolume(self:GetEntityWithName("QC010_MusicBoxObjective", "marker"))
      end)
      while not self.ParentQuest.HeroWished do
        self:ShowMusicBoxAcceptance()
        coroutine.yield()
      end
      GUI.FadeScreenOut(1)
      self.CurrentState = 4
    elseif self.CurrentState == 4 then
      Timing.Wait(0.5)
      Follow.StopFollowing(self.Entity)
      Layers.ActivateLayer("QC010_MusicBoxLayer")
      Timing.SetTimeOfDay(21.2)
      self.ParentQuest:AddScriptRules(EInteractiveCutsceneRule.CUTSCENE_RULE_NO_HERO_MOVE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS)
      self:MoveAndRotateEntityToMarkerNamed(QuestManager.HeroEntity, "QC010_HeroWishMarker", false, false)
      local henchman = GetPlayerHenchman()
      if henchman and henchman:IsAlive() then
        local pos = self:GetPositionOfEntity("QC010_HeroWishMarker", "marker") - CVector3(1, 0, 0)
        Physics.TeleportToPosition(henchman, pos)
      end
      self:MoveAndRotateEntityToMarkerNamed(self.Entity, "QC010_RoseWishMarker2")
      Inventory.RemoveAllItemsOfType(QuestManager.HeroEntity, "QC230_MusicBox")
      self.ParentQuest.RoseWishPrompt = true
      self:PlayCutscene({
        Cutscene = "QC010_RoseWishSequence"
      })
      self.pause_menu_disabled_key = Player.DisableFullPauseMenu(QuestManager.HeroEntity)
      CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
        BlendInSeconds = 0,
        Position = CVector3(180.65, 82.17, 53.22),
        Focus = CVector3(180.65, 81.19, 53.44),
        FOV = 50,
        DOFFocusEntity = box_ent,
        DOFCloseOffset = 10,
        DOFFarOffset = 10,
        DOFSize = CameraValues.DOFSize.LOW,
        DOFStrength = CameraValues.DOFStrength.LOW
      })
      coroutine.yield()
      CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
        BlendInSeconds = 300,
        Position = CVector3(180.65, 82.17, 53.22),
        Focus = CVector3(180.65, 81.19, 53.44),
        FOV = 40,
        DOFFocusEntity = box_ent,
        DOFCloseOffset = 10,
        DOFFarOffset = 10,
        DOFSize = CameraValues.DOFSize.LOW,
        DOFStrength = CameraValues.DOFStrength.LOW
      })
      GUI.FadeScreenIn(1)
      ScriptFunction.CreateEntityFromLimbo(Gameflow.ChildhoodVars.DogName, self:GetPositionOfEntity("QC010_DogShackMarker", "marker"))
      Dog.EnableAutoTeleport(GetDog(), false)
      ScriptFunction.StartCutscene({
        Entity = GetDog(),
        Cutscene = "QC010_DogSleeps",
        WaitUntilStarted = false
      })
      Layers.ActivateLayer("QC010_DogVaultLine")
      PhysicsCharacter.SetAsPushableByHero(GetDog(), false)
      ScriptFunction.SetFacingVector(GetDog(), Physics.GetFacingVector(self:GetEntityWithName("QC010_DogShackMarker", "marker")))
      self.CurrentState = 6
    elseif self.CurrentState == 6 then
      local box_ent = self:GetEntityWithName("QC010_MusicBoxWish", "object")
      self:WaitForTimeInSeconds(17)
      CameraBase.RumbleHandle = 0.1
      Player.AddRumbleFromTable(QuestManager.HeroEntity, {
        ID = ERumbleTypes.RUMBLE_TYPE_SCRIPTED_RUMBLE,
        MaxLevel = 1,
        Smoothness = 0,
        AttackTime = 0,
        DecayTime = 0.5,
        Duration = 2,
        LeaveOpen = false
      })
      local hench = GetPlayerHenchman()
      if hench and hench:IsAlive() then
        Player.AddRumbleFromTable(hench, {
          ID = ERumbleTypes.RUMBLE_TYPE_SCRIPTED_RUMBLE,
          MaxLevel = 1,
          Smoothness = 0,
          AttackTime = 0,
          DecayTime = 0.5,
          Duration = 2,
          LeaveOpen = false
        })
      end
      while Action.IsPerformingAnyAction(box_ent) do
        coroutine.yield()
      end
      Debug.CreateEntityAtPosition("FX_Musicbox_Disappear", "Disappear", ScriptFunction.TrackDummy(box_ent, "Character.FX.Particle.Effect.1."))
      coroutine.yield()
      CameraBase.RumbleHandle = 0
      box_ent:Destroy()
      SoundTools.PlayMusic("MUSIC_QC010_MUSIC_BOX_EXPLODE")
      self:WaitForTimeInSeconds(1)
      CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_DEFAULT, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {BlendInSeconds = 3})
      SACCamera.SetBehindHero = true
      Player.ReEnableFullPauseMenu(QuestManager.HeroEntity, self.pause_menu_disabled_key)
      self.ParentQuest:RemoveScriptRules(EInteractiveCutsceneRule.CUTSCENE_RULE_NO_HERO_MOVE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS)
      PhysicsCharacter.SetAsAbleToPushCharacters(self.Entity, true)
      PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
      self:PlayCutscene({
        Cutscene = "QC010_RoseWishSequence2"
      })
      self.CurrentState = 8
    elseif self.CurrentState == 8 then
      local shack_trigger = self:GetEntityWithName("QC010_ShackTrigger", "marker")
      local dog_marker = self:GetEntityWithName("QC010_DogShackMarker", "marker")
      self:WaitFor(function()
        return Trigger.IsSpecificTriggerEntityInsideTriggerVolume(shack_trigger, QuestManager.HeroEntity)
      end)
      ScriptFunction.StopAnyInteractiveCutscene(GetDog())
      ScriptFunction.DogStandAtPosition(dog_marker:GetPosition(), {
        wait = false,
        direction = Physics.GetFacingVector(dog_marker)
      })
      self:PlayCutscene({
        Cutscene = "QC010_RoseDogBed",
        UntilCondition = function()
          return self.ParentQuest.BedUsed
        end
      })
      self:UpdateObjectiveTag("TEXT_QUEST_QC010_OBJECTIVE_50")
      self.CurrentState = 9
    elseif self.CurrentState == 9 then
      if self.ParentQuest.BedUsed then
        self.CurrentState = 10
      else
        ScriptFunction.StartCutscene({
          Entity = GetDog(),
          Cutscene = "QC010_DogSleeps",
          WaitUntilStarted = false
        })
        OpinionReaction.SetRespondToExpressions(self.Entity, false)
        GraphicAppearance.SetFadedByCamera(self.Entity, false)
        self:PlayCutscene({
          Cutscene = "QC010_RoseGoToBed",
          UntilCondition = function()
            return self.ParentQuest.BedUsed
          end
        })
        GraphicAppearance.SetFadedByCamera(self.Entity, true)
        self.CurrentState = 10
      end
    elseif self.CurrentState == 10 then
      self:RemoveObjectiveTag("TEXT_QUEST_QC010_OBJECTIVE_50")
      self:WaitFor(function()
        return self.ParentQuest.Morning
      end)
      Layers.DeactivateLayer("QC010_DogVaultLine")
      ScriptFunction.StopInteractiveCutscene("QC010_DogSleeps")
      self.dog_marker = self:GetEntityWithName("QC010_DogMorningMarker", "marker")
      ScriptFunction.DogTeleportToStandAtPosition(self.dog_marker:GetPosition(), {
        direction = Physics.GetFacingVector(self.dog_marker)
      })
      ScriptFunction.DogSetMood(EDogMoodType.DOG_MOOD_TYPE_ANGRY)
      if ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC010_GuardMorning") then
        ScriptFunction.StartCutscene({
          Entity = GetDog(),
          Cutscene = "QC010_GuardMorning",
          WaitUntilStarted = false
        })
        self:RemoveObjectiveEntity(self:GetEntityWithName("QC010_Bedroll2", "object"))
        self:PlayCutscene({
          Cutscene = "QC010_GuardMorning"
        })
        self.CurrentState = 11
      end
    elseif self.CurrentState == 11 then
      local dog_facing = self.Entity:GetPosition() - self.dog_marker:GetPosition()
      dog_facing:Normalise()
      ScriptFunction.StartCutscene({
        Entity = GetDog(),
        Cutscene = "QC010_RoseMorning",
        WaitUntilStarted = false
      })
      self:PlayCutscene({
        Cutscene = "QC010_RoseMorning"
      })
      self.ParentQuest:DogWhimper()
      self:PlayCutscene({
        Cutscene = "QC010_RoseMorning_2"
      })
      self.ParentQuest:DogWhimper()
      self.CurrentState = 12
    elseif self.CurrentState == 12 then
      self.CurrentState = 13
    elseif self.CurrentState == 13 then
    elseif self.CurrentState == 20 then
      self:PlayCutscene({
        Cutscene = "QC010_JeevesGreet"
      })
      Layers.DeactivateLayer("QC010_JeevesVaultLineLayer")
      Follow.FollowEntity(self.Entity, self:GetEntityWithName("QC010_Jeeves", "creature"), 1.5)
      self.CurrentState = 21
    elseif self.CurrentState == 21 then
      if ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC010_JeevesToStudy") then
        self.ParentQuest.JeevesWalkBegan = true
        PhysicsCharacter.SetAsAbleToPushCharacters(self.Entity, true)
        self:PlayCutscene({
          Cutscene = "QC010_JeevesToStudy"
        })
        Follow.StopFollowing(self.Entity)
        self.CurrentState = 23
      end
    elseif self.CurrentState == 23 then
      if self.ParentQuest.JeevesIntroduced then
        ScriptFunction.StartScriptControlledMovement(self.Entity, self:GetPositionOfEntity("QC010_RoseStudyMarker", "marker"), false, ENavigationSpeed.NAV_SPEED_WALK)
        self:WaitFor(function()
          return self.ParentQuest.HeroInStudy
        end)
        self.ParentQuest:AddScriptRules(EInteractiveCutsceneRule.CUTSCENE_RULE_FORCE_WALK + EInteractiveCutsceneRule.CUTSCENE_RULE_NO_WEAPONS, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS)
        Timing.Wait(0.5)
        self.CurrentState = 30
      end
    elseif self.CurrentState == 30 then
      if ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC010_LucienIntro2") then
        self:PlayCutscene({
          Cutscene = "QC010_LucienIntro2"
        })
        self.CurrentState = 31
      end
    elseif self.CurrentState == 31 then
      ScriptFunction.StopScriptControlledMovement(self.Entity)
      self:PlayCutscene({
        Cutscene = "QC010_RoseReactsToMagic"
      })
      self.CurrentState = 32
    elseif self.CurrentState == 32 then
      if not self.ParentQuest.HeroInCircle then
        self:PlayCutscene({
          Cutscene = "QC010_RoseCirclePrompt",
          UntilCondition = function()
            return self.ParentQuest.HeroInCircle
          end
        })
      end
      self.CurrentState = 33
    elseif self.CurrentState == 33 then
      local Timer = QuestManager.NewTimer(10)
      self:WaitFor(function()
        return self.ParentQuest.HeroInCircle or Timer:GetTime() == 0
      end)
      if not self.ParentQuest.HeroInCircle then
        self:WaitFor(function()
          return self.ParentQuest.HeroInCircle
        end)
        self.CurrentState = 34
      else
        self.CurrentState = 34
      end
    elseif self.CurrentState == 34 then
      self:PlayCutscene({
        Cutscene = "QC010_LucienCircle"
      })
      Creature.Kill(self.Entity, self:GetEntityWithName("QC010_Lucien", "creature"))
      SACCamera.RemoveInterestingEntity(self.Entity)
    end
    coroutine.yield()
  end
end
function QC010_Rose:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewEntityThread("QC010_Arfur")
function QC010_Arfur:Init()
  self.CurrentState = 0
end
function QC010_Arfur:CustomUpdate()
  PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
  ScriptFunction.DisableSimBehaviours(self.Entity)
  Health.SetAsInvulnerable(self.Entity, true)
  if Gameflow.ChildhoodVars.DEBUG_MODE then
    self.Entity:Destroy()
  end
  while true do
    if self.CurrentState == 0 then
      if self.ParentQuest.HeroClosedIn then
        self:PlayCutscene({
          Cutscene = "QC010_ArfurOffer"
        })
        self.CurrentState = 1
      end
    elseif self.CurrentState == 1 then
      local arfur_marker = self:GetEntityWithName("QC010_ArfurMoveAwayMarker", "marker")
      ScriptFunction.StartScriptControlledMovement(self.Entity, arfur_marker:GetPosition(), true, ENavigationSpeed.NAV_SPEED_WALK, Physics.GetFacingVector(arfur_marker))
      self:PlayCutscene({
        Cutscene = "QC010_SetArfurMode"
      })
      self:PlayCutscene({
        Cutscene = "QC010_ArfurSendRegards",
        UntilCondition = function()
          return self.ParentQuest.HeroInCrowd
        end
      })
      self.CurrentState = 2
    elseif self.CurrentState == 2 then
      self.Entity:Destroy()
    end
    coroutine.yield()
  end
end
function QC010_Arfur:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewQuestThread("QC010_CaravanEffects")
function QC010_CaravanEffects:Init()
  self.CurrentState = 0
end
function QC010_CaravanEffects:Update()
  while true do
    if self.CurrentState == 0 then
      local caravan = self:GetEntityWithName("Gypsy_Caravan_1", "")
      if caravan and caravan:IsAlive() then
        self.Steam = {}
        self.Steam[1] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 11)
        self.Steam[2] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 1)
        self.Steam[3] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 9)
        self.Steam[4] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 8)
        self.Steam[5] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 7)
        self.Steam[6] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 6)
        self.Steam[7] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.", 0)
        self.Steam[8] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 5)
        self.Steam[9] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 4)
        self.Steam[10] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 3)
        self.Steam[11] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 0)
        self.Steam[12] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 2)
        self.Steam[13] = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Pot_Steam_01.par", 10)
        local fx_pos = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Torch_Fire_01.par", 0)
        local fx_pos1 = GraphicAppearance.GetDummyObjectPosition(caravan, "Prop.FX.Particle.Effect_1.FX_Torch_Fire_01.par", 1)
        local torch1 = Debug.CreateEntityAtPosition("FX_Torch_Fire", "CaravanFlame", fx_pos)
        local torch2 = Debug.CreateEntityAtPosition("FX_Torch_Fire", "CaravanFlame", fx_pos1)
        Timing.Wait(0.1)
        torch1:Destroy()
        torch2:Destroy()
        Debug.CreateEntityAtPosition("FX_Torch_Fire", "CaravanFlame", fx_pos)
        Debug.CreateEntityAtPosition("FX_Torch_Fire", "CaravanFlame", fx_pos1)
      end
      self.CurrentState = 1
    elseif self.CurrentState == 1 then
      local random1 = math.random(1, 7)
      local random2 = math.random(8, 13)
      local random3 = math.random(1, 13)
      if random2 - random1 ~= 1 then
        if 7 <= random2 - random1 then
          Debug.CreateEntityAtPosition("FX_Steam_Blast", "Steam", self.Steam[random1])
          Debug.CreateEntityAtPosition("FX_Steam_Blast", "Steam", self.Steam[random2])
          if random3 ~= random2 and random3 ~= random1 then
            Debug.CreateEntityAtPosition("FX_Steam_Blast", "Steam", self.Steam[random3])
          end
        else
          Debug.CreateEntityAtPosition("FX_Steam_Blast", "Steam", self.Steam[random1])
          Debug.CreateEntityAtPosition("FX_Steam_Blast", "Steam", self.Steam[random2])
        end
        Timing.Wait(0.5)
      end
    end
    coroutine.yield()
  end
end
QuestManager.NewEntityThread("QC010_Murgo")
function QC010_Murgo:Init()
  self.CurrentState = 0
end
function QC010_Murgo:BuyMusicBoxToaster(center, dialogue_table)
  local rose = self:GetEntityWithName("QC010_Rose", "creature")
  local murgo = self:GetEntityWithName("QC010_Murgo", "creature")
  while not self.BoxAccepted and IsDistanceBetweenThingsUnder(QuestManager.HeroEntity, center, 3) do
    if self.MurgoToasterBoxShowing then
      if not self.SaidApproachLines then
        ScriptFunction.SaySimLine(murgo, "TEXT_QUEST_QC010_MURGO_APPROACH_10")
        self:WaitFor(function()
          return ScriptFunction.IsAvailableToSayLine(murgo)
        end)
        ScriptFunction.SaySimLine(rose, "TEXT_QUEST_QC010_MURGO_APPROACH_20")
        self.SaidApproachLines = true
      end
      if ScriptFunction.GetPlayersTarget() == self.Entity then
        if dialogue_table.TargetedIC == nil then
          if ScriptFunction.IsPerformingAnyInteractiveCutscene(self.Entity) then
            ScriptFunction.StopAnyInteractiveCutscene(self.Entity)
          end
        elseif not ScriptFunction.IsPerformingInteractiveCutscene(dialogue_table.TargetedIC) then
          ScriptFunction.StopAnyInteractiveCutscene(self.Entity)
          ScriptFunction.StartCutscene({
            Entity = self.Entity,
            Cutscene = dialogue_table.TargetedIC
          })
        end
      elseif Targeted.IsHeroWithinInteractionDistance(self.Entity) then
        if dialogue_table.NotTargetedIC == nil then
          if ScriptFunction.IsPerformingAnyInteractiveCutscene(self.Entity) then
            ScriptFunction.StopAnyInteractiveCutscene(self.Entity)
          end
        elseif not ScriptFunction.IsPerformingInteractiveCutscene(dialogue_table.NotTargetedIC) then
          ScriptFunction.StopAnyInteractiveCutscene(self.Entity)
          ScriptFunction.StartCutscene({
            Entity = self.Entity,
            Cutscene = dialogue_table.NotTargetedIC
          })
        end
      end
      local is_posted, message_skip = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_INFOBOX, self.LastMessageID_ButtonBox)
      if is_posted then
        self.LastMessageID_ButtonBox = message_skip:GetID()
        if message_skip:GetExtraDataAsNumber() == 1 then
          GUI.RemoveDisplayBox(self.murgo_box_tag)
          self.MurgoToasterBoxShowing = false
          self.BoxAccepted = true
        end
      end
    elseif IsDistanceBetweenThingsUnder(QuestManager.HeroEntity, center, 3) then
      if IsDistanceBetweenThingsOver(QuestManager.HeroEntity, rose, 10) and not IsEntityVisibleOnScreen(rose) then
        local cam_table = CameraManager.GetCurrentCamera()
        if cam_table then
          local cam = cam_table.Camera
          if cam then
            local camera_facing = Camera.GetForwardVector(cam)
            camera_facing:Normalise()
            local cam_pos = Debug.GetEntityWithName("PrimaryCamera"):GetPosition()
            local new_pos = cam_pos - camera_facing
            local ground_pos = Camera.GetGroundPositionAtPosition(cam, new_pos)
            Physics.TeleportToPosition(rose, ground_pos)
          end
        end
      end
      self.murgo_box_tag = "MurgoBuyBox"
      GUI.DisplayInfoBoxParams({
        Name = self.murgo_box_tag,
        ShowYButton = false,
        DisplayBoxStyle = EDisplayBoxStyle.DBS_QUEST_ACCEPTANCE,
        IsHoldAButton = true
      }, "TEXT_QUEST_QC010_QUESTION_BUY_BOX_10")
      self.MurgoToasterBoxShowing = true
    end
    coroutine.yield()
  end
  if self.MurgoToasterBoxShowing then
    GUI.RemoveDisplayBox(self.murgo_box_tag)
    self.MurgoToasterBoxShowing = false
    if not self.BoxAccepted then
      if dialogue_table.WalkAwayIC == nil then
        if ScriptFunction.IsPerformingAnyInteractiveCutscene(self.Entity) then
          ScriptFunction.StopAnyInteractiveCutscene(self.Entity)
        end
      elseif not ScriptFunction.IsPerformingInteractiveCutscene(dialogue_table.WalkAwayIC) and not WalkedAway then
        ScriptFunction.StopAnyInteractiveCutscene(self.Entity)
        ScriptFunction.StartCutscene({
          Entity = self.Entity,
          Cutscene = dialogue_table.WalkAwayIC
        })
      end
    end
  end
  return self.BoxAccepted
end
function QC010_Murgo:CustomUpdate()
  PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
  Health.SetAsInvulnerable(self.Entity, true)
  if Gameflow.ChildhoodVars.DEBUG_MODE then
    self.CurrentState = 10
  end
  while true do
    if self.CurrentState == 0 then
      ModeManager.AddModeByEnumWithAnimGroupName(self.Entity, EEntityModeType.EM_CUTSCENE_CUSTOM_POSE, "SalesmanRubbingHandsMode")
      Player.SetInterestingHighlightingAsEnabled(QuestManager.HeroEntity, false)
      self:WaitFor(function()
        return self.ParentQuest.PlayCrowdSound
      end)
      local so_caravan = self:GetEntityWithName("Gypsy_Caravan_1", "")
      if so_caravan and so_caravan:IsAlive() then
        Sound.PlayEvent(so_caravan, "SE_CHILDHOOD_CROWD_MURMUR", "MURGO_CROWD")
      end
      Sound.PlayEvent(self.Entity, "SE_CHILDHOOD_CROWD_CHEER", "")
      ScriptFunction.StartCutscene({
        Entity = self.Entity,
        Cutscene = "QC010_MurgoDistance",
        WaitUntilStarted = false
      })
      self.CurrentState = 1
    elseif self.CurrentState == 1 then
      if self.ParentQuest.StartMurgo and not ScriptFunction.IsPerformingInteractiveCutscene("QC010_RoseArrivedAtMurgo") then
        self.ParentQuest.QC010_CaravanEffects = QC010_CaravanEffects:new()
        self.ParentQuest:StartNewThread(self.ParentQuest.QC010_CaravanEffects)
        self.ParentQuest.LookAtTarget = ScriptFunction.SetHeroLookTarget(self.Entity)
        self:PlayCutscene({
          Cutscene = "QC010_MurgoPitch1"
        })
        self.CurrentState = 2
      end
    elseif self.CurrentState == 2 then
      if self.ParentQuest.TheresaAndRoseFinished then
        self.CurrentState = 10
      end
    elseif self.CurrentState == 10 then
      self:PlayCutscene({
        Cutscene = "QC010_MurgoWaitAround",
        UntilCondition = function()
          return self.ParentQuest.EndPhase
        end
      })
      Creature.SetAsInteresting(self.Entity, true)
      self.CurrentState = 11
    elseif self.CurrentState == 11 then
      local villager_marker = self:GetEntityWithName("QC010_VillagerMarker_10", "marker")
      if IsDistanceBetweenThingsUnder(villager_marker, QuestManager.HeroEntity, 2) then
        self.CurrentState = 13
      end
    elseif self.CurrentState == 13 then
      if self:BuyMusicBoxToaster(self:GetEntityWithName("QC010_VillagerMarker_10", "marker"), {
        TargetedIC = "QC010_MurgoWaitTargeted",
        NotTargetedIC = "QC010_MurgoWaitNotTargeted",
        WalkAwayIC = "QC010_MurgoWaitWalkAway"
      }) then
        self.CurrentState = 14
      end
    elseif self.CurrentState == 14 then
      Creature.SetAsInteresting(self.Entity, false)
      local music_box = self:GetEntityWithName("QC010_MusicBox", "object")
      music_box:Destroy()
      self:PlayCutscene({
        Cutscene = "QC010_MurgoBuy"
      })
      CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_DEFAULT, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {BlendInSeconds = 1})
      SACCamera.RemoveInterestingEntity(self.Entity)
      Gameflow.ChildhoodVars.PayForBox()
      Layers.DeactivateLayer("QC010_MurgoVaultLineLayer")
      self.ParentQuest.GotBox = true
      self.CurrentState = 15
    elseif self.CurrentState == 15 then
      self:PlayCutscene({
        Cutscene = "QC010_MurgoWaitAfterBox"
      })
    end
    coroutine.yield()
  end
end
function QC010_Murgo:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewEntityThread("QC010_Theresa")
function QC010_Theresa:Init()
  self.CurrentState = 0
  PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
end
function QC010_Childhood:TheresaCamera()
  local theresa = self:GetEntityWithName("QC010_Theresa", "creature")
  local theresa_position = theresa:GetPosition()
  local theresa_facing = Physics.GetFacingVector(theresa)
  theresa_facing:Normalise()
  local new_pos = theresa_position + theresa_facing * 0.75 + CVector3(0, 0, 1.6)
  return new_pos
end
function QC010_Theresa:CustomUpdate()
  PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
  Health.SetAsInvulnerable(self.Entity, true)
  Navigation.SetIsImportant(self.Entity, true)
  if Gameflow.ChildhoodVars.DEBUG_MODE then
    self.CurrentState = 2
  end
  while true do
    if self.CurrentState == 0 then
      if self.ParentQuest.MurgoFinished then
        self.CurrentState = 1
      end
    elseif self.CurrentState == 1 then
      if ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC010_TheresaRose") then
        SoundTools.PlayMusic("MUSIC_SCRIPT_CHILDHOOD_THERESA_INTRO")
        local so_caravan = self:GetEntityWithName("Gypsy_Caravan_1", "")
        if so_caravan and so_caravan:IsAlive() then
          Sound.StopSoundCategoryPlaying(so_caravan, "MURGO_CROWD", 3000)
        end
        local time_to_change = 3
        local intensity = 0.75
        Targeted.SetAsTargetable(self.Entity, false)
        GraphicAppearance.SetSaturationMask(self.Entity, true)
        GraphicAppearance.SetSaturationMask(self:GetEntityWithName("QC010_Rose", "creature"), true)
        GraphicAppearance.SetSaturationMask(QuestManager.HeroEntity, true)
        EnvironmentTheme.BlendToEnvironmentTheme("EnvThemeNewCombatHighIntensity", intensity, time_to_change)
        ScriptFunction.StartCutscene({
          Entity = self.Entity,
          Cutscene = "QC010_TheresaRose",
          WaitUntilStarted = true
        })
        self.CurrentState = 2
      end
    elseif self.CurrentState == 2 then
      if self.ParentQuest.StopTheresaRoseScene then
        ScriptFunction.StopInteractiveCutscene("QC010_TheresaRose")
        Action.FinishAllActions(self.Entity)
        Navigation.StopMoving(self.Entity)
        self.CurrentState = 3
      end
    elseif self.CurrentState == 3 then
      Layers.DeactivateLayer("QC010_CrowdBlockageA")
      Layers.DeactivateLayer("QC010_CrowdBlockageB")
      GraphicAppearance.SetSaturationMask(self.Entity, false)
      self.Entity:Destroy()
      self.Currentstate = 3
    end
    coroutine.yield()
  end
end
function QC010_Theresa:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewEntityThread("QC010_MusicBoxWish")
function QC010_MusicBoxWish:CustomUpdate()
  while not self.ParentQuest.RoseWishPrompt do
    coroutine.yield()
  end
  self.MusicBoxMusic = SoundTools.PlayMusic("MUSIC_SCRIPT_CHILDHOOD_MUSIC_BOX")
  ScriptFunction.PlayAnimationOnObject("QC010_MusicBoxWish", "MusicBoxActivate", false)
end
function QC010_MusicBoxWish:ShowToasterBoxNoTarget(toasterbox_text)
  local BoxTag = self.Entity:GetName()
  GUI.DisplayInfoBoxParams({
    Name = BoxTag,
    ShowYButton = false,
    DisplayBoxStyle = EDisplayBoxStyle.DBS_QUEST_ACCEPTANCE
  }, toasterbox_text)
  while true do
    local is_posted, message = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_INFOBOX, self.my_LastMessageID_ButtonBox)
    if is_posted then
      self.my_LastMessageID_ButtonBox = message:GetID()
      if message:GetExtraDataAsNumber() == 1 then
        GUI.RemoveDisplayBox(BoxTag)
        return true
      end
    end
    coroutine.yield()
  end
end
QuestManager.NewEntityThread("QC010_Bedroll")
function QC010_Bedroll:Init()
end
function QC010_Bedroll:CustomUpdate()
  Targeted.SetAsTargetable(self.Entity, false)
  Targeted.SetAsTargetable(self:GetEntityWithName("QC010_Bedroll", "object"), false)
  self:WaitFor(function()
    return ScriptFunction.IsPerformingInteractiveCutscene("QC010_RoseDogBed")
  end)
  Targeted.SetAsTargetable(self.Entity, true)
  self:WaitFor(function()
    return self.Interacted
  end)
  self.ParentQuest.BedUsed = true
  Targeted.SetAsTargetable(self.Entity, false)
  GUI.FadeScreenOut(3)
  self:WaitForTimeInSeconds(3)
  local rose = self:GetEntityWithName("QC010_Rose", "creature")
  self:MoveAndRotateEntityToMarkerNamed(rose, "QC010_RoseMorningMarker")
  self:MoveAndRotateEntityToMarkerNamed(GetDog(), "QC010_DogMorningMarker")
  Physics.TeleportToPosition(QuestManager.HeroEntity, self:GetPositionOfEntity("QC010_Bedroll2", "object"))
  ScriptFunction.SetFacingVector(QuestManager.HeroEntity, CVector3(0, -0.5, 0))
  self.ParentQuest.PauseMenuDisabledKey = Player.DisableFullPauseMenu(QuestManager.HeroEntity)
  local animation_loop = {
    Type = EScriptableAction.LOOP,
    Priority = EActionPriority.PRIORITY_INTERACTION,
    LoopAction = {
      Type = EScriptableAction.PLAY_ANIMATION,
      Anim = "SleepLoop"
    },
    OutOfAction = {
      Type = EScriptableAction.PLAY_ANIMATION,
      Anim = "SleepOutOf"
    },
    NumLoops = 0
  }
  self.ParentQuest.SleepActionHandle = Action.SetCurrentAction(QuestManager.HeroEntity, animation_loop)
  self.ParentQuest:SetFixedCamera({
    source_position = CVector3(203.62, 110.08, 54.95),
    target_position = CVector3(203.23, 109.17, 54.99),
    fov = CameraValues.FOV.DEFAULT,
    dof_focus_entity = QuestManager.HeroEntity,
    dof_far = CameraValues.DOFDistance.GAME_FAR,
    dof_close = CameraValues.DOFDistance.CUT_CLOSE,
    dof_size = CameraValues.DOFStrength.MID,
    dof_strength = CameraValues.DOFSize.MID
  })
  Layers.ActivateLayer("QC010_Morning")
  EnvironmentTheme.BlendToEnvironmentTheme("EnvThemeChildhoodNight", 1, 0)
  Timing.SetTimeOfDay(17)
  self.ParentQuest.Morning = true
  self:WaitForTimeInSeconds(2)
  SoundTools.PlayMusic("MUSIC_QC010_CHILDREN_AWOKEN")
end
QuestManager.NewEntityThread("QC010_Guard")
function QC010_Guard:Init()
  self.CurrentState = 0
end
function QC010_Guard:CustomUpdate()
  PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
  Health.SetAsInvulnerable(self.Entity, true)
  while true do
    if self.CurrentState == 0 then
      self:WaitForTimeInSeconds(2)
      local guard_1 = self:GetEntityWithName("QC010_EscortGuard_1", "creature")
      local guard_2 = self:GetEntityWithName("QC010_EscortGuard_2", "creature")
      if guard_1 and guard_1:IsAlive() then
        AIManager:SetCanRunMoveAwayFromAreaBehaviour(guard_1, false)
        PhysicsCharacter.SetAsPushableByHero(guard_1, false)
      end
      if guard_2 and guard_2:IsAlive() then
        AIManager:SetCanRunMoveAwayFromAreaBehaviour(guard_2, false)
        PhysicsCharacter.SetAsPushableByHero(guard_2, false)
      end
      self:PlayCutscene({
        Cutscene = "QC010_GuardMorning"
      })
      self.ParentQuest.GuardWoken = true
      self.CurrentState = 1
    elseif self.CurrentState == 1 then
      local marker = self:GetEntityWithName("QC010_GuardCarriageMarker", "marker")
      ScriptFunction.StartScriptControlledMovement(self.Entity, marker:GetPosition(), false, ENavigationSpeed.NAV_SPEED_WALK, Physics.GetFacingVector(marker))
      self.CurrentState = 2
    elseif self.CurrentState == 2 then
      if self.ParentQuest.HeroWokeUp then
        self:WaitForTimeInSeconds(2)
        self.CurrentState = 3
      end
    elseif self.CurrentState == 3 then
      if self.ParentQuest:GoToCastleQuestion() then
        self.CurrentState = 4
      end
    elseif self.CurrentState == 4 then
      self:SetFixedCamera({
        blend_in_seconds = 75,
        source_position = CVector3(190.53, 55.56, 64.22),
        target_position = CVector3(190.47, 54.49, 64.44),
        fov = 65
      })
      GUI.FadeScreenOut(15)
      SoundTools.PlayMusic("MUSIC_QC010_TO_THE_CASTLE")
      Timing.Wait(3)
      GuildMessages.SetNarratorTag(QuestManager.HeroEntity, "TEXT_CHARACTER_NAME_ROSE")
      ScriptFunction.PostGuildSealMessage("TEXT_QUEST_QC010_ROSE_MORNING_WAIT_AROUND_10", true)
      GuildMessages.SetNarratorTag(QuestManager.HeroEntity, "TEXT_CHARACTER_NAME_THERESA")
      self:WaitFor(function()
        return GUI.IsScreenFullyFaded()
      end)
      EnvironmentTheme.BlendToEnvironmentTheme("EnvThemeChildhoodNight", 0, 0)
      self:SetDefaultCamera()
      self.ParentQuest.GoToCastle = true
      self.CurrentState = 5
    end
    coroutine.yield()
  end
end
function QC010_Guard:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewEntityThread("QC010_Jeeves")
function QC010_Jeeves:Init()
  self.CurrentState = 0
end
function QC010_Jeeves:CustomUpdate()
  PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
  Health.SetAsInvulnerable(self.Entity, true)
  GUI.SetDPadEnabled(false)
  Timing.SetTimeOfDay(6.3)
  if IsLevelLoaded("FairfaxCastleGardens") then
    self:WaitForTimeInSeconds(3)
    self.CurrentState = 10
  end
  while true do
    if self.CurrentState == 0 then
    elseif self.CurrentState == 10 then
      do
        local study_door = self:GetEntityWithName("FF_Door_Luciens", "object")
        local corridor_door = self:GetEntityWithName("FF_Door_Luciens_2", "object")
        Door.SetOpen(corridor_door, true, true)
        Door.SetLocked(study_door, true)
        Door.SetLocked(corridor_door, true)
        Targeted.SetAsTargetable(study_door, false)
        Targeted.SetAsTargetable(corridor_door, false)
      end
      SoundTools.PlayMusic("MUSIC_REGION_FAIRFAX_CASTLE")
      self:PlayCutscene({
        Cutscene = "QC010_JeevesGreet"
      })
      self.CurrentState = 11
    elseif self.CurrentState == 11 then
      PhysicsCharacter.SetAsAbleToPushCharacters(self.Entity, true)
      self:PlayCutscene({
        Cutscene = "QC010_JeevesToStudy"
      })
      self.CurrentState = 13
    elseif self.CurrentState == 13 then
      self.CurrentState = 14
    elseif self.CurrentState == 14 then
      self.CurrentState = 15
    elseif self.CurrentState == 15 then
      ScriptFunction.StartCutscene({
        Entity = self.Entity,
        Cutscene = "QC010_LucienIntro",
        WaitUntilStarted = false
      })
      self.CurrentState = 16
    elseif self.CurrentState == 16 then
      if self.ParentQuest.JeevesIntroduced then
        self.luciens_door = ScriptFunction.GetEntityWithName("FF_Door_Luciens", "object")
        if self.luciens_door then
          Door.SetOpen(self.luciens_door, true, true)
          Targeted.SetAsTargetable(self.luciens_door, false)
        end
        self:WaitForTimeInSeconds(5)
        ScriptFunction.StopAnyInteractiveCutscene(self.Entity)
        self.CurrentState = 17
      end
    elseif self.CurrentState == 17 and self.ParentQuest.HeroInStudy and not Door.IsOpen(self.luciens_door) then
      ScriptFunction.StartScriptControlledMovement(self.Entity, self:GetPositionOfEntity("QC010_JeevesLeaveMarker", "marker"), true, ENavigationSpeed.NAV_SPEED_WALK)
      self.Entity:Destroy()
    end
    coroutine.yield()
  end
end
function QC010_Jeeves:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewEntityThread("QC010_Lucien")
function QC010_Lucien:Init()
  self.CurrentState = 0
end
function QC010_Lucien:CustomUpdate()
  PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
  PhysicsCharacter.SetAsAbleToPushCharacters(self.Entity, true)
  Faction.AddTemporaryEntityRelationship(self.Entity, QuestManager.HeroEntity, EFactionStatus.FACTION_STATUS_NEUTRAL)
  Hittable.SetEntityAsHittableByEntity(self.Entity, QuestManager.HeroEntity, false)
  Health.SetAsInvulnerable(self.Entity, true)
  while true do
    if self.CurrentState == 0 then
      local letter1 = self:GetEntityWithName("Document1", "object")
      local letter2 = self:GetEntityWithName("Document2", "object")
      if letter1 and letter1:IsAlive() then
        Targeted.SetAsTargetable(letter1, false)
      end
      if letter2 and letter2:IsAlive() then
        Targeted.SetAsTargetable(letter2, false)
      end
      Player.SetAutomaticHUDSuggestionsAsEnabled(QuestManager.HeroEntity, false)
      self:PlayCutscene({
        Cutscene = "QC010_SetLucienMode"
      })
      local desk_position = self:GetPositionOfEntity("QC010_LucienDeskMarker", "marker")
      if desk_position then
        Physics.TeleportToPosition(self.Entity, desk_position)
      end
      ScriptFunction.SetFacingVector(self.Entity, Physics.GetFacingVector(self:GetEntityWithName("QC010_LucienDeskMarker", "marker")))
      self.CurrentState = 1
    elseif self.CurrentState == 1 then
      if self.ParentQuest.HeroInStudy then
        self:PlayCutscene({
          Cutscene = "QC010_LucienIntro2"
        })
        self.ParentQuest.CircleActive = true
        self.CurrentState = 2
      end
    elseif self.CurrentState == 2 then
      if ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC010_RoseReactsToMagic") then
        self:PlayCutscene({
          Cutscene = "QC010_RoseReactsToMagic"
        })
        self.CurrentState = 3
      end
    elseif self.CurrentState == 3 then
      self:PlayCutscene({
        Cutscene = "QC010_RoseCirclePrompt",
        UntilCondition = function()
          return self.ParentQuest.HeroInCircle
        end
      })
      self.CurrentState = 4
    elseif self.CurrentState == 4 then
      if self.ParentQuest.HeroInCircle then
        self.CurrentState = 5
      end
    elseif self.CurrentState == 5 and ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC010_LucienCircle") then
      self.ParentQuest:OverrideHeroCamera({
        target_entity = self:GetEntityWithName("QC010_Lucien", "creature"),
        amount = 1,
        override_rotation = true,
        angle_threshold = 45,
        target_lock = true,
        blend_in_seconds = 2
      })
      PhysicsCharacter.SetAsAbleToPushCharacters(self.Entity, false)
      self:PlayCutscene({
        Cutscene = "QC010_LucienCircle"
      })
      self.ParentQuest:RemoveScriptRules(EInteractiveCutsceneRule.CUTSCENE_RULE_FORCE_WALK + EInteractiveCutsceneRule.CUTSCENE_RULE_NO_WEAPONS, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS)
      Player.SetAutomaticHUDSuggestionsAsEnabled(QuestManager.HeroEntity, true)
      self.CurrentState = 6
    end
    coroutine.yield()
  end
end
function QC010_Lucien:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewEntityThread("QC010_Garth")
function QC010_Garth:Init()
  self.CurrentState = 0
end
function QC010_Garth:CustomUpdate()
  PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
  Health.SetAsInvulnerable(self.Entity, true)
  Morph.SetWillGlowAlpha(self.Entity, 1)
  GraphicAppearanceMorph.UpdateTextureMorphs(self.Entity)
  while true do
    if self.CurrentState == 0 then
      if ScriptFunction.IsPerformingInteractiveCutscene("QC010_JeevesToStudy") then
        ScriptFunction.StartScriptControlledMovement(self.Entity, self:GetPositionOfEntity("QC010_CorridorTrigger", "marker"), true, ENavigationSpeed.NAV_SPEED_WALK)
        self.CurrentState = 1
      end
    elseif self.CurrentState == 1 then
      ScriptFunction.StartScriptControlledMovement(self.Entity, self:GetPositionOfEntity("QC010_GarthMoveMarker", "marker"), true, ENavigationSpeed.NAV_SPEED_WALK)
      self.CurrentState = 2
    elseif self.CurrentState == 2 then
      local trigger = self:GetEntityWithName("QC010_BanisterTrigger", "marker")
      if Trigger.IsSpecificTriggerEntityInsideTriggerVolume(trigger, QuestManager.HeroEntity) then
        ScriptFunction.StartScriptControlledMovement(self.Entity, self:GetPositionOfEntity("QC010_HeroCastleStartMarker", "marker"), true, ENavigationSpeed.NAV_SPEED_FAST_WALK)
        self.Entity:Destroy()
      else
        self:WaitForTimeInSeconds(4)
        ScriptFunction.StartScriptControlledMovement(self.Entity, self:GetPositionOfEntity("QC010_HeroCastleStartMarker", "marker"), true, ENavigationSpeed.NAV_SPEED_FAST_WALK)
        self.Entity:Destroy()
      end
    end
    coroutine.yield()
  end
end
function QC010_Garth:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewEntityThread("QC010_CircleTrigger")
function QC010_CircleTrigger:Init()
  self.CurrentState = 0
end
function QC010_CircleTrigger:CustomUpdate()
  self.Rose = self:GetEntityWithName("QC010_Rose", "creature")
  self.StudyDoor = self:GetEntityWithName("FF_Door_Luciens", "object")
  self.CircleTrigger = self:GetEntityWithName("QC010_RoseCircleTrigger", "marker")
  Trigger.SetToTriggerOnSpecificEntity(self.Entity, QuestManager.HeroEntity)
  Trigger.SetToTriggerOnSpecificEntity(self.CircleTrigger, self.Rose)
  Trigger.SetToTriggerOnSpecificEntity(self.CircleTrigger, QuestManager.HeroEntity)
  while true do
    if self.CurrentState == 0 then
      if self.ParentQuest.AllowHeroToMove then
        self.CurrentState = 1
      end
    elseif self.CurrentState == 1 then
      self.Rose = self:GetEntityWithName("QC010_Rose", "creature")
      if Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.CircleTrigger, self.Rose) or Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, QuestManager.HeroEntity) then
        local fx_pos = GraphicAppearance.GetDummyObjectPosition(self:GetEntityWithName("Fairfax_Hero_Circle", "object"), "Prop.FX.Particle.Effect_1.fxscr_herocircle_symbol.par", 0)
        local fx_facing = GraphicAppearance.GetDummyObjectFacingDirection(self:GetEntityWithName("Fairfax_Hero_Circle", "object"), "Prop.FX.Particle.Effect_1.fxscr_herocircle_symbol.par", 0)
        Sound.PlayEvent(self.StudyDoor, "SE_HERO_CIRCLE_ROSE", "ROSE_CIRCLE")
        self.FirstEffect = Debug.CreateEntityAtPosition("FX_HeroCircle_Symbol_S", "circleEffect", fx_pos)
        ScriptFunction.SetFacingVector(self.FirstEffect, fx_facing)
        if self.FirstEffect:IsAlive() then
          self.FirstEffect:SetAsGameSaving()
        end
        if Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, QuestManager.HeroEntity) then
          Layers.ActivateLayer("QC010_CircleVaultLineLayer")
          local henchman = GetPlayerHenchman()
          if henchman and henchman:IsAlive() then
            Physics.TeleportToPosition(henchman, self.Entity:GetPosition())
          end
          self.ParentQuest.HeroInCircle = true
          self.CurrentState = 2
        else
          self.ParentQuest.RoseInCircle = true
          self.CurrentState = 3
        end
      end
    elseif self.CurrentState == 2 then
      self.Rose = self:GetEntityWithName("QC010_Rose", "creature")
      if Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.CircleTrigger, self.Rose) then
        local fx_pos = GraphicAppearance.GetDummyObjectPosition(self:GetEntityWithName("Fairfax_Hero_Circle", "object"), "Prop.FX.Particle.Effect_1.fxscr_herocircle_symbol.par", 0)
        local fx_facing = GraphicAppearance.GetDummyObjectFacingDirection(self:GetEntityWithName("Fairfax_Hero_Circle", "object"), "Prop.FX.Particle.Effect_1.fxscr_herocircle_symbol.par", 0)
        Sound.PlayEvent(self.StudyDoor, "SE_HERO_CIRCLE_HERO", "HERO_CIRCLE")
        self.SecondEffect = Debug.CreateEntityAtPosition("FX_HeroCircle_Symbol", "circleEffect1", fx_pos)
        ScriptFunction.SetFacingVector(self.SecondEffect, fx_facing)
        if self.SecondEffect:IsAlive() then
          self.SecondEffect:SetAsGameSaving()
        end
        self.ParentQuest.RoseInCircle = true
        self.CurrentState = 4
      end
    elseif self.CurrentState == 3 then
      if Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, QuestManager.HeroEntity) then
        local fx_pos = GraphicAppearance.GetDummyObjectPosition(self:GetEntityWithName("Fairfax_Hero_Circle", "object"), "Prop.FX.Particle.Effect_1.fxscr_herocircle_symbol.par", 0)
        local fx_facing = GraphicAppearance.GetDummyObjectFacingDirection(self:GetEntityWithName("Fairfax_Hero_Circle", "object"), "Prop.FX.Particle.Effect_1.fxscr_herocircle_symbol.par", 0)
        Sound.PlayEvent(self.StudyDoor, "SE_HERO_CIRCLE_HERO", "HERO_CIRCLE")
        self.SecondEffect = Debug.CreateEntityAtPosition("FX_HeroCircle_Symbol", "circleEffect1", fx_pos)
        ScriptFunction.SetFacingVector(self.SecondEffect, fx_facing)
        if self.SecondEffect:IsAlive() then
          self.SecondEffect:SetAsGameSaving()
        end
        Layers.ActivateLayer("QC010_CircleVaultLineLayer")
        local henchman = GetPlayerHenchman()
        if henchman and henchman:IsAlive() then
          Physics.TeleportToPosition(henchman, self.Entity:GetPosition())
        end
        self.ParentQuest.HeroInCircle = true
        self.CurrentState = 4
      end
    elseif self.CurrentState == 4 and self.ParentQuest.PaintCirleFXRed then
      Timing.Wait(6)
      local fx_pos = GraphicAppearance.GetDummyObjectPosition(self:GetEntityWithName("Fairfax_Hero_Circle", "object"), "Prop.FX.Particle.Effect_1.fxscr_herocircle_symbol.par", 0)
      local fx_facing = GraphicAppearance.GetDummyObjectFacingDirection(self:GetEntityWithName("Fairfax_Hero_Circle", "object"), "Prop.FX.Particle.Effect_1.fxscr_herocircle_symbol.par", 0)
      self.FirstRedEffect = Debug.CreateEntityAtPosition("FX_HeroCircle_Symbol_Red_S", "circleEffect", fx_pos)
      self.SecondRedEffect = Debug.CreateEntityAtPosition("FX_HeroCircle_Symbol_Red", "circleEffect1", fx_pos)
      ScriptFunction.SetFacingVector(self.FirstRedEffect, fx_facing)
      ScriptFunction.SetFacingVector(self.SecondRedEffect, fx_facing)
      Timing.Wait(0.5)
      self.FirstEffect:Destroy()
      self.SecondEffect:Destroy()
      if self.FirstRedEffect:IsAlive() then
        self.FirstRedEffect:SetAsGameSaving()
      end
      if self.SecondRedEffect:IsAlive() then
        self.FirstRedEffect:SetAsGameSaving()
      end
      self.CurrentState = 5
    end
    coroutine.yield()
  end
end
QuestManager.NewEntityThread("QC010_RoseCircleTrigger")
function QC010_RoseCircleTrigger:Init()
  self.CurrentState = 0
end
function QC010_RoseCircleTrigger:CustomUpdate()
  self.Rose = self:GetEntityWithName("QC010_Rose", "creature")
  Trigger.SetToTriggerOnSpecificEntity(self.Entity, QuestManager.HeroEntity)
  Trigger.SetToTriggerOnSpecificEntity(self.Entity, self.Rose)
  while true do
    if self.CurrentState == 0 then
      if Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, self.Rose) and not Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, QuestManager.HeroEntity) then
        Layers.ActivateLayer("QC010_RoseVaultLineLayer")
        self.CurrentState = 1
      end
    elseif self.CurrentState == 1 then
    end
    coroutine.yield()
  end
end
QuestManager.NewEntityThread("QC010_StudyTrigger")
function QC010_StudyTrigger:Init()
  self.CurrentState = 0
end
function QC010_StudyTrigger:CustomUpdate()
  while true do
    if self.CurrentState == 0 then
      self.Rose = self:GetEntityWithName("QC010_Rose", "creature")
      self.LuciensDoor = self:GetEntityWithName("FF_Door_Luciens", "object")
      Trigger.SetToTriggerOnSpecificEntity(self.Entity, QuestManager.HeroEntity)
      Trigger.SetToTriggerOnSpecificEntity(self.Entity, self.Rose)
      self.CurrentState = 1
    elseif self.CurrentState == 1 and Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, QuestManager.HeroEntity) and Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, self.Rose) then
      self.ParentQuest.HeroInStudy = true
      self.StudyMusic = SoundTools.PlayMusic("MUSIC_QC010_LUCIENS_STUDY")
      if self.LuciensDoor then
        Door.SetOpen(self.LuciensDoor, false, true)
        Targeted.SetAsTargetable(self.LuciensDoor, false)
      end
      local henchman = GetPlayerHenchman()
      if henchman and henchman:IsAlive() then
        Trigger.SetToTriggerOnSpecificEntity(self.Entity, henchman)
        coroutine.yield()
        if not Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, henchman) then
          local hench_marker_pos = self:GetPositionOfEntity("QC010_HeroStudyMarker", "marker")
          if hench_marker_pos then
            Physics.TeleportToPosition(henchman, hench_marker_pos)
          else
            Physics.TeleportToPosition(henchman, self.Entity:GetPosition())
          end
        end
      end
      self.CurrentState = 2
    end
    coroutine.yield()
  end
end
QuestManager.NewEntityThread("QC010_CorridorTrigger")
function QC010_CorridorTrigger:Init()
  self.CurrentState = 0
  Trigger.SetToTriggerOnSpecificEntity(self.Entity, QuestManager.HeroEntity)
end
function QC010_CorridorTrigger:CustomUpdate()
  self.Garth = self:GetEntityWithName("QC010_Garth", "creature")
  self.BanisterTrigger = self:GetEntityWithName("QC010_BanisterTrigger", "marker")
  self.Rose = self:GetEntityWithName("QC010_Rose", "creature")
  Trigger.SetToTriggerOnSpecificEntity(self.Entity, self.Garth)
  while true do
    if self.CurrentState == 0 then
      self.CorridorDoor = self:GetEntityWithName("FF_Door_Luciens_2", "object")
      if self.ParentQuest.JeevesWalkBegan then
        local henchman = GetPlayerHenchman()
        if henchman and henchman:IsAlive() then
          Trigger.SetToTriggerOnSpecificEntity(self.Entity, henchman)
          coroutine.yield()
          local is_hero_out = Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, QuestManager.HeroEntity)
          local is_rose_in = Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.BanisterTrigger, self.Rose)
          local is_henchman_out = Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, henchman)
          if is_hero_out and not is_rose_in and is_henchman_out then
            Layers.ActivateLayer("QC010_JeevesVaultLineLayer")
            self.HeroEnteredCorridor = true
            Door.SetOpen(self.CorridorDoor, false, true)
            Targeted.SetAsTargetable(self.CorridorDoor, false)
            self.CurrentState = 1
          end
        elseif Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, QuestManager.HeroEntity) and not Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.BanisterTrigger, self.Rose) then
          Layers.ActivateLayer("QC010_JeevesVaultLineLayer")
          self.HeroEnteredCorridor = true
          Door.SetOpen(self.CorridorDoor, false, true)
          Targeted.SetAsTargetable(self.CorridorDoor, false)
          self.CurrentState = 1
        end
      end
    elseif self.CurrentState == 1 then
      if IsDistanceBetweenThingsUnder(self.Garth, self.BanisterTrigger, 18) then
        Door.SetOpen(self.CorridorDoor, true, true)
        Targeted.SetAsTargetable(self.CorridorDoor, false)
        self:WaitFor(function()
          return Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.BanisterTrigger, self.Garth) and Door.IsOpen(self.CorridorDoor)
        end)
        self:WaitForTimeInSeconds(2)
        self.CurrentState = 2
      end
    elseif self.CurrentState == 2 and not Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.BanisterTrigger, QuestManager.HeroEntity) then
      Door.SetOpen(self.CorridorDoor, false, true)
      Targeted.SetAsTargetable(self.CorridorDoor, false)
      self.CurrentState = 3
    end
    coroutine.yield()
  end
end
QuestManager.NewEntityThread("QC010_BanisterTrigger")
function QC010_BanisterTrigger:Init()
  self.CurrentState = 0
  Trigger.SetToTriggerOnSpecificEntity(self.Entity, QuestManager.HeroEntity)
end
function QC010_BanisterTrigger:CustomUpdate()
  self.Garth = self:GetEntityWithName("QC010_Garth", "creature")
  self.Rose = self:GetEntityWithName("QC010_Rose", "creature")
  Trigger.SetToTriggerOnSpecificEntity(self.Entity, self.Garth)
  Trigger.SetToTriggerOnSpecificEntity(self.Entity, self.Rose)
  CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_DEFAULT, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {BlendInSeconds = 0})
  while true do
    if self.CurrentState == 0 then
      coroutine.yield()
      if Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, QuestManager.HeroEntity) and not self.BanisterCameraSet then
        CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
          BlendInSeconds = 2,
          BlendOutSeconds = 2,
          Position = CVector3(70.47, 152.77, 152.37),
          Focus = CVector3(70.1, 153.7, 152.31),
          FOV = 70,
          PanAngle = 0.15
        })
        self.BanisterCameraSet = true
      elseif not Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, QuestManager.HeroEntity) and self.BanisterCameraSet then
        CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_DEFAULT, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS)
        self.BanisterCameraSet = false
      end
    end
    coroutine.yield()
  end
end
QuestManager.NewEntityThread("QC010_HeroPassedWall")
function QC010_HeroPassedWall:Init()
  self.CurrentState = 0
end
function QC010_HeroPassedWall:CustomUpdate()
  while true do
    if self.CurrentState == 0 then
      local rose = self:GetEntityWithName("QC010_Rose", "creature")
      Trigger.SetToTriggerOnSpecificEntity(self.Entity, QuestManager.HeroEntity)
      Trigger.SetToTriggerOnSpecificEntity(self.Entity, rose)
      self:WaitFor(function()
        return Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, rose)
      end)
      self.ParentQuest.RosePassedWall = true
      self.CurrentState = 1
    end
    coroutine.yield()
  end
end
QuestManager.NewEntityThread("QC010_RoseCallingTrigger")
function QC010_RoseCallingTrigger:CustomUpdate()
  Trigger.SetToTriggerOnSpecificEntity(self.Entity, QuestManager.HeroEntity)
  self:WaitForTriggerToFire(self.Entity)
  self.ParentQuest.HeroClosedIn = true
end
QuestManager.NewEntityThread("QC010_VillagerA")
function QC010_VillagerA:Init()
  self.CurrentState = 0
end
function QC010_VillagerA:CustomUpdate()
  while true do
    if self.CurrentState == 0 then
      if ScriptFunction.IsInteractiveCutsceneWaitingForMe(self.Entity, "QC010_MurgoPitch1") then
        self:PlayCutscene({
          Cutscene = "QC010_MurgoPitch1"
        })
        self.CurrentState = 1
      end
    elseif self.CurrentState == 1 and self.ParentQuest.MurgoPitchDone then
      local escape_markers = self:GetAllEntitiesWithNameIncluding("QC010_VillagerLeaveMarker", "marker")
      local Rand = GetRandomNumber(5) * 0.5
      Timing.Wait(Rand)
      ScriptFunction.StartScriptControlledMovement(self.Entity, escape_markers[GetRandomNumber(#escape_markers)]:GetPosition(), true)
      self:WaitFor(function()
        return self.ParentQuest.TheresaWalkingAway
      end)
      self.Entity:Destroy()
    end
    coroutine.yield()
  end
end
function QC010_VillagerA:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewEntityThread("QC010_VillagerB")
function QC010_VillagerB:Init()
  self.CurrentState = 0
end
function QC010_VillagerB:CustomUpdate()
  while true do
    if self.CurrentState == 0 and self.ParentQuest.MurgoPitchDone then
      local escape_markers = self:GetAllEntitiesWithNameIncluding("QC010_VillagerLeaveMarker", "marker")
      local Rand = GetRandomNumber(5) * 0.5
      Timing.Wait(Rand)
      ScriptFunction.StartScriptControlledMovement(self.Entity, escape_markers[GetRandomNumber(#escape_markers)]:GetPosition(), true)
      self:WaitFor(function()
        return self.ParentQuest.TheresaWalkingAway
      end)
      self.Entity:Destroy()
    end
    coroutine.yield()
  end
end
function QC010_VillagerB:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewEntityThread("QC010_CrowdMember")
function QC010_CrowdMember:Init()
  self.CurrentState = 0
  self.MyIndex = 0
end
function QC010_CrowdMember:CustomUpdate()
  while true do
    if self.CurrentState == 0 then
      self.MyIndex = self.ParentQuest.CrowdIndex
      self.ParentQuest.CrowdTable[self.MyIndex] = {}
      self.ParentQuest.CrowdTable[self.MyIndex].Bool = false
      self.ParentQuest.CrowdTable[self.MyIndex].Entity = self.Entity
      self.ParentQuest.CrowdIndex = self.ParentQuest.CrowdIndex + 1
      self.CurrentState = 1
    elseif self.CurrentState == 1 then
      if self.ParentQuest.CrowdTable[self.MyIndex].Bool then
        local escape_markers = self:GetAllEntitiesWithNameIncluding("QC010_VillagerLeaveMarker", "marker")
        Navigation.SetMovementPaused(self.Entity, false)
        ScriptFunction.StartScriptControlledMovement(self.Entity, escape_markers[GetRandomNumber(#escape_markers)]:GetPosition(), false)
        self.CurrentState = 2
      end
    elseif self.CurrentState == 2 and self.ParentQuest.TheresaWalkingAway then
      self.Entity:Destroy()
    end
    coroutine.yield()
  end
end
function QC010_CrowdMember:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewEntityThread("QC010_RearCrowdMember")
function QC010_RearCrowdMember:Init()
  self.CurrentState = 0
  self.MyIndex = 0
end
function QC010_RearCrowdMember:CustomUpdate()
  while true do
    if self.CurrentState == 0 then
      self.MyIndex = self.ParentQuest.RearCrowdIndex
      self.ParentQuest.RearCrowdTable[self.MyIndex] = {}
      self.ParentQuest.RearCrowdTable[self.MyIndex].Bool = false
      self.ParentQuest.RearCrowdTable[self.MyIndex].Entity = self.Entity
      self.ParentQuest.RearCrowdIndex = self.ParentQuest.RearCrowdIndex + 1
      self.CurrentState = 1
    elseif self.CurrentState == 1 and self.ParentQuest.DisperseCrowd then
      Timing.Wait(1)
      self.Entity:Destroy()
    end
    coroutine.yield()
  end
end
function QC010_RearCrowdMember:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewQuestThread("QC010_CrowdMemberManager")
function QC010_CrowdMemberManager:Init()
  self.CurrentState = 0
end
function QC010_CrowdMemberManager:Update()
  while not self.ParentQuest.TheresaAndRoseOnCamera do
    coroutine.yield()
  end
  local crowd_dispersed = false
  while not crowd_dispersed do
    crowd_dispersed = true
    for i, vill in ipairs(self.ParentQuest.CrowdTable) do
      if crowd_dispersed and not vill.Bool then
        crowd_dispersed = false
      end
    end
    if not crowd_dispersed then
      local largest_distance = 0
      local villager_to_disperse = 0
      for i, vill in ipairs(self.ParentQuest.CrowdTable) do
        if not vill.Bool and largest_distance < GetDistanceBetweenEntities(vill.Entity, QuestManager.HeroEntity) then
          largest_distance = GetDistanceBetweenEntities(vill.Entity, QuestManager.HeroEntity)
          villager_to_disperse = i
        end
      end
      Timing.Wait(0.1)
      self.ParentQuest.CrowdTable[villager_to_disperse].Bool = true
    end
    coroutine.yield()
  end
  self.ParentQuest.MurgoPitchDone = true
end
QuestManager.NewEntityThread("QC010_HeroThroughArchTrigger")
function QC010_HeroThroughArchTrigger:CustomUpdate()
  Trigger.SetToTriggerOnSpecificEntity(self.Entity, QuestManager.HeroEntity)
  self:WaitFor(function()
    return self:HasTriggerFired(self.Entity)
  end)
  self.ParentQuest.HeroThroughArch = true
end
QuestManager.NewEntityThread("QC010_HeroInCrowdTrigger")
function QC010_HeroInCrowdTrigger:Init()
  if not Gameflow.ChildhoodVars.DEBUG_MODE then
    self.CurrentState = 0
  else
    self.CurrentState = 3
  end
end
function QC010_HeroInCrowdTrigger:IsCameraFacingAlley()
  local cam_table = CameraManager.GetCurrentCamera()
  if cam_table then
    local cam = cam_table.Camera
    if cam then
      local camera_facing = Camera.GetForwardVector(cam)
      local alley_facing = CVector3(-0.51388, 0.857862, 0)
      camera_facing:Normalise()
      alley_facing:Normalise()
      local cos = alley_facing:GetDot(camera_facing)
      if 0.4 < cos then
        return true
      else
        return false
      end
    end
  end
end
function QC010_HeroInCrowdTrigger:CustomUpdate()
  while true do
    self.Rose = self:GetEntityWithName("QC010_Rose", "creature")
    if self.CurrentState == 0 then
      Trigger.SetToTriggerOnSpecificEntity(self.Entity, QuestManager.HeroEntity)
      Trigger.SetToTriggerOnSpecificEntity(self.Entity, self.Rose)
      self:WaitForTriggerToFire(self.Entity)
      self.CurrentState = 1
    elseif self.CurrentState == 1 then
      local murgo = self:GetEntityWithName("QC010_Murgo", "creature")
      while not self.ParentQuest.StartMurgo do
        if Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, QuestManager.HeroEntity) then
          self.ParentQuest.HeroInCrowd = true
          TutorialManager.CompleteTutorial(ETutorialType.TUTORIAL_BREADCRUMB_TRAIL)
          local hench = GetPlayerHenchman()
          if hench and hench:IsAlive() then
            CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
              BlendInSeconds = 2,
              BlendOutSeconds = 2,
              Position = CVector3(177.68, 144.77, 50.45),
              Focus = CVector3(176.7, 144.95, 50.41),
              FOV = 77
            })
          else
            self.ParentQuest:OverrideHeroCamera({
              blend_in_seconds = 2,
              blend_out_seconds = 2,
              zoom_data = {
                StringLength = 1.5,
                CageRadius = 1.4,
                MaxCageRadius = 1.4,
                HeightOffset = 0.2,
                FocalOffset = 1,
                LockZoomLevel = true
              }
            })
          end
          Layers.ActivateLayer("QC010_CrowdBlockageB")
          do
            local hench = GetPlayerHenchman()
            if hench and hench:IsAlive() then
              local hench_trigger = self:GetEntityWithName("QC010_IsHenchmanNearCrowdTrigger", "marker")
              if hench_trigger and hench_trigger:IsAlive() then
                Trigger.SetToTriggerOnSpecificEntity(hench_trigger, hench)
                coroutine.yield()
                if hench and hench:IsAlive() and not Trigger.IsSpecificTriggerEntityInsideTriggerVolume(hench_trigger, hench) then
                  self:MoveAndRotateEntityToMarkerNamed(hench, "QC010_HenchmanInCrowdMarker")
                end
              end
            end
          end
          Timing.Wait(1)
          self:WaitFor(function()
            return self:IsCameraFacingAlley()
          end)
          Layers.ActivateLayer("QC010_RearMurgoCrowd")
          local rear_crowd = self:GetAllEntitiesWithNameIncluding("QC010_RearCrowdMember", "creature")
          for i, vill in ipairs(rear_crowd) do
            GossipEC.AddLabel(vill, "ChildhoodCrowdMember")
            Navigation.StopMoving(vill)
            Navigation.SetMovementPaused(vill, true)
            PhysicsCharacter.SetAsPushableByHero(vill, false)
            self.ParentQuest:StartNewEntityThread(vill:GetName(), QC010_RearCrowdMember)
          end
          self.ParentQuest:SetLookAtCamera({
            blend_in_seconds = 2,
            blend_out_seconds = 2,
            target_position = CVector3(172.68, 148.78, 51.8),
            source_position = CVector3(173.62, 149.13, 51.78)
          })
          self:RemoveObjectiveEntity(self:GetEntityWithName("QC010_HeroInCrowdTrigger", "marker"))
          local MurgoTimer = QuestManager.NewTimer(6)
          while 0 < MurgoTimer:GetTime() and not Player.GetLookAtButtonDown(QuestManager.HeroEntity) do
            coroutine.yield()
          end
          self.ParentQuest.StartMurgo = true
        end
        coroutine.yield()
      end
      self.CurrentState = 2
    elseif self.CurrentState == 2 then
      while not self.ParentQuest.BeginMurgoExpressions do
        if not Trigger.IsSpecificTriggerEntityInsideTriggerVolume(self.Entity, self.Rose) and Player.GetLookAtButtonDown(QuestManager.HeroEntity) then
          CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_SIMPLE, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_ALWAYS, {
            BlendInSeconds = 1,
            Position = CVector3(173.62, 149.13, 51.78),
            Focus = CVector3(172.68, 148.78, 51.8),
            PanAngle = 0.25
          })
          Timing.Wait(0.5)
          ScriptFunction.StopScriptControlledMovement(self.Rose)
          self:MoveAndRotateEntityToMarkerNamed(self.Rose, "QC010_RoseInCrowdMarker")
          CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_DEFAULT, EInteractiveCutsceneRuleScope.CUTSCENE_RULE_SCOPE_NORMAL)
        end
        coroutine.yield()
      end
      self.CurrentState = 3
    elseif self.CurrentState == 3 then
      if self.ParentQuest.BeginMurgoExpressions then
        ScriptFunction.StopAnyInteractiveCutscene(self:GetEntityWithName("QC010_Rose", "creature"))
        ScriptFunction.StopAnyInteractiveCutscene(self:GetEntityWithName("QC010_Theresa", "creature"))
        self.CurrentState = 4
      end
    elseif self.CurrentState == 4 then
      while not self.ParentQuest.EndMurgoExpressions do
        coroutine.yield()
      end
      self.ParentQuest:SetLookAtCamera({
        blend_in_seconds = 5,
        blend_out_seconds = 5,
        fov = 75,
        source_position = CVector3(170.42, 146.22, 51.37),
        target_position = CVector3(168.42, 146.23, 51.41)
      })
      self.CurrentState = 5
    elseif self.CurrentState == 5 then
      if self.ParentQuest.MurgoFinished then
        self.ParentQuest:ClearLookAtCamera()
        self.CurrentState = 6
      end
    elseif self.CurrentState == 6 then
      self.CurrentState = 8
    end
    coroutine.yield()
  end
end
QuestManager.NewEntityThread("QC010_EscortGuardFairfax")
function QC010_EscortGuardFairfax:Init()
  self.CurrentState = 0
end
function QC010_EscortGuardFairfax:CustomUpdate()
  PhysicsCharacter.SetAsPushableByHero(self.Entity, false)
  ScriptFunction.DisableSimBehaviours(self.Entity)
  Health.SetAsInvulnerable(self.Entity, true)
  while true do
    if self.CurrentState == 0 then
      self:PlayCutscene({
        Cutscene = "QC010_JeevesGreet"
      })
      self.CurrentState = 1
    elseif self.CurrentState == 1 then
    end
    coroutine.yield()
  end
end
function QC010_EscortGuardFairfax:OnTerminated()
  if MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_KILLED, self.Entity) then
  end
end
QuestManager.NewQuestThread("QC010_GenericEventManager")
function QC010_GenericEventManager:Init()
  self.QuestName = self.ParentQuest.QuestName
  self.CurrentState = 0
end
function QC010_GenericEventManager:Update()
  while true do
    if self.CurrentState == 0 then
      if self.ParentQuest.BCToShack then
        local shack_trigger = self:GetEntityWithName("QC010_ShackTrigger", "marker")
        local MusicBoxObjective = self:GetEntityWithName("QC010_MusicBoxObjective", "marker")
        local radius = Trigger.GetBoundingRadius(shack_trigger)
        QuestTracker.SetObjectiveBreadcrumbMaxAreaDrawRadius(QuestManager.HeroEntity, self.ParentQuest.QuestName, 2)
        QuestTracker.SetObjectiveBreadcrumbLargeAreaDrawLength(QuestManager.HeroEntity, self.ParentQuest.QuestName, 2)
        QuestTracker.SetObjectiveBreadcrumbAreaInitialAngle(QuestManager.HeroEntity, self.ParentQuest.QuestName, 1.6)
        QuestTracker.SetObjectiveBreadcrumbRadius(QuestManager.HeroEntity, self.ParentQuest.QuestName, radius)
        Trigger.SetToTriggerOnSpecificEntity(shack_trigger, QuestManager.HeroEntity)
        if shack_trigger and shack_trigger:IsAlive() and MusicBoxObjective and MusicBoxObjective:IsAlive() then
          self:UpdateObjectiveEntity(shack_trigger, MusicBoxObjective)
        end
        self.CurrentState = 1
      end
    elseif self.CurrentState == 1 then
      if self.ParentQuest.WakeUpSparrow then
        self:WaitForTimeInSeconds(3)
        Action.BreakSequence(QuestManager.HeroEntity, self.ParentQuest.SleepActionHandle)
        ScriptFunction.WaitForCurrentActionToFinish(QuestManager.HeroEntity)
        self.ParentQuest:SetDefaultCamera()
        if self.ParentQuest.PauseMenuDisabledKey then
          Player.ReEnableFullPauseMenu(QuestManager.HeroEntity, self.ParentQuest.PauseMenuDisabledKey)
          self.ParentQuest.PauseMenuDisabledKey = nil
        end
        ScriptFunction.DogSetMood(EDogMoodType.DOG_MOOD_TYPE_NORMAL)
        SACCamera.SetBehindHero = true
        ScriptFunction.DogStopStanding()
        ScriptFunction.StartCutscene({
          Entity = GetDog(),
          Cutscene = "QC010_DogWaits",
          WaitUntilStarted = false
        })
        self.ParentQuest.HeroWokeUp = true
        self.CurrentState = 2
      end
    elseif self.CurrentState == 2 and self.ParentQuest.BreadcrumbToExit then
      QuestTracker.ClearAllObjectiveEntities(QuestManager.HeroEntity, self.ParentQuest.QuestName)
      self.CurrentState = 3
    end
    coroutine.yield()
  end
end
QuestManager.NewQuestThread("QC010_PackRatThread")
function QC010_PackRatThread:Update()
  local pack_rat_activation_count = 15
  while true do
    if pack_rat_activation_count <= Inventory.GetNumberOfItemsOfCategory(QuestManager.HeroEntity, EInventoryCategory.EIC_ITEMS_FOOD_AND_DRINK) then
      break
    end
    self:WaitForTimeInSeconds(1)
  end
end
