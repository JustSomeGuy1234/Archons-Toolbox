﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.WindowsAPICodePack.Dialogs;

namespace Fable2SMM
{
    /// <summary>
    /// Interaction logic for InstallWindow.xaml
    /// </summary>
    public partial class InstallWindow : Window
    {
        public InstallWindow()
        {
            InitializeComponent();
        }

        private void ChooseFolderButton_Click(object sender, RoutedEventArgs e)
        {
            CommonOpenFileDialog dialogue = new CommonOpenFileDialog
            {
                IsFolderPicker = true,
                EnsurePathExists = true,
                Multiselect = false
            };

            CommonFileDialogResult result = dialogue.ShowDialog();
            if (result == CommonFileDialogResult.Ok)
                ModManaging.GameFolder = dialogue.FileName;
        }

        public static RoutedCommand InstallRunnerCmd = new RoutedCommand();
        private void InstallRunnerCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            ModManaging.InstallRunner();
        }

        public static RoutedCommand RestoreBackupCmd = new RoutedCommand();
        private void RestoreBackupCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("READ ME!\n\n" +
                "Uninstalling the manager and removing all mod files will not necessarily remove the mods from your savefile.\n\n" +
                "Well behaved mods *should* remove themselves when you next load in.\n\n" +
                "I recommend uninstalling each mod through the manager then loading your save and making sure everything works. If it does, save the game then uninstall the mod manager.", "READ ME"
            );

            if (MessageBox.Show("Are you sure you want to restore the gamescripts_r.bnk backup?", "Confirm", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                if (File.Exists(Gamescripts.GamescriptsPath))
                {
                    File.Copy(Gamescripts.GamescriptsBackupPath, Gamescripts.GamescriptsPath);
                }
            }
        }

        public static RoutedCommand UpdateRunnerCmd = new RoutedCommand();
        private void UpdateRunnerCmdExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            //string installedVersion = ModManaging.GetRunnerVersion();
            ModManaging.ExtractRunnerScripts();

        }
        private void UpdateRunnerCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = 
                Gamescripts.CurrentGamescriptsStatus == GamescriptsStatus.ORIGINAL ||
                Gamescripts.CurrentGamescriptsStatus == GamescriptsStatus.MANAGERINSTALLED ||
                Gamescripts.CurrentGamescriptsStatus == GamescriptsStatus.MODIFIED;
        }
    }
}
