
for k,v in pairs(CombatStyles) do
	if type(v) == "table" then 
		v.MinSecondsBetweenMeleeAttacks = .1
		v.SecondsToWaitAfterTargetIsHit = .1
	end
end

local troll_balance = CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_100]
	troll_balance.NumberOfTremors = 3
	troll_balance.NumberOfShockwaves = 4
	troll_balance.NumberOfRocks = 3
	troll_balance.ThrowAnimSpeedMultiplier = 1.5
	troll_balance.TimeBetweenShockwaves = 4
	troll_balance.RateOfFire = 1
	troll_balance.PoundAnimSpeedMultiplier = 1.5
	troll_balance.ShockwaveSpeed = 2
	troll_balance = CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_50]
	troll_balance.NumberOfTremors = 3
	troll_balance.NumberOfShockwaves = 7
	troll_balance.NumberOfRocks = 3
	troll_balance.ThrowAnimSpeedMultiplier = 2
	troll_balance.TimeBetweenShockwaves = 3
	troll_balance.RateOfFire = 1
	troll_balance.PoundAnimSpeedMultiplier = 2
	troll_balance.ShockwaveSpeed = 6
	troll_balance = CombatStyles.RockTroll.Balance[ETrollHealthStatus.TROLL_HEALTH_STATUS_25]
	troll_balance.NumberOfTremors = 3
	troll_balance.NumberOfShockwaves = 10
	troll_balance.NumberOfRocks = 3
	troll_balance.ThrowAnimSpeedMultiplier = 3
	troll_balance.TimeBetweenShockwaves = 1
	troll_balance.RateOfFire = 1
	troll_balance.PoundAnimSpeedMultiplier = 3
	troll_balance.ShockwaveSpeed = 6

if oldtremor then BehaviourTrollAttack.GetTremorAttack = oldtremor end
oldtremor = BehaviourTrollAttack.GetTremorAttack
function BehaviourTrollAttack:GetTremorAttack(roar)
	local tremor_action = oldtremor(self, roar)
	local mult = 1.5
	local troll_status = Troll.GetTrollStatus(self.Entity)
	if troll_status == ETrollHealthStatus.TROLL_HEALTH_STATUS_50 or troll_status == ETrollHealthStatus.TROLL_HEALTH_STATUS_25 then
		tremor_action.Actions[roar and 2 or 1].SpeedMultiplier = 3
	end
	return tremor_action
end

if oldattack then BehaviourTrollAttack.GetAttackAction = oldattack end
oldattack = BehaviourTrollAttack.GetAttackAction
function BehaviourTrollAttack:GetAttackAction()
	local attack = oldattack(self)
	attack.Actions[1].SpeedMultiplier = 3
	attack.Actions[1].ProjectileType = "ProjectileSwampTrollRight"
	attack.Actions[2].NumRocks = 3
	return attack
end

if oldinvulnerability then Troll.SetInvulnerable = oldinvulnerability end
oldinvulnerability = Troll.SetInvulnerable
function Troll.SetInvulnerable(ent, invuln)
	oldinvulnerability(ent, false)
end

-- for k,v in pairs(CombatStyles.Balverine.Sequences[CombatSituations.Melee]) do
-- 	CombatStyles.Balverine.Sequences[CombatSituations.Melee][k] = "BalverineFrenzy"
-- end