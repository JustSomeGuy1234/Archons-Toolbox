-- Limitations: 
-- 				None of the following is allowed: 
--					Multiline comments. Hex values. Functions. Operations. Variable values.  Return marks the end of the file. 
-- 				This is because this file gets interpreted manually by the manager, and I'm not writing a full thing for it (though it feels like I already have).

local runnerversion = 1
local installedmods = {

	
}

local installedmodules = {}
return installedmods, runnerversion