-- DeltaPatchGenerator.lua

--[[
Args:
origpath: The unmodified script path
newpath: The modified script path
outpath: The patch output path

Returns: A table containing each differing byte. This is most likely useless as the table is written to the output path to be loaded later by the game state.
--]]

local args = {...}
local origpath = args[1]
local newpath = args[2]
local outpath = args[3]
if not origpath or not newpath or not outpath then
	print("no source file or modded file or outpath provided")
	io.input()
	return
end

-- Load the original file and dump it into a string. Do the same with the modified version.
local loaded, err = loadfile(origpath)
if not loaded or err then error(err) end
local originaldumped = string.dump(loaded)

loaded, err = loadfile(newpath)
if not loaded or err then error(err) end
local newdumped = string.dump(loaded)


-- For each byte in our modified script, compare to the original. 
-- Any differences will be added appended to a string, in a `x = {offset, value}` format.
local patchtable = {}

print(#newdumped)
print(#originaldumped)
for offset=1, #newdumped do
	local newByte = newdumped:sub(offset, offset)
	if newByte ~= originaldumped:sub(offset, offset) then
		patchtable[#patchtable + 1] = {offset, newByte}
	end
end

-- Generate two strings for each byte to patch.
-- They will be concat'd into string form, creating two "tables" to be written to the patch file.
-- One will contain the offsets, the other will contain the values. Neither will have keys.
patchoffsetsegments = {}
patchvaluesegments = {}
local stripspaces = true
for patchbyte=1, #patchtable do
	local offset = patchtable[patchbyte][1]
	local newByte = patchtable[patchbyte][2]
	patchoffsetsegments[patchbyte] = offset
	patchvaluesegments[patchbyte] = string.byte(newByte)
end

-- Concat all strings to create the final string to write to the patch file
patchoffsettableconcat = table.concat(patchoffsetsegments, ",")
patchvaluetableconcat = table.concat(patchvaluesegments, ",")

local patchstring = "local len = " .. tostring(#newdumped) .. "\n"
patchstring = patchstring .. "local offsets = {\n    "
patchstring = patchstring .. patchoffsettableconcat .. "\n}\n"

patchstring = patchstring .. "local values = {\n    " .. patchvaluetableconcat .. "\n}\n"

patchstring = patchstring .. "\nreturn len, offsets, values"


local patchfile = io.open(outpath, "w")
patchfile:write(patchstring)
patchfile:close()

return patchtable