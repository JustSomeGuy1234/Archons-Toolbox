--[[ FPSCamera Aux ]]
function GetConfigMenuEntries()
	local function reload_mod()
		ModManager.GetModHandleWithName("FirstPersonCamera").VersionMinor = GetRandomNumber(10000000)
		ModManager.ReadInstalledMods()
	end

	return {
		MCM.NewActionEntry("Reload Mod", true, reload_mod, nil),
		MCM.NewActionEntry("Toggle First Person" .. MCM.FormatBool(IsEnabled), true, ToggleFirstPerson, nil),
		MCM.NewActionEntry("Set FOV", true, SetFOVWindow, nil),
		MCM.NewActionEntry("Set Sensitivity (" .. tostring(Sensitivity*100) .. "%)", true, SetSensitivityWindow, nil),
		MCM.NewActionEntry("Set Body Visibility (" .. tostring(BodyVisibility * 100) .. "%)", true, SetBodyVisibilityWindow, nil),
		MCM.NewActionEntry("Force True Position" .. MCM.FormatBool(ForceUseTrueHeadPosition), true, MCM.SetValue, {getfenv(1), "ForceUseTrueHeadPosition", not ForceUseTrueHeadPosition}),
		MCM.NewActionEntry("Third Person Combat" .. MCM.FormatBool(UseThirdPersonCombat), true, MCM.SetValue, {getfenv(1), "UseThirdPersonCombat", not UseThirdPersonCombat}),
		MCM.NewActionEntry("Invisible Dog" .. MCM.FormatBool(MakeDogInvisible), true, MCM.SetValue, {getfenv(1), "MakeDogInvisible", not MakeDogInvisible}),
		MCM.NewActionEntry("Toggle Debug" .. MCM.FormatBool(Debugging), true, MCM.SetValue, {getfenv(1), "Debugging", not Debugging}),
	}
end

function SetFOVWindow()
	local returnedAmount, user_accepted = GUI.AskForAmount(getfenv(1), 
		{Type = EAdjusterTypes.ADJUSTER_TYPE_MONEY, MinVal = 60, MaxVal = 179, Increment = 1, DefaultVal = 75, ShowSign = false}, 
		"Set FOV", 1
	)
	if user_accepted then
		ScriptFunction.WaitForTimeInSeconds(.7)
		FirstPersonModFOV = returnedAmount
	end
end
function SetBodyVisibilityWindow()
	local returnedAmount, user_accepted = GUI.AskForAmount(getfenv(1), 
		{Type = EAdjusterTypes.ADJUSTER_TYPE_PERCENTAGE, MinVal = 0, MaxVal = 100, Increment = 1, DefaultVal = BodyVisibility * 100, ShowSign = false}, 
		"Set Body Transparency", 1
	)
	if user_accepted then
		ScriptFunction.WaitForTimeInSeconds(.5)
		BodyVisibility = returnedAmount / 100
		ScriptFunction.WaitForTimeInSeconds(.5)
	end
end
function SetSensitivityWindow()
	local returnedAmount, user_accepted = GUI.AskForAmount(getfenv(1), 
		{Type = EAdjusterTypes.ADJUSTER_TYPE_PERCENTAGE, MinVal = 1, MaxVal = 100, Increment = 1, DefaultVal = Sensitivity * 100, ShowSign = false}, 
		"Set Camera Sensitivity", 1
	)
	if user_accepted then
		ScriptFunction.WaitForTimeInSeconds(.5)
		Sensitivity = returnedAmount / 100
	end
end