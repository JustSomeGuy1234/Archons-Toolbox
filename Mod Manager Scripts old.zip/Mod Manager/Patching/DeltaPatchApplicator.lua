-- DeltaPatchApplicator.lua
print("\n")
-- print = function() end
local args = {...}
local scriptpath = args[1]
local patchpath = args[2]
if not scriptpath or not patchpath then
	error("No source or modded file passed")
end

local overwrite_print = false
if overwrite_print then
	print = function() end
end

local scriptdumped = string.dump(loadfile(scriptpath))
local scriptlen,patchoffsets,patchvalues = loadfile(patchpath)()

--  Split entire script up into chars
local scripttable = {}
for i=1,#scriptdumped do
	if scriptlen < i then break end
	scripttable[i] = scriptdumped:sub(i,i)
end

-- For debugging. Called when when a value is written to an offset.
local scriptwriteproxy = {}
function scriptwriteproxy.__newindex(_, key, value)
	-- print("Setting offset " .. tostring(key) .. " to " .. tostring(string.byte(value)))
	rawset(scripttable, key, value)
end
setmetatable(scriptwriteproxy, scriptwriteproxy)

--[[ 
For each value in the patchvalues table, get the offset from the patchoffset table and insert it into the script char table

pos: pos tracks position in file, similar to working with file streams.

Offsets in the patchoffsets table are relative to the previous offsets.
	This means that offsets = {1,1005,2,50} would correspond to scripttable[1,1006,1008, and 1058].
	This is beneficial as there's no need to represent huge offsets more than once, saving space.
If an offset is negative the buffer var is set to its absolute value. totalbuffer is increased by the same amount.

buffer: If buffer is > 0, simply increment pos, write the current value, and decrease buffer by 1.
    This means that -x number of bytes should be written consecutively, incrementing pos by one for each. 
	This means we can store {100,-7,15}, instead of {100,1,1,1,1,1,1,1,15}.

totalbuffer: In the above example patchoffsets[3] (the 15) corresponds to patchvalues[9].
	To track this, we use totalbuffer to see how many buffer bytes there have been.
	In the above example we have 7 buffer bytes, so we store 6 (rather than 7, as the offset byte still uses an index in the offset table)
	Then we do (i - totalbuffer) to figure out which index in the offset table we should read next.
--]]

local buffer = 0
local totalbuffer = 0
local pos = 0
for k,v in ipairs(patchvalues) do
	val = v
	if buffer > 0 then
		pos = pos + 1
		scriptwriteproxy[pos] = string.char(val)
		buffer = buffer - 1
		-- print("buffer = " .. tostring(buffer))
	else
		local rel_off = patchoffsets[k-totalbuffer]
		if rel_off < 0 then
			-- print("Triggered consec, len: " .. tostring(buffer))
			buffer = math.abs(rel_off) - 1
			pos = pos + 1
			scriptwriteproxy[pos] = string.char(val)
			totalbuffer = totalbuffer + buffer
		else
			pos = pos + rel_off
			scriptwriteproxy[pos] = string.char(val)
		end
	end
end

local finalstring = table.concat(scripttable)
local result = loadstring(finalstring)

if not result then
	error("\n\nFailed to compile patched script! I cannot provide further information from here.\n\nIf you're a mod author, check the log from the GUI state after generating your patch.")
	return
else
	print("Patch applied, function value: " .. tostring(result))
end
return result