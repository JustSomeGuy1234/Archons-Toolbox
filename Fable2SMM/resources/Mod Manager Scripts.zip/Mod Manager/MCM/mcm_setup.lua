-- This borrows a lot of code from the Debug Menu mod. Perhaps it's a good indicator that a lot of this should be in MultipageMenu by default.

local multimenu = require("MultipageMenu")
local manager
do
	local tmp = {...}
	manager = tmp[1]
end

-- OptionSets basically contains each mod's main EntryAction that opens their menus
OptionSets = {
	-- { TextTag = "Some Mod", Enabled = true, Func = OpenMenu, Args = {"Some Menu", GetMyModsOptionsFunc}, Key = "MyModKey"}, <-- Created by EntryAction
}

function CustomUpdate()
	while true do
		coroutine.yield()
		if Player.IsInFirstPerson(QuestManager.HeroEntity) or Debug.GetUseFreeCamera() then
			local pressed_x, message = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_GENERIC_X_BUTTON_PRESSED, LastMessageID_PressedXButton)
			if pressed_x and (Timing.GetWorldFrame() == message:GetTimeStamp()) then
				LastMessageID_PressedXButton = message:GetID()
				Debug.SetDrawGUI(true)
				FrameMenuOpened = Timing.GetWorldFrame()
				OpenMenu("Mod Configuration Menu", CreateMenuFromOptionSets)
				CloseAll = false
			end
		end
	end
end


function OpenMenu(title, entriesfunction, singleoption)
	local entriesfunctiontype = type(entriesfunction)
	if entriesfunctiontype ~= "function" then
		GUI.DisplayMessageBox("MCM: Something tried to open a menu but entriesfunction was an invalid type: " .. entriesfunctiontype)
		ScriptFunction.WaitForTimeInSeconds(.5)
		return
	end
	local result, entries, worked, last_selected_entry
	local lastpage = 0
	while result ~= 0 and not CloseAll do
		worked, entries = pcall(entriesfunction)
		if not worked then
			GUI.DisplayMessageBox("MCM: Something tried to open a menu but the entriesfunction threw an error:\n\n" .. entries)
			ScriptFunction.WaitForTimeInSeconds(.5)
			return
		end

		-- if title arg is a function then set menu title to its return value.
		local finaltitle = title or "no title"
		if type(title) == "function" then
			local title_worked, title_or_error = pcall(title)
			if not worked then
				GUI.DisplayMessageBox("MCM: A menu's title function threw an error!\n\n" .. tostring(title_or_error))
			else
				finaltitle = tostring(title_or_error or "nil title value")
			end
		end

		result, lastpage = multimenu.ShowMenuBoxWithPages(finaltitle, entries, false, lastpage, SlowMenu)
		if result == 0 then break end
		last_selected_entry = entries[result]
		HandleEntry(last_selected_entry)
		if singleoption then break end

		-- If user clicked right stick, process final choice then end. This only occurs on the current menu, but CloseAll is set to true so all menus close.
		local is_posted, message = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_GENERIC_RIGHT_STICK_PRESSED, LastStickID)
		if is_posted and message:GetTimeStamp() - FrameMenuOpened > 0 then 
			LastStickID = message:GetID()
			CloseAll = true
		end
		coroutine.yield()
	end
	return last_selected_entry
end


function AddOptionSet(set, key)
	-- set = { Key = "key", {TextTag = "My Mod", Enabled = bool, Func = MCM.OpenMenu, Args = GetMyModsEntries } }
	if type(set) ~= "table" then
		GUI.DisplayMessageBox("A mod tried to add an invalid option set to the mcm! " .. tostring(getfenv(2).ScriptName or "noscriptname"))
		return false, "set isn't a table"
	elseif not key and not set.Key then
		GUI.DisplayMessageBox("A mod tried to add an option set without a key! " .. tostring(getfenv(2).ScriptName) or "noscriptname")
		return false, "no key was passed"
	end
	set.Key = set.Key or key

	for k,v in pairs(OptionSets) do
		if v.Key == key then
			return false, "option set with that key already exists"
		end
	end
	table.insert(OptionSets, set)
end
function RemoveOptionSet(key)
	for k,v in pairs(OptionSets) do
		if v.Key == key then
			table.remove(OptionSets, k)
			return true
		end
	end
	return false
end
function CreateMenuFromOptionSets()
	local menu = {}
	for k,v in ipairs(OptionSets) do
		table.insert(menu, v)
	end
	return menu
end

function HandleEntry(entry)
	if type(entry.Function) == "function" then

		-- create a coroutine from a closure functions so we can *safely* call the function while supporting yields
		local function temp_func(func, args)
			if type(args) == "table" then
				func(unpack(args))
				-- GUI.DisplayMessageBox("Called a function successfully and exiting (" .. tostring(func) .. " | " .. tostring(args))
				-- ScriptFunction.WaitForTimeInSeconds(.5)
			else
				func(args)
				-- GUI.DisplayMessageBox("Called a function successfully and exiting (" .. tostring(func) .. " | " .. tostring(args))
				-- ScriptFunction.WaitForTimeInSeconds(.5)
			end
			return true
		end
		local temp_co = coroutine.create(temp_func)

		-- resume the coroutine closure until either true or an error is returned
		local resumed, return_code = coroutine.resume(temp_co, entry.Function, entry.Args)

		while resumed and return_code ~= true do
			resumed, return_code = coroutine.resume(temp_co)
			if return_code ~= nil and return_code ~= true then
				GUI.DisplayMessageBox("A mod's MCM function returned: " .. tostring(return_code))
				return return_code
			end
			coroutine.yield()
		end
	end
end

function NewActionEntry(text, enabled, func, args)
	local entry = {}
	if type(text) == "string" then
		entry.TextTag = text

		if type(enabled) == "boolean" then
			entry.Enabled = enabled
		else
			entry.Enabled = true
		end

		if not func then
			entry.TextTag = text .. " (nil function)"
		else
			entry.Function = func
		end
		entry.Args = args

		return entry
	else
		return "Malformed entry"
	end
end

function FormatBool(thebool)
	if type(thebool) == "boolean" then
		return " (" .. tostring(thebool)  .. ")"
	else
		return ""
	end
end

-- Mod Data Display funcs
function DisplayModData(mod_handle)
	local infostring = ""
	for k,v in pairs(mod_handle) do
		infostring = infostring .. tostring(k) .. " = " .. tostring(v) .. " |\n"
	end
	GUI.DisplayMessageBox(infostring)
	ScriptFunction.WaitForTimeInSeconds(.5)
end
function GetModListEntries()
	local mods = manager.GetAllMods()
	local entries = {}
	for k,v in pairs(mods) do
		entries[#entries+1] = NewActionEntry(v.NameID, true, DisplayModData, {v})
	end
	return entries
end

function GetModManagerMenuEntries()
	return {
		NewActionEntry("Recheck Mod Status", true, manager.ReadInstalledMods, nil),
		NewActionEntry("Portable Mode" .. FormatBool(manager.Portable), true, SetValue, {manager, "Portable", not manager.Portable}),
		NewActionEntry("Reload Manager", true, manager.ReloadRunner, nil),
		NewActionEntry("Show All Running Mods", true, OpenMenu, {"Mod Info", GetModListEntries}),
		NewActionEntry("Unfreeze Hero", true, manager.ModMetatable.ModMisc.UnstuckHero, nil),
		Key = "ModManagerOptions"
	}
end

function SetValue(tab, key, value)
	tab[key] = value
end

function AddModToMCM(handle)
	local entry, key = manager.GetModMCMEntryAndKey(handle)
	if entry and key then
		AddOptionSet(entry, key)
		-- GUI.DisplayMessageBox("Adding option set for mod: " .. tostring(handle.NameID) .. " with key " .. tostring(key))
	else
		-- GUI.DisplayMessageBox("NOT actually adding option set for mod: " .. tostring(handle.NameID) .. " with key " .. tostring(key))
	end
end
function RemoveModFromMCM(handle)
	local _, key = manager.GetModMCMEntryAndKey(handle)
	if key then
		RemoveOptionSet(key)
	end
end