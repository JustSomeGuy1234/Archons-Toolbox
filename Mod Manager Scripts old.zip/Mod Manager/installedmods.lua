-- Limitations: 
-- 				None of the following is allowed: 
--					Multiline comments. Hex values. Functions. Operations. Variable values.  Return marks the end of the file. 
-- 				This is because this file gets interpreted manually by the manager, and I'm not writing a full thing for it (though it feels like I already have).

local runnerversion = 1
local installedmods = {
	FirstPersonCamera = {
Enabled = true, Installed = true, ClearData = false, Static = true,
NameID = "FirstPersonCamera",
StartScriptPath = "startcamera.lua",
VersionMajor = 1,
VersionMinor = 69,
Author = "Guy",
},
	FishingMod = {
Enabled = true, Installed = true, ClearData = false,
NameID = "FishingMod",
StartScriptPath = "main.lua",
VersionMajor = 1,
VersionMinor = 4,
Author = "Guy",
},
--[[
	Chickenpocalypse = {
		Enabled = false, Installed = false, ClearData = false, Static = false,
		NameID = "Chickenpocalypse", StartScriptPath = "ChickenRain.lua", VersionMajor = 1, VersionMinor = 1, 
		Files = {
			"scripts/Mods/Chickenpocalypse/ChickenRain.lua",
		},
	},
	ChildhoodPatch = {
		Enabled = false, Installed = false, ClearData = false, Static = true,
		NameID = "ChildhoodPatch", StartScriptPath = "start.lua", VersionMajor = 1, VersionMinor = 1, 
		Files = {
			"scripts/Mods/ChildhoodPatch/start.lua",
			"scripts/Mods/ChildhoodPatch/patch.lua",
		},
	},
	DogTeleporter = {
		Enabled = true, Installed = true, ClearData = false, Static = true,
		NameID = "DogTeleporter", StartScriptPath = "start.lua", VersionMajor = 1, VersionMinor = 3, 
		Files = {
			"scripts/Mods/DogTeleporter/start.lua",
		},
	},

	OrbSucker = {
		Enabled = true, Installed = true, ClearData = false, Static = false,
		NameID = "OrbSucker", StartScriptPath = "start.lua", VersionMajor = 1, VersionMinor = 1, 
		Files = {
			"scripts/Mods/OrbSucker/start.lua",
		},
	},

	TestMod = { NameID = "TestMod", StartScriptPath = "start.lua", VersionMajor = 1, VersionMinor = 3, 
		Enabled = false, Installed = false, ClearData = false, Static = false,
		Files = {
			"scripts/Mods/TestMod/start.lua",
		},
	},--]]
	
	RuntimeCodeRunner = { NameID = "RuntimeCodeRunner", StartScriptPath = "CodeLoader.lua", VersionMajor = 1, VersionMinor = 2, 
		Enabled = true, Installed = true, ClearData = false, Static = false,
		Files = {
			"scripts/Mods/RuntimeCodeRunner/CodeLoader.lua",
			"scripts/Mods/RuntimeCodeRunner/RuntimeCode.lua",
		},
	},
}

local installedmodules = {}
return installedmods, runnerversion