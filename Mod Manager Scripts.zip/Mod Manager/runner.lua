--[[
The aim of the manager is to make script mod creation and installation extremely simple, while also expanding on the games functionality.

Flow:
	On game start/load, GeneralScriptManager.lua runs startrunner.lua if the runner script is not running already
	The startrunner.lua script sets this script up (the runner script) to be in its own fenv then runs it
	The runner script adds its Update() function to GeneralScriptManager.AddScript, so it is automatically called every tick

	When the game reloads, GeneralScriptManager finds this runner script and calls the ReadInstalledMods() function (I may also add the ability to call this on demand for runtime mod management)
	The ReadInstalledMods function runs the InstalledMods.lua file, which contains info about which mods should be installed/enabled.
	For every entry in InstalledMods, if the mod should be installed and enabled, set up the mods startup script to be in its own fenv and run it.
	When setting up the mod, it creates a "handle" (name is wip) that basically contains info about the mod such as mod name, version etc.
	Add the mod handle to the CurrentlyRunningMods chain.

	The Update function (coroutine actually) calls the CustomUpdate function (also a coroutine) and catches any errors.
	The CustomUpdate function iterates through each handle in the CurrentlyRunningMods chain to resume each mods ModUpdate coroutine, every tick.
	It also iterates through the ModHooks script chain and does all that stuff. (logic is defined in modhooks.lua, which is run by modmetatable.lua, which is run by this script)


That's a very simplified explanation. The runner also disables and uninstalls mods depending on what InstalledMods says, allows mods to retain data when updating, etc.

--]]

--[[ 
TODO:
(done?): Add version checking for the manager itself. Probably done with InstalledMods?
Make something for modules
Add an option to delete uninstall data *without* having to reinstall the mod with the clean option
Test reloading the mod manager: Uninstall data, Disabled mods
Add a menu (should be openable at any time)

--]]

-- Version MUST be on its own line in the format of ^Version = \d$ -- This is because the manager needs to read it to find what's installed.
Version = 1
ScriptName = "ModManagerRunner"
ModsFolder = "scripts/Mods/"
self = getfenv(1)
-- menu = require "MultipageMenu"

local passed = {...}
DisabledMods = {}
UninstalledMods = {}
StaticMods = {}

-- Mod Metatable should contain mod-related things that mods can access
ModMetatable = {}
setmetatable(ModMetatable, ModMetatable)
ModMetatable.__index = function(the_table, key)
	local in_mt = rawget(ModMetatable, key)
	if in_mt then
		return in_mt
	else
		return _G[key]
	end
end
ModMetatable.ModManager = self

local meta_script = loadfile("scripts/Mod Manager/modmetatable.lua")
if type(meta_script) ~= "function" then
	GUI.DisplayMessageBox("mod metatable script failed to compile!")
	return false
end
setfenv(meta_script, ModMetatable)
meta_script()

local overridenrequire, overridewhynot = pcall(ModMetatable.Patching._OverrideRequire)
if not overridenrequire then
	GUI.DisplayMessageBox(tostring("Failed to override `require` for patching:\n" .. tostring(overridewhynot)))
end
-- local patched, patcherr = ModMetatable.Patching.AddPatch("scripts/quests/qc010_childhood.lua", "scripts/Mods/ChildhoodPatch/patch.lua", "mychildhoodpatch")
-- GUI.DisplayMessageBox(tostring(patched or "") .. " : " .. tostring(patcherr or ""))


-- Update function is just a layer of error handling for the real update function, CustomUpdate. (which are actually both coroutines)
function Update()
	custom_update = coroutine.create(CustomUpdate)
	while not ShouldDie do
		coroutine.yield()
		ManagerWorked, ManagerWhyNot = coroutine.resume(custom_update, self)
		if not ManagerWorked then
			GUI.DisplayMessageBox("Mod Manager Runner error! Reason:\n " .. tostring(ManagerWhyNot))
			ShouldDie = true
		end
	end
	coroutine.yield()
end

function CustomUpdate()
	ReadInstalledMods()
	while not ShouldDie do
		coroutine.yield()
		ModMetatable.ModHooks.UpdateHooks()
		UpdateMods()
	end
end

-- Why reinvent the wheel? Let's just use the game's manager technique. I imagine this is more efficient than using pairs.
function UpdateMods()
	local l = CurrentlyRunningMods
	local successful_run, error_message
	while l do
		if l and not l.value then
			GUI.DisplayMessageBox("a handle has no value!\nName: " .. tostring(l.NameID))
			RemoveModFromChain(nil, l)
			break
		end
		if l.value.mod_update and coroutine.status(l.value.mod_update) == "dead" then
			UninstallMod(l.NameID)
		elseif l.value.mod_update then
			successful_run, error_message = coroutine.resume(l.value.mod_update, l.value)
		else
			GUI.DisplayMessageBox(tostring("Mod " .. l.NameID .. " was missing ModUpdate coroutine!"))
			UninstallMod(l.NameID)
		end
		if not successful_run then
			GUI.DisplayMessageBox(error_message)
		end
		l = l.next
	end
end

-- [[ Loads a script and sets its fenv to a new table ]]
function LoadScriptIntoFuncAndTab(fullpath)
	local modtab = {}
	local modfunc = loadfile(fullpath)
	if type(modfunc) ~= "function" then
		GUI.DisplayMessageBox("Couldn't run " .. tostring(fullpath) .. "\n\nMake sure it compiles, the path is right, and it is added to dir.manifest")
		return
	end
	setfenv(modfunc, modtab) 
	setmetatable(modtab, ModMetatable)
	return modfunc, modtab
end

-- [[ Create the mod's main coroutine and the mod's "handle" (node), then add it to the update chain ]]
function CreateModHandle(mod_table, installinfo)
	if IsModEnabled(installinfo.NameID) then
		GUI.DisplayMessageBox("A mod named: \"" .. (installinfo.NameID or "noname") .. "\" Is already active and running!")
		return false
	elseif DisabledMods[installinfo.NameID] then
		GUI.DisplayMessageBox("A mod named: \"" .. (installinfo.NameID or "noname") .. "\" Is installed but disabled!")
		return false
	end
	if type(mod_table.ModUpdate) ~= "function" and not installinfo.Static then
		GUI.DisplayMessageBox("A mod named: \"" ..  (installinfo.NameID or "noname") .. "\" had an invalid ModUpdate function (" .. tostring(mod_table.ModUpdate) .. "), and is not Static.")
		return false
	end

	if not installinfo.Static then
		mod_table.mod_update = coroutine.create(mod_table.ModUpdate)
	end
	local handle = {
		prev = CurrentlyRunningModsEnd,
		value = mod_table,
		VersionMajor = installinfo.VersionMajor,
		VersionMinor = installinfo.VersionMinor,
		NameID = installinfo.NameID,
		Static = installinfo.Static
	}
	return true, handle
end
function InsertMod(mod_handle)
	local old_list_end = CurrentlyRunningModsEnd
	CurrentlyRunningModsEnd = mod_handle
	if CurrentlyRunningMods == nil then
		CurrentlyRunningMods = CurrentlyRunningModsEnd
	end
	if old_list_end ~= nil then
		old_list_end.next = CurrentlyRunningModsEnd
	end
end

--[[ Move a mod from the DisabledMods table, and insert it into the script chain ]]
function EnableMod(name)
	local handle = DisabledMods[name]

	if DisabledMods[name] == nil then
		if GetModHandleWithName(name) or StaticMods[name] then
			-- Should we log an error here? A mod shouldn't be enable-able if it's already running.
			-- Should we call the mod's Enable function again?
			DisabledMods[name] = nil
			return true
		end
		GUI.DisplayMessageBox("Mod Manager tried to enable non-existant mod " .. tostring(name))
		return false
	end

	if not handle.Static then
		InsertMod(handle)
	end
	if handle.value.Enable then
		local enablefuncworked, whynot = pcall(handle.value.Enable)
		if not enablefuncworked then
			GUI.DisplayMessageBox(tostring(name or "NoModName") .. "'s Enable function has failed:\n" ..
														tostring(whynot or "NOREASON"))
		end
	end
	return true
end
function IsModEnabled(name)
	local modhandle = GetModHandleWithName(name) or StaticMods[name]
	if modhandle then
		return true, modhandle
	else
		return false
	end
end

function RemoveModFromChain(name, alt_handle)
	local l = alt_handle or GetModHandleWithName(name)
	if not l then return nil, false end
	-- Remove the mod from the update chain
	if l.next then
		l.next.prev = l.prev
	end
	if l.prev then
		l.prev.next = l.next
	end
	if CurrentlyRunningMods == l then
		CurrentlyRunningMods = l.next
	end
	if CurrentlyRunningModsEnd == l then
		CurrentlyRunningModsEnd = l.prev
	end
	if l.value then
		if l.value.Disable then
			pcall(l.value.Disable, l.value)
		end
	end
	return l, true
end
function DisableMod(name)
	local handle, removed = RemoveModFromChain(name)
	if not removed then
		handle = StaticMods[name]
		if handle then
			StaticMods[name] = nil
			removed = true
		end
	end

	if removed then
		DisabledMods[handle.NameID] = handle
		return true, handle
	else
		return false
	end
end
function IsModDisabled(name)
	local disabledmod = DisabledMods[name]
	if disabledmod then
		return true, disabledmod
	else
		return false
	end
end

function UninstallMod(modname, force_delete)
	local mod = GetModHandleWithName(modname) or DisabledMods[modname]
	if mod then
		if mod.value.Uninstall then
			local uninst_success, uninst_data
			uninst_success, uninst_data = pcall(mod.value.Uninstall, mod.value)
			if not force_delete and not mod.ClearData then
				UninstalledMods[modname] = uninst_data
			else
				DeleteUninstallData(modname)
			end
		end
		RemoveModFromChain(modname)
		DisabledMods[modname] = nil
		return true
	else
		return false
	end
end
function GetUninstallData(modname)
	return UninstalledMods[modname]
end
function DeleteUninstallData(modname)
	UninstalledMods[modname] = nil
end
function IsModUninstalled(modname)
	local uninstalldata = UninstalledMods[modname]
	if uninstalldata then
		return true, uninstalldata
	else
		return false
	end
end

function ReadInstalledMods()
	GUI.DisplayMessageBox("DEBUG: ReadInstalledMods called!")
	local installed_script = loadfile("scripts/Mod Manager/installedmods.lua")
	if type(installed_script) ~= "function" then
		GUI.DisplayMessageBox("installedmods.lua failed to compile!")
		return false
	end

	-- TODO: This should be a pcall
	local installedmods, targetver = installed_script()

	if Version ~= targetver then
		GUI.DisplayMessageBox("DEBUG: InstalledMods says there's a new version of the runner, reloading from file and passing mod data!")
		local save = Terminate()
		_,t = pcall(loadfile("scripts/Mod Manager/startrunner.lua"), save)
		return
	end

	-- Update mods, and also create a table for easy indexing to see if a mod doesn't exist in installedmods anymore.
	local runningmodstmp = {}
	for modname, installinfo in pairs(installedmods) do
		UpdateModInstallation(modname, installinfo)
		runningmodstmp[installinfo.NameID] = true
	end

	local node = CurrentlyRunningModsEnd
	while node do
		local found = (runningmodstmp[node.NameID] or DisabledMods[node.NameID] or UninstalledMods[node.NameID]) ~= nil
		if not found then
			-- We have a mod saved, but it isn't in installedmods anymore. With permission we should delete it.
			if GUI.AskYesNoQuestion("A mod with ID " .. node.NameID .. " seems to have been deleted. Would you like to remove it from your save?", {}) then
				UninstallMod(node.NameID, true)
			end
		end
		node = node.prev
	end
end

function UpdateModInstallation(modname, installinfo)
	if installinfo.Installed and installinfo.Enabled then
		-- If mod wants to be running
		local ismodrunning, runninghandle = IsModEnabled(modname)
		local ismoddisabled, disabledhandle = IsModDisabled(modname)
		local ismoduninstalled, uninstalldata = IsModUninstalled(modname)
		local _
		local handle = runninghandle or disabledhandle
		if ismodrunning or ismoddisabled then
			-- VERSION CHECK
			if handle.VersionMajor ~= installinfo.VersionMajor or handle.VersionMinor ~= installinfo.VersionMinor then
				-- We need to update
				GUI.DisplayMessageBox("DEBUG: Updating mod because of differing version: " .. modname .. 
					"\nStored: " .. tostring(handle.VersionMajor or "nomajor") .. "." .. tostring(handle.VersionMinor or "nominor") .. 
					"\nNew: " .. tostring(installinfo.VersionMajor or "nomajor") .. "." .. tostring(installinfo.VersionMinor or "nominor")
				)
				UninstallMod(modname)
				_, handle = InstallMod(modname, installinfo)
			end

			if ismodrunning then
				-- do nothing
			else
				EnableMod(modname)
			end
		else
			-- Mod is not installed.
			InstallMod(modname, installinfo)
		end
	elseif installinfo.Installed and not installinfo.Enabled then
		-- If mod wants to be disabled but installed still.
		DisableMod(modname)
	elseif not installinfo.Installed then
		UninstallMod(modname)
	end
end

-- [[ Calls a mod's setup, creates its handle, and if not static inserts it into the script chain ]]
function InstallMod(modname, installinfo)
	local modfunc, modtab = LoadScriptIntoFuncAndTab(ModsFolder .. installinfo.NameID .. "/" .. installinfo.StartScriptPath)
	local uninstalldata = GetUninstallData(modname)
	if not modfunc then 
		GUI.DisplayMessageBox("Failed to run \"" .. tostring(modname) .. "\"s start script.")
		return false
	end

	local script_worked, error_message
	if installinfo.ClearData then
		script_worked, error_message = pcall(modfunc)
	else
		script_worked, error_message = pcall(modfunc, uninstalldata)
	end
	if not script_worked then
		return GUI.DisplayMessageBox("Mod failed to initialize!\n" .. tostring(modname) .. "\n\n" .. tostring(error_message))
	end
	DeleteUninstallData(modname)

	local creation_success, handle = CreateModHandle(modtab, installinfo)
	if creation_success and installinfo.Enabled and not installinfo.Static then
		InsertMod(handle)
	elseif installinfo.Static then
		StaticMods[modname] = handle
	end

	return creation_success, handle

end

function GetModHandleWithName(name, all)
	local all_occurances = {}
	local curscript = CurrentlyRunningMods
	while curscript do
		if curscript.NameID == name then
			if all then
				all_occurances[#all_occurances+1] = curscript
			else
				return curscript, true
			end
		end
		curscript = curscript.next
	end
	if all then
		all_occurances[#all_occurance+1] = DisabledMods[name]
		return all_occurances
	end
	if StaticMods[name] then 
		return StaticMods[name]
	end
	return DisabledMods[name], false
end

function OnSaveLoad()
	ReadInstalledMods()
	ModMetatable.ModHooks.OnSaveLoad()
end

function Terminate()
	ShouldDie = true
	return {RunningMods = GetRunningMods(), StaticMods = StaticMods, DisabledMods = DisabledMods, UninstalledMods = UninstalledMods, Hooks = ModMetatable.ModHooks.Hooks}
end

function ReloadRunner()
	local runnerfunc = loadfile("scripts/Mod Manager/runner.lua")
	if type(runnerfunc) ~= "function" then
		GUI.DisplayMessageBox("Couldn't run ModManager Runner script!")
		return
	end
	local old_vals = Terminate()
	local runnertab = {}
	setfenv(runnerfunc, runnertab)
	setmetatable(runnertab,runnertab)
	runnertab.__index = _G
	runnertab._G = _G
	runnerfunc(old_vals)
	GeneralScriptManager.AddScript(runnertab)
	runnertab.ReadInstalledMods()
end

function GetRunningMods()
  local save_table = {}
  local mod_script = CurrentlyRunningMods
  while mod_script do
    save_table[#save_table + 1] = mod_script
    mod_script = mod_script.next
  end
  return save_table
end
function LoadRunningMods(save_table)
	CurrentlyRunningMods = nil
	CurrentlyRunningModsEnd = nil
	for k, v in ipairs(save_table) do
		if v.NameID and v.value and v.VersionMajor and v.VersionMinor then
			InsertMod(v)
		else
			GUI.DisplayMessageBox("A mod handle from the savetable is malformed!\n\n" ..
				"\nNameID: " .. tostring(v.NameID) ..
				"\nvalue: " .. tostring(v.value) ..
				"\nVersionMajor: " .. tostring(v.VersionMajor) ..
				"\nVersionMinor: " .. tostring(v.VersionMinor))
		end
	end
end

if type(passed[1]) == "table" then
	passed = passed[1]
	LoadRunningMods(passed.RunningMods)
	DisabledMods = passed.DisabledMods
	UninstalledMods = passed.UninstalledMods
	StaticMods = passed.StaticMods
	ModMetatable.ModHooks.Hooks = passed.Hooks

	local mods = ""
	for k,v in pairs(passed.RunningMods) do
		mods = mods .. tostring(k) .. "\n"
	end
	GUI.DisplayMessageBox("Loading mods:\n\n" .. mods)
end

--ReadInstalledMods()

GUI.DisplayMessageBox("Manager Runner v" .. tostring(Version) .. " has run for the first time!")