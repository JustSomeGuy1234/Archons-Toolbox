-- DeltaPatchApplicator.lua
print("\n")
-- print = function() end
local args = {...}
local scriptpath = args[1]
local patchpath = args[2]
if not scriptpath or not patchpath then
	error("No source or modded file passed")
end

local overwrite_print = false
if overwrite_print then
	print = function() end
end

local scriptdumped = string.dump(loadfile(scriptpath))
local scriptlen,patchoffsets,patchvalues = loadfile(patchpath)()

--  Split entire script up into chars
local scripttable = {}
for i=1,#scriptdumped do
	if scriptlen < i then break end
	scripttable[i] = scriptdumped:sub(i,i)
end

-- Replace the bytes in the script with those provided by the patch
-- Offsets are relative to their preceeding byte's offset
-- A negative offset means that there are (offset) number of bytes in a row, so we needn't store their offsets
-- Consecs corrects the index of the values with the offsets.
-- E.g. If we had offsets[1],[2],[3],[4] containing 5000,1,-3,20 respectively, this would correspond to values[1],[2],[3],[4],[5],[6]
--		So then offsets[5] would correspond to values[7..]
local consecs = 0
local pos = 0
local value
for i=1, #patchoffsets do
	local offsetval = patchoffsets[i]
	if offsetval < 0 then
		-- We need to replace an array of bytes, or just one byte
		local numofbytes = math.abs(offsetval)
		print("starting a streak as we have " .. tostring(numofbytes) .. " to write")
		for j=1,numofbytes do
			local offset = pos + 1
			value = patchvalues[i + j + consecs]

			if not value then 
				error("ERROR: Patch index had no value!\nIndex: " .. tostring(i) ..
									"\nsubarray: " .. tostring(j) .. "\nconsecs: " .. tostring(consecs) .. "\nfinal: " .. tostring(i + j + consecs) .. 
									"\n\nNum of values: " .. tostring(#patchvalues) ..
									"\nNum of offsets: " .. tostring(#patchoffsets) .. 
									"\nCurrent Offset: " .. tostring(i))
			end

			print("Setting value to " .. tostring(value) .. " at script offset " .. tostring(offset))
			scripttable[offset] = string.char(value)
			pos = offset
		end
		if numofbytes > 1 then
			consecs = consecs + numofbytes - 1
			print("Breaking streak, increasing consecs by " .. tostring(numofbytes))
		else
			print("Not incrementing consecs")
		end
	else
		-- Ordinary byte replacement
		local offset = pos + offsetval
		value = patchvalues[i + consecs]
		pos = offset
			if not value then error("ERROR: Patch index had no value! Index: " .. tostring(i))	end -- This is much faster than using an assert as the string would be concatenated each time.
		scripttable[offset] = string.char(value)
		print(tostring("Writing ordinary byte at " .. tostring(offset)))
	end
	-- io.read()
end

local finalstring = table.concat(scripttable)
local finalfunc, err = loadstring(finalstring)

if not finalfunc then
	-- error(err)
	return
end
io.read()
return finalfunc
