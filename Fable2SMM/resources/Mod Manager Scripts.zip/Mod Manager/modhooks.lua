-- Still partly placeholder code, needs adapting


-- Hook categories are given numbers for efficient iteration.
HooksEnum = {
	OnSaveLoad = 1,
	OnEnterArea = 2,
	OnHeroHit = 3,
}
-- Stupid function used for updating as old HooksEnum may differ from new one. Lol, lmao.
function GetHookName(enum, num)
	for k,v in pairs(enum) do
		if v == num then return k end
	end
end

-- Stores callback functions
Hooks = {
	[HooksEnum["OnSaveLoad"]] = {

	},
	[HooksEnum["OnEnterArea"]] = {
		--[[
		Cur = {ID = "SomeID", func, arg}
		--]]
	},
	[HooksEnum["OnHeroHit"]] = {
		--[[
		--OnHeroHit
		Cur = {ID = "AnotherID", func, arg, next},
		() = {ID = "SomeID", func, arg, prev, next}, -- Not actually in the table, but in next and prev of prev and next entry respectively
		End = {ID = "AndAnotha", func, arg, prev}
			--]]
	}
}
-- Stores last message IDs
Hooks.MessageIDs = {}

-- Condition Check functions
Hooks[HooksEnum["OnSaveLoad"]].CheckCondition = function()
	
end
Hooks[HooksEnum["OnEnterArea"]].CheckCondition = function()
	local is_posted, message = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_LEVEL_LOADED, Hooks.MessageIDs.LastMessageID_LevelLoaded)
	if is_posted then
		Hooks.MessageIDs.LastMessageID_LevelLoaded = message:GetID()
		return true, message
	else
		return false
	end
end
Hooks[HooksEnum["OnHeroHit"]].CheckCondition = function()
	local is_posted, message = MessageEvents.IsMessageSentTo(EMessageEventType.MESSAGE_EVENT_HIT, QuestManager.HeroEntity, Hooks.MessageIDs.LastMessageID_HeroHit)
	if is_posted then
		Hooks.MessageIDs.LastMessageID_HeroHit = message:GetID()
		return true, message
	end
	return false
end

-- General system stuff. Called by the runner.
function UpdateHooks()
	for i=1,#Hooks do
		local hooktab = Hooks[i]
		local posted, msg = hooktab.CheckCondition()
		if hooktab.Cur and posted then
			TriggerHook(hooktab, msg)
		end
	end
end
function TriggerHook(hooktable, msg)
	if not hooktable then return false end
	local last_success, last_reason
	local hookentry = hooktable.Cur
	while hookentry do
		last_success, last_reason = pcall(hookentry.func, hookentry.arg, msg)
		if not last_success then
			-- ?????????????? Isn't this like a really bad idea?
			Debug.Error(last_reason)
		end
		hookentry = hookentry.next
	end
	return true
end
function OnSaveLoad()
	TriggerHook(Hooks[HooksEnum["OnSaveLoad"]])
end

-- Functions to be used by mods
function AddHook(hook, id, thefunc, arg)

	if not HooksEnum[hook] then error("AddHook: Hook with name \"" ..tostring(hook or "nil")..  "\" doesn't exist!") end
	if not id then error("AddHook: wasn't passed an ID!") end
	if type(thefunc) ~= "function" then error("AddHook wasn't passed a function!") end

	local hooktab = Hooks[HooksEnum[hook]]
	if not hooktab then
		error("Manager error in AddHook: Couldn't find hook table \"" ..tostring(hook).. "\".\n\nThis is not good! The enum value exists, but its corresponding table doesn't!")
	end

	local hookentry = hooktab.Cur
	while hookentry do
		if hookentry.id == id then
			error("AddHook: ID is already taken!\nID: " ..tostring(id))
			return false
		end
		hookentry = hookentry.next
	end

	local last_end = hooktab.End
	hooktab.End = {
		id = id,
		func = thefunc,
		arg = arg,
		prev = last_end
	}
	if last_end then
		last_end.next = hooktab.End
	end
	if hooktab.Cur == nil then
		hooktab.Cur = hooktab.End
	end
end
function RemoveHook(hook, id)

	if not HooksEnum[hook] then error("RemoveHook: Hook with name \"" ..tostring(hook or "nil")..  "\" doesn't exist!") end
	if not id then error("RemoveHook: wasn't passed an ID!") end

	local hooktab = Hooks[HooksEnum[hook]]
	local l = hooktab.Cur
	while l do
		if l.id == id then
			if l.prev then
				l.prev.next = l.next
			end
			if l.next then
				l.next.prev = l.prev
			end
			if hooktab.Cur == l then
				hooktab.Cur = l.next
			end
			if hooktab.End == l then
				hooktab.End = l.prev
			end
		end
		l = l.next
	end
end

--[[
	-- Testing
	area1func = function()
		print("area1 hook called")
	end

	hit1func = function()
		print("hit1 hit hook called")
	end
	hit2func = function()
		print("middle hit hook called")
	end
	hit3func = function()
		print("hit3 hit hook called")
	end

	AddHook("OnEnterArea", "SomeID", area1func)

	AddHook("OnHeroHit", "AnotherID", hit1func)
	AddHook("OnHeroHit", "SomeID", hit2func)
	AddHook("OnHeroHit", "AndAnotha", hit3func)
--]]