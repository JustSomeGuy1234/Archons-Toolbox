﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fable2SMM
{
    public class Gamescripts
    {
        public static string GamescriptsPath { get { return Path.Combine(ModManaging.DataFolder + @"gamescripts_r.bnk"); } }
        public static string GamescriptsBackupPath = GamescriptsPath + ".bak";
        public const string GamescriptsOriginalHash = "68A2EF1F703C3C325F268EDCD5CDADBC5C869E96CF7C7E2E38BC017153C876E2";
        public const string GamescriptsManagerHash = "CA1D0D427146659C7C9C8BFCE6EA6BE44F3A8D79411B4168445C94C519FC8AE3";

        public static GamescriptsStatus CurrentGamescriptsStatus { get => _gamescriptsStatus; set { _gamescriptsStatus = value; CurrentGamescriptsStatusChanged?.Invoke(null, EventArgs.Empty); } }
        private static GamescriptsStatus _gamescriptsStatus = GamescriptsStatus.ORIGINAL;
        public static event EventHandler CurrentGamescriptsStatusChanged;
    }
}
