-- DeltaPatchApplicator.lua
print("\n")
-- print = function() end
local args = {...}
local scriptpath = args[1]
local patchpath = args[2]
if not scriptpath or not patchpath then
	error("No source or modded file passed")
end

local scriptdumped = string.dump(loadfile(scriptpath))
local scriptlen,patchoffsets,patchvalues = loadfile(patchpath)()

--  Split entire script up into chars
local scripttable = {}
for i=1,#scriptdumped do
	if scriptlen < i then break end
	scripttable[i] = scriptdumped:sub(i,i)
end

-- Replace the bytes in the script with those provided by the patch
-- Offsets are relative to their preceeding byte's offset
local pos = 0
for i=1, #patchoffsets do
	local offset = pos + patchoffsets[i]
	local value = patchvalues[i]
	pos = offset
		if not value then error("ERROR: Patch offset had no value! Index: " .. tostring(i))	end -- This is much faster than using an assert as the string would be concatenated each time.
	scripttable[offset] = string.char(value)
end

local finalstring = table.concat(scripttable)
local finalfunc, err = loadstring(finalstring)

if not finalfunc then
	-- error(err)
	return
end
return finalfunc
