﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Diagnostics;
using System.Windows;
using System.Collections.ObjectModel;

namespace Fable2SMM
{

    public static class ModManaging
    {
        public static bool RealtimeSaving = false;
        // TODO: Make sure the event handler still works
        public static string GameFolder
        {
            get { return _gameFolder; } 
            set 
            { 
                if (!value.EndsWith(@"\") && !value.EndsWith("/")) value += @"\";
                if (!Directory.Exists(value))
                {
                    System.Media.SystemSounds.Hand.Play();
                    MessageBox.Show("Game Path does not exist!");
                    return;
                }
                // TODO: Add some error handling here. There's a decent chance this will throw an error if set to something that doesn't have the runner installed. Obviously this will need to happen TO install the runner.
                _gameFolder = value; OnGameFolderChanged(EventArgs.Empty); Trace.WriteLine("Changing GameFolder to " + value);
                if (File.Exists(Mod.InstalledModsPath))
                {
                    LuaParsing.ReadInstalledModsIntoContentAndDict();
                    runnerInstalled = true;
                    ModManaging.EnumerateAllMods();
                }
                else
                    runnerInstalled = false;
            }
        }
        static string _gameFolder = "";
        public static event EventHandler GameFolderChanged;
        private static void OnGameFolderChanged(EventArgs e)
        { GameFolderChanged?.Invoke(null, e); }

        public static string DataFolder { get { return GameFolder + @"Data\"; }}
        public static string ScriptsFolder { get { return DataFolder + @"scripts\"; } }
        public static string ModsFolder { get { return ScriptsFolder + @"Mods\"; } }
        public static string RunnerFolder { get { return ScriptsFolder + @"\Mod Manager\"; } }
        public const string RunnerVersionFileName = @"runnerversion.txt";

        public const string gamescriptsrOriginalHash = "68A2EF1F703C3C325F268EDCD5CDADBC5C869E96CF7C7E2E38BC017153C876E2";
        public const string gamescriptsrManagerHash = "CA1D0D427146659C7C9C8BFCE6EA6BE44F3A8D79411B4168445C94C519FC8AE3";
        public static string unchangedInstalledmodsHash = "";
        public static bool runnerInstalled = false;



        public static ObservableCollection<Mod> ModList { get { return _modList; } set { _modList = value; ModListChanged?.Invoke(null, EventArgs.Empty); Trace.WriteLine("Setting ModList to something else"); } }
        private static ObservableCollection<Mod> _modList = new ObservableCollection<Mod>();
        public static event EventHandler ModListChanged;

        public static string CurrentInstalledModsContent { get { return _currentInstalledModsContent; } set { _currentInstalledModsContent = value; OnInstalledModsContentChanged(EventArgs.Empty); } }
        static string _currentInstalledModsContent = "";
        public static event EventHandler CurrentInstalledModsContentChanged;
        private static void OnInstalledModsContentChanged(EventArgs e)
        {CurrentInstalledModsContentChanged?.Invoke(null, e);}

        public static Dictionary<string, object> InstalledModsFileDict { get { return _installedModsDict; } set { _installedModsDict = value; } }
        static Dictionary<string, object> _installedModsDict = new Dictionary<string, object>();


        /// <summary>
        /// Compares installedmods and loose mods in the Mods folder to see what needs updating/removing.
        /// </summary>
        /// <remarks>Perhaps this method shouldn't exist, and instead mods should only be marked as different when something changes (files are missing, or an intentional act through the manager)</remarks>
        /// <param name="installedmodsDict"></param>
        /// <returns>
        /// <list type="bullet">
        /// <item>outOfDateMods - Mods with a differing version in the folder</item>
        /// <item>neverInstalledMods - Mods that are found in folder but not installedmods</item>
        /// <item>uninstalledMods - Mods that are found within installedmods but not folder</item>
        /// </list>
        /// </returns>
        public static void EnumerateAllMods()
        {
            if (string.IsNullOrEmpty(CurrentInstalledModsContent))
                //throw new Exception("CurrentInstalledModsContent variable is empty!");
                return;
            if (InstalledModsFileDict == null)
                throw new Exception("InstalledModsFileDict is null, but CurrentInstalledModsContent is not!");

            List<Mod> installedmodsList = LuaParsing.GetAllModsFromInstalledModsFileDict(InstalledModsFileDict);
            List<Mod> loosemodsList = ManifestParser.ConvertManifestsToMods(ManifestParser.GetAllManifestsInModFolder());
            List<Mod> FinalModList = new List<Mod>();

            Dictionary<string, Mod> installedModsDict = new Dictionary<string, Mod>();

            foreach (Mod installedmod in installedmodsList)
            {
                if (installedModsDict.ContainsKey(installedmod.NameID))
                    throw new Exception("Somehow a mod with the same nameID was found twice! " + installedmod.NameID);
                installedModsDict.Add(installedmod.NameID, installedmod);

                if (!File.Exists(ModsFolder + installedmod.NameID))
                    installedmod.IsDeleted = true;
                FinalModList.Add(installedmod);
            }

            foreach (Mod loosemod in loosemodsList)
            {
                if (installedModsDict.ContainsKey(loosemod.NameID))
                {
                    Mod installedmod = installedModsDict[loosemod.NameID];
                    // Found existing mod
                    if (installedmod.VersionMajor != loosemod.VersionMajor || installedmod.VersionMinor != loosemod.VersionMinor)
                    {
                        installedmod.IsOutOfDate = true;
                        Console.WriteLine("Versions differ for mod: " + installedmod.NameID);
                    }
                }
                else
                    FinalModList.Add(loosemod);

            }

            ModList = new ObservableCollection<Mod>(FinalModList);
            // We now have every mod processed from both lists, let's concat them while making sure there's no duplicates and that they retain their management status'

        }

        static void UpdateAllOutOfDateMods()
        {
            EnumerateAllMods();

            foreach (Mod oldMod in ModList)
            {
                Console.WriteLine("Updating " + oldMod.NameID);
                if (oldMod.IsOutOfDate)
                    oldMod.UpdateMod();
                // Do we handle dirmanifest changes here or in UpdateMod? Probably updatemod.
            }
        }



        public static void WriteToInstalledMods(string content)
        {
            if (!Directory.Exists(Mod.InstalledModsPath.Substring(0, Mod.InstalledModsPath.LastIndexOf('\\'))))
                throw new Exception("Mod Manager folder doesn't exist. TODO: Handle this properly");
            File.WriteAllText(Mod.InstalledModsPath, content);
        }


        

        public static string GetFileHash(string filePath)
        {
            string curFileHashString;
            using (SHA256 sha = SHA256.Create())
            {
                if (File.Exists(filePath))
                {
                    using (FileStream stream = File.OpenRead(filePath))
                    {
                        byte[] curFileHashBytes = sha.ComputeHash(stream);
                        curFileHashString = string.Join("", curFileHashBytes.Select(x => x.ToString("X2")));
                    }
                }
                else
                    return "";
            }
            return curFileHashString;
        }

        static string GetRunnerVersion()
        {
            string RunnerVersionPath = RunnerFolder + RunnerVersionFileName;
            if (!File.Exists(RunnerVersionPath))
                throw new Exception($"Failed to find the runnerversion file at\n`{RunnerVersionPath}`");
            string[] fileLines = File.ReadAllLines(RunnerFolder + RunnerVersionFileName);
            if (fileLines.Length <= 0)
                throw new Exception("runnerversion file is empty! (no lines)");

            string versionText = fileLines[0].Trim();
            if (string.IsNullOrWhiteSpace(versionText))
                throw new Exception("runnerversion file is empty! (just whitespace)");

            return versionText;
        }

        public static void WriteFilesToModFolders(Dictionary<string, byte[]> files)
        {
            bool wantsToOverwrite = false;
            foreach (string relativeFilePath in files.Keys)
            {
                string folderPath = Path.Combine(ModsFolder, Path.GetDirectoryName(relativeFilePath));
                string fullFilePath = Path.Combine(ModsFolder, relativeFilePath);
                if (Directory.Exists(folderPath))
                    Console.WriteLine($"A mod with the folder {folderPath} exists, but this is probably okay.");
                else
                    Directory.CreateDirectory(folderPath);
                if (!wantsToOverwrite && File.Exists(fullFilePath))
                {
                    Console.WriteLine($"Also, a file already exists here. nWould you like to update? y/n");
                    if (Console.ReadKey(false).Key != ConsoleKey.Y)
                        return;

                    wantsToOverwrite = true;
                }

                File.WriteAllBytes(fullFilePath, files[relativeFilePath]);
            }
        }
        public static (Mod, string manifestContent, Dictionary<string, byte[]>) GetModFromZip(string zipPath)
        {
            Dictionary<string, byte[]> files = new Dictionary<string, byte[]>();
            Mod modFromManifest = null;
            string manifestContent = "";
            using (Stream fs = File.OpenRead(zipPath))
            {
                ZipArchive archive = new ZipArchive(fs);
                ZipArchiveEntry manifestEntry = null;
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    byte[] filecontent = new byte[entry.Length];
                    using (Stream entryStream = entry.Open())
                    {
                        entryStream.Read(filecontent, 0, filecontent.Length);
                        Console.WriteLine(entry.FullName);
                    }
                    string contentString = ASCIIEncoding.ASCII.GetString(filecontent);
                    if (entry.Name == "modmanifest.json")
                    {
                        if (manifestEntry == null)
                            manifestEntry = entry;
                        else
                            throw new Exception("Mod has multiple manifest files!");
                        modFromManifest = ManifestParser.ConvertManifestToMod(contentString);
                        manifestContent = contentString;
                    }
                    files.Add(entry.FullName, filecontent);
                }
            }
            if (modFromManifest == null)
                throw new Exception("Failed to find mod manifest from zip file " + zipPath);
            return (modFromManifest, manifestContent, files);
        }
        public static Mod InstallModFromZip(string zipPath)
        {
            (Mod zipMod, string manifestContent, var zipFilesDict) = GetModFromZip(zipPath);
            WriteFilesToModFolders(zipFilesDict);
            if (LuaParsing.IsModInInstalledMods(zipMod.NameID))
            {
                Mod existingMod = ModList.Where(x => x.NameID == zipMod.NameID).First();
                if (existingMod == null)
                    throw new NullReferenceException("Mod is already in InstalledMods but can't be found in the ModList to update???\nI think I did something stupid here so this error may be made in error.");
                existingMod.UpdateMod();
                return existingMod;
            }
            zipMod.InstallModIntoInstalledModsAndAddToList(manifestContent);
            return zipMod;
        }

        public static (Mod, string, Dictionary<string, byte[]>) GetModFromFolder(string passedPath)
        {
            string folderPath = passedPath;
            if (!folderPath.EndsWith("/") || !folderPath.EndsWith("\\"))
                folderPath += "\\";
            string modManPath = Path.Combine(folderPath + "modmanifest.json");
            if (!File.Exists(modManPath))
            {
                MessageBox.Show("Folder doesn't contain a mod manifest: " + folderPath);
                return (null, null, null);
            }

            string modManContent = File.ReadAllText(modManPath);
            Mod mod = ManifestParser.ConvertManifestToMod(modManContent);
            Dictionary<string, byte[]> fileDict = new Dictionary<string, byte[]>();


            string[] fullPaths = Directory.GetFiles(folderPath, "*", SearchOption.AllDirectories);
            foreach (string fullpath in fullPaths)
            {
                byte[] content = File.ReadAllBytes(fullpath);
                string relPath = fullpath.Replace(folderPath.Replace('/', '\\'), "");
                fileDict.Add(relPath, content);
            }



            return (mod, modManContent, fileDict);
        }
        public static Mod InstallModFromFolder(string folderPath)
        {
            (Mod folderMod, string modManContent, Dictionary<string, byte[]> fileDict) = GetModFromFolder(folderPath);
            if (folderMod == null)
                return null;
            if (LuaParsing.IsModInInstalledMods(folderMod.NameID))
            {
                Mod existingMod = ModList.Where(x => x.NameID == folderMod.NameID).First();
                if (existingMod == null)
                    throw new NullReferenceException("Mod is already in InstalledMods but can't be found in the ModList to update???\nI think I did something stupid here so this error may be made in error.");
                existingMod.UpdateMod();
                return existingMod;
            }
            else
            {
                WriteFilesToModFolders(fileDict);
                folderMod.InstallModIntoInstalledModsAndAddToList(modManContent);
                return folderMod;
            }
        }

        static void InstallRunner()
        {
            string gamescriptsPath = DataFolder + "gamescripts_r.bnk";
            string gamescriptsBackupPath = gamescriptsPath + ".bak";

            string currentGamescriptsHash = GetFileHash(gamescriptsPath);
            bool gamescriptsExists = File.Exists(gamescriptsPath);
            bool gamescriptsIsOriginal = currentGamescriptsHash == gamescriptsrOriginalHash;
            bool gamescriptsHasManager = currentGamescriptsHash == gamescriptsrManagerHash;
            string currentBackupHash = GetFileHash(gamescriptsBackupPath);
            bool backupExists = File.Exists(currentBackupHash);
            bool backupIsOriginal = currentBackupHash == gamescriptsrOriginalHash;
            bool backupHasManager = currentBackupHash == gamescriptsrManagerHash;

            // Make sure the gamescripts_r bnk is patchable, make a backup, or restore one of available.
            // TODO: Add an option to override the patching checks
            if (gamescriptsExists)
            {
                // Gamescripts is original and there's no backup
                if (gamescriptsIsOriginal && !backupExists)
                    File.Copy(gamescriptsPath, gamescriptsBackupPath);
                // Gamescripts is original, backup exists but is not original
                else if (gamescriptsIsOriginal && backupExists && !backupIsOriginal)
                {
                    if (MessageBox.Show("Backed up gamescripts_r.bnk is not original. Would you like to overwrite it with the original version?", "Unoriginal backup", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                        File.Copy(gamescriptsPath, gamescriptsBackupPath);
                }
                else if (!gamescriptsIsOriginal && !gamescriptsHasManager)
                {
                    if (backupExists && (backupIsOriginal || backupHasManager))
                    {
                        if (MessageBox.Show("Current gamescripts_r.bnk is not compatible, but the backup is. Would you like to restore the backup?", "Incompatible File", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                            File.Copy(gamescriptsBackupPath, gamescriptsPath);

                    }
                }
            }
            // Neither gamescripts nor backup exists
            else if (!gamescriptsExists && !backupExists)
            {
                MessageBox.Show("gamescripts_r.bnk is missing from the game directory, and there is no backup.", "Missing File", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            // Gamescripts is not suitable or it's missing but there is a backup, original or otherwise
            else if ((!gamescriptsExists || (!gamescriptsIsOriginal && !gamescriptsHasManager)) && backupExists)
            {
                if ((backupIsOriginal || backupHasManager) && MessageBox.Show("gamescripts_r.bnk is missing or incompatible.\n\nHowever, a suitable backup exists. Would you like to restore it?", "Missing File & Corrupt Backup",
                                                                            MessageBoxButton.YesNo, MessageBoxImage.Error) == MessageBoxResult.Yes)
                {
                    File.Copy(gamescriptsBackupPath, gamescriptsPath);
                    gamescriptsExists = true;
                    gamescriptsIsOriginal = backupIsOriginal;
                    gamescriptsHasManager = backupHasManager;

                }
            }

            // Extract mod manager scripts
            ZipArchive modManagerScripts = new ZipArchive(File.OpenRead("./looseresources/ModManagerScripts.zip"));
            bool canOverWrite = false;
            foreach (ZipArchiveEntry entry in modManagerScripts.Entries)
            {
                string finalEntryPath = ScriptsFolder + entry.FullName;
                string finalEntryFolder = Path.GetDirectoryName(finalEntryPath);

                if (!canOverWrite && Directory.Exists(finalEntryFolder))
                {
                    ConsoleKey pressedKey = ConsoleKey.A;
                    while (pressedKey == ConsoleKey.Y || pressedKey == ConsoleKey.N)
                    {
                        Console.WriteLine("Found existing folders/files from the manager. Would you like to overwrite them?\nThis may reset mod management if necessary (e.g. whether mods are enabled, disabled, etc.)");
                        pressedKey = Console.ReadKey().Key;
                    }
                    if (pressedKey == ConsoleKey.N)
                        break;
                    canOverWrite = true;
                }

                byte[] buffer;
                Stream entryStream = entry.Open();
                entryStream.Read(buffer = new byte[entry.Length], 0, (int)entry.Length);
                Directory.CreateDirectory(finalEntryFolder);
                File.WriteAllBytes(finalEntryPath, buffer);
            }
            // By now the bnk is either original, already patched, or the user has declined to use a compatible bnk. 
            if (gamescriptsIsOriginal || (!gamescriptsHasManager && gamescriptsExists && MessageBox.Show("You are using a probably-incompatible gamescripts_r.bnk file. Would you like to try patching anyway? This may break your game.") == MessageBoxResult.Yes))
                Patching.Patcher.Patch(gamescriptsPath, "./looseresources/Fable2ModManager.patch");



            // TODO: Modify this so that it manager scripts aren't added by the forced file, and are instead added automatically.
            if (File.Exists(DirManifest.DirManifestForcedPath))
            {
            replacemanifestloop:
                Console.WriteLine("\n\nYou have an old dir.forced.manifest file. Would you like to overwrite it?\nIf you have customized it, copy the lines somewhere safe and reinsert them after install." +
                    "\nIf you're unsure, or are updating and already have it backed up, press Y. Otherwise, press N." +
                    "\nNOTICE: If you're updating you really should press Y, as the manager uses the forced file for new manager-related files.");
                if (Console.ReadKey().Key == ConsoleKey.Y)
                    File.Copy(gamescriptsPath, gamescriptsBackupPath, true);
                else if (Console.ReadKey().Key != ConsoleKey.N)
                    goto replacemanifestloop;
            }
            else
                File.Copy(gamescriptsPath, gamescriptsBackupPath);
            // TODO: Test this
            DirManifest.AddForcedFilesToDirManifest();
            File.WriteAllText(DirManifest.DirManifestPath, DirManifest.CurrentDirManifestContent);
        }
    }
}
