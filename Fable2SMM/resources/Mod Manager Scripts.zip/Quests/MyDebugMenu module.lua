menu = require "MultipageMenu"
self = getfenv(1)
local modulename = "MyDebugMenu" -- Should be unused now
ScriptName = "DebugMenu"

-- [[ Debug Functions ]]
DumbBandits = {}
Functions = {}
function Functions.GodMode()
	Health.SetAsInvulnerable(QuestManager.HeroEntity, not Health.IsInvulnerable(QuestManager.HeroEntity))
end
function Functions.DumbBandit()
	DumbBandit = Debug.CreateEntityByHero("CreatureVillagerBanditLieutenant", "jerry")
	Combat.SetCanFight(DumbBandit, false)
	Combat.SetCanFlee(DumbBandit, false)
	Health.SetAsInvulnerable(DumbBandit, true)
	table.insert(DumbBandits, DumbBandit)
end
function Functions.DestroyDumbBandits()
	for k,v in pairs(DumbBandits) do
		if v:IsAlive() then
			v:Destroy()
			DumbBandits[k] = nil
		end
	end
end
function Functions.HideGUI()
	local hidetimer = {}
	function hidetimer:Update()
		local timer = QuestManager.NewTimer(1)
		while timer:GetTime() ~= 0 do
			coroutine.yield()
		end
		Debug.SetDrawGUI(false)
	end
	GeneralScriptManager.AddScript(hidetimer)
end
function Functions.SetFOV()
	local returnedAmount, user_accepted = GUI.AskForAmount(ModMisc.FCFSMessages, {
		Type = EAdjusterTypes.ADJUSTER_TYPE_MONEY,
		MinVal = 5,
		MaxVal = 179,
		Increment = 1,
		DefaultVal = 75,
		ShowSign = false
	}, "FOV Slider", 1)
	if user_accepted then
		ScriptFunction.WaitForTimeInSeconds(1.5)
		Debug.SetFOV(returnedAmount)
		ScriptFunction.WaitForTimeInSeconds(1)
	end
end

-- [[ Entries ]]
function FormatBool(thebool)
	if type(thebool) == "boolean" then
		return " (" .. tostring(thebool)  .. ")"
	else
		return ""
	end
end

function NewActionEntry(text, enabled, func, args)
	local entry = {}
	if type(text) == "string" then
		entry.TextTag = text

		if type(enabled) == "boolean" then
			entry.Enabled = enabled
		else
			entry.Enabled = true
		end

		if not func then
			entry.TextTag = text .. " (err: nil function)"
		else
			entry.Function = func
		end
		entry.Args = args

		return entry
	else
		return "Malformed entry"
	end
end

function HandleEntry(entry)
	if type(entry.Function) == "function" then
		if type(entry.Args) == "table" then
			entry.Function(unpack(entry.Args))
		else
			entry.Function(entry.Args)
		end
	end
end

function GetMainMenuEntries() 
	return {
		NewActionEntry("Camera Menu", true, OpenMenu, {"Camera Menu", GetCameraMenuEntries}),
		NewActionEntry("Toggle Godmode" .. FormatBool(Health.IsInvulnerable(QuestManager.HeroEntity)), true, Functions.GodMode, nil),
		NewActionEntry("Spawn Invincible Dumb Bandit", true, Functions.DumbBandit, nil),
		NewActionEntry("Destroy All Dumb Bandits", true, Functions.DestroyDumbBandits, nil)
	}
end
function GetCameraMenuEntries()
	return {
		NewActionEntry("Toggle Free Cam", true, Debug.ToggleFreeCam, nil),
		NewActionEntry("Hide GUI", true, Functions.HideGUI, nil),
		NewActionEntry("Set FOV", true, Functions.SetFOV, nil)
	}
end
 
-- [[ Menu Function ]]
function OpenMenu(title, entriesfunction)
	local result
	while result ~= 0 do
		local entries = entriesfunction()
		result = menu.ShowMenuBoxWithPages(title, entries)
		if result == 0 then break end
		local selectedentry = entries[result]
		HandleEntry(selectedentry)
		coroutine.yield()
	end
end

function Update()
	custom_update = coroutine.create(CustomUpdate)
	while not ShouldDie do
		coroutine.yield()

		MyScriptWorked, ScriptWhyNot = coroutine.resume(custom_update)
		if not MyScriptWorked then
			GUI.DisplayMessageBox("Guy's Debug Menu has ended! Reason:\n " .. tostring(ScriptWhyNot))
			ShouldDie = true
		end

	end
	coroutine.yield()
end

function CustomUpdate()
	while true do
		coroutine.yield()
		if Player.IsInFirstPerson(QuestManager.HeroEntity) or Debug.GetUseFreeCamera() then
			local pressed_a, message = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_GENERIC_A_BUTTON_PRESSED, LastMessageID_PressedAButton)
			if pressed_a and (Timing.GetWorldFrame() == message:GetTimeStamp()) then
				LastMessageID_PressedAButton = message:GetID()
				Debug.SetDrawGUI(true) 	-- Unfortunately I couldn't find a way to get whether the GUI is enabled or disabled when opening the menu, so we cannot restore how it was when the menu closes.
				OpenMenu("Guy's Debug Menu", GetMainMenuEntries)
			end
		end
	end
end

function Terminate()
	ShouldDie = true
	package.loaded[modulename] = nil
	_G[modulename] = nil
end

function ReloadModule()
	Terminate()
	require(modulename)
end

function Reload()
	Terminate()
	local menufunc = loadfile("/data/scripts/Quests/MyDebugMenu.lua")
	local menutab = {}
	setfenv(menufunc, menutab)
	setmetatable(menutab,menutab)
	menutab.__index = _G
	menutab._G = _G
	menufunc()
end