local oldbark = BehaviourDogLeadHeroBase.Bark

function RestoreDogBark()
	BehaviourDogLeadHeroBase.Bark = oldbark
	GUI.DisplayMessageBox("Dog Teleporter: Restoring bark")
end

function ReplaceDogBark()
	GUI.DisplayMessageBox("Dog Teleporter: Replacing bark")
	function BehaviourDogLeadHeroBase:Bark()
		-- Debug.Draw3DText(hero:GetPosition(), "Dog tried barking!", 1, {DrawInFrontOfScene = true})
		local firstTime = false
		if not self.LastBark then
			self.LastBark = Timing.GetWorldFrame()
			firstTime = true
		end
		if Timing.GetSecondsSince(self.LastBark) >= 3 or firstTime then
			firstTime = false
			self.LastBark = Timing.GetWorldFrame()
			oldbark(self)
			local targ = self:GetTargetPosition() or CVector3(0,0,0)
			if not Action.IsPerformingAnyAction(self.Entity) and targ:IsNonZero() and GetDistanceBetweenEntityAndPosition(self.Entity, targ) > 1.5 then
				local lastfx = Debug.CreateEntityByHero("FX_Goodguy_Teleporter")
				lastfx:SetPosition(targ)
				self.Entity:SetPosition(targ)
				ParticleEmitter.KillParticleWithFadeOut(lastfx, 3)
			end
		end
	end
end

ModHooks.AddHook("OnSaveLoad", "DogBarkReplacer", ReplaceDogBark, getfenv(1))

function Enable()
	-- GUI.DisplayMessageBox("Dog Teleporter: Enabling Mod")
	ReplaceDogBark()
	ModHooks.AddHook("OnSaveLoad", "DogBarkReplacer", ReplaceDogBark, getfenv(1))
end

function Disable()
	-- GUI.DisplayMessageBox("Dog Teleporter: Disabling Mod")
	RestoreDogBark()
	ModHooks.RemoveHook("OnSaveLoad", "DogBarkReplacer")
end

function Uninstall()
	GUI.DisplayMessageBox("Dog Teleporter: Uninstalling Mod")
	Disable()
end
-- GUI.DisplayMessageBox("Dog Teleporter: Starting Mod")
Enable()