-- Used by the GUI state to generate patches.

-- Source: The original script. Compared with your modified version to make the patch.
-- Target: Your modified version. Compared with the original to make the patch.
-- PatchPath: The filepath of the generated patch.
-- Overwrite: If the patch already exists, should it be overwritten?
-- I was going to use this for the game to see which patches are available, but it'd be better if a script were to call a function to declare it instead.

local basepath = "GAME:\\data\\scripts\\"

local PatchGens = {
	{
		Source = "Mod Manager\\Patching\\tmp\\qc010_childhood.lua",
		Target = "Mod Manager\\Patching\\tmp\\qc010_childhood_modified.lua",
		PatchPath = "Mod Manager\\Patching\\tmp\\qc010_childhood_patch.lua",
		Overwrite = false
	},
}

for k,v in ipairs(PatchGens) do
	v.Source = basepath .. v.Source
	v.Target = basepath .. v.Target
	v.PatchPath = basepath .. v.PatchPath
end

return PatchGens