--[[
The aim of the manager is to make script mod creation and installation extremely simple, while also expanding on the games functionality.

Flow:
	On game start/load, GeneralScriptManager.lua runs startrunner.lua if the runner script is not running already
	The startrunner.lua script sets this script up (the runner script) to be in its own fenv then runs it
	The runner script adds its Update() function to GeneralScriptManager.AddScript, so it is automatically called every tick

	When the game reloads, GeneralScriptManager finds this runner script and calls the ReadInstalledMods() function (I may also add the ability to call this on demand for runtime mod management)
	The ReadInstalledMods function runs the InstalledMods.lua file, which contains info about which mods should be installed/enabled.
	For every entry in InstalledMods, if the mod should be installed and enabled, set up the mods startup script to be in its own fenv and run it.
	When setting up the mod, it creates a "handle" (name is wip) that basically contains info about the mod such as mod name, version etc.
	Add the mod handle to the CurrentlyRunningMods chain.

	The Update function (coroutine actually) calls the CustomUpdate function (also a coroutine) and catches any errors.
	The CustomUpdate function iterates through each handle in the CurrentlyRunningMods chain to resume each mods ModUpdate coroutine, every tick.
	It also iterates through the ModHooks script chain and does all that stuff. (logic is defined in modhooks.lua, which is run by modmetatable.lua, which is run by this script)


That's a very simplified explanation. The runner also disables and uninstalls mods depending on what InstalledMods says, allows mods to retain data when updating, etc.

--]]

--[[ 
TODO:
(done?): Add version checking for the manager itself. Probably done with InstalledMods?
Make something for modules
Add an option to delete uninstall data *without* having to reinstall the mod with the clean option
(done?) Test reloading the mod manager: Uninstall data, Disabled mods
(done?) Add a menu (should be openable at any time)


Add some kind of recovery if the mod script chain causes an error when importing it during runner reload
--]]

-- Version MUST be on its own line in the format of |^Version = \d$| (does it?) This is because the manager needs to read it to find what's installed (why does it need to know?).
Version = 1.04
ScriptName = "ModManagerRunner"
ModsFolder = "scripts/Mods/"
Portable = false
self = getfenv(1)
-- menu = require "MultipageMenu"

local saved = {...}
DisabledMods = {}
UninstalledMods = {}
StaticMods = {}
UninstallationQueue = {}
ToCheckInstallationQueue = false

-- Mod Metatable should contain mod-related things that mods can access
ModMetatable = {}
setmetatable(ModMetatable, ModMetatable)
ModMetatable.__index = function(the_table, key)
	local in_mt = rawget(ModMetatable, key)
	if in_mt then
		return in_mt
	else
		return _G[key]
	end
end
ModMetatable.ModManager = self

local meta_script = loadfile("scripts/Mod Manager/modmetatable.lua")
if type(meta_script) ~= "function" then
	GUI.DisplayMessageBox("Mod Manager: Metatable script failed to compile!")
	return false
end
setfenv(meta_script, ModMetatable)

local meta_worked, meta_whynot = pcall(meta_script, self)
if not meta_worked then
	GUI.DisplayMessageBox("Mod Manager: Metatable script error!\n\n" .. tostring(meta_whynot))
	return
end


--[[local overridenrequire, overridewhynot = pcall(ModMetatable.Patching._OverrideRequire)
if not overridenrequire then
	GUI.DisplayMessageBox(tostring("Failed to override `require` for patching:\n" .. tostring(overridewhynot)))
end--]]
-- local patched, patcherr = ModMetatable.Patching.AddPatch("scripts/quests/qc010_childhood.lua", "scripts/Mods/ChildhoodPatch/patch.lua", "mychildhoodpatch")
-- GUI.DisplayMessageBox(tostring(patched or "") .. " : " .. tostring(patcherr or ""))


-- The Update coroutine is just a layer of error handling for the real update coroutine, CustomUpdate.
function Update()
	custom_update = coroutine.create(CustomUpdate)
	mcm_update = coroutine.create(ModMetatable.MCM.CustomUpdate)
	while not ShouldDie do
		coroutine.yield()
		ManagerWorked, ManagerWhyNot = coroutine.resume(custom_update)
		if not ManagerWorked then
			GUI.DisplayMessageBox("Mod Manager Runner error! Reason:\n" .. tostring(ManagerWhyNot))
			ShouldDie = true
		end
		MCMWorked, MCMWhyNot = coroutine.resume(mcm_update)
		if not MCMWorked then
			GUI.DisplayMessageBox("Mod Manager Runner error! Reason:\n" .. tostring(MCMWhyNot))
			ShouldDie = true
		end
	end
	coroutine.yield()
end

function CheckInstallationQueue()
	for k,node in pairs(UninstallationQueue) do
		if GUI.AskYesNoQuestion("Mod " .. node.NameID .. " seems to have been renamed or deleted. Would you like to remove it from your save?", {}) then
			UninstallMod(node.NameID, true)
		end
	end
end

function CustomUpdate()
	ReadInstalledMods()
	while not ShouldDie do
		coroutine.yield()
		if ToCheckInstallationQueue then
			CheckInstallationQueue()
			ToCheckInstallationQueue = false
			UninstallationQueue = {}
		end
		ModMetatable.ModHooks.UpdateHooks()
		UpdateMods()
	end
end

-- Why reinvent the wheel? Let's just use the game's script chain technique. I imagine this is more efficient than using pairs/ipairs.
		-- Okay I just tested and it's about twice as fast as using an iterator.
function UpdateMods()
	local l = CurrentlyRunningMods
	local successful_run, error_message
	while l do
		if l and not l.value then
			GUI.DisplayMessageBox("A mod handle has no value!\nName: " .. tostring(l.NameID))
			RemoveModFromChain(nil, l)
			break
		end
		if l.value.mod_update and coroutine.status(l.value.mod_update) == "dead" then
			UninstallMod(l.NameID)
		elseif l.value.mod_update then
			successful_run, error_message = coroutine.resume(l.value.mod_update, l.value)
		else
			GUI.DisplayMessageBox(tostring("Mod " .. tostring(l.NameID or "MissingID") .. " was missing ModUpdate coroutine!"))
			UninstallMod(l.NameID)
		end
		if not successful_run then
			GUI.DisplayMessageBox(error_message)
		end
		l = l.next
	end
end



-- [[ Loads a script and sets its fenv to a new table ]]
function LoadScriptIntoFuncAndTab(fullpath)
	local modtab = {}
	local modfunc = loadfile(fullpath)
	if type(modfunc) ~= "function" then
		GUI.DisplayMessageBox("Couldn't run " .. tostring(fullpath) .. "\n\nMake sure it compiles, the path is right, and it is added to dir.manifest")
		return
	end
	setfenv(modfunc, modtab) 
	setmetatable(modtab, ModMetatable)
	return modfunc, modtab
end

-- [[ Create the mod's main coroutine and the mod's "handle" (node), then add it to the update chain ]]
function CreateModHandle(mod_table, installinfo)
	if IsModEnabled(installinfo.NameID) then
		GUI.DisplayMessageBox("A mod named: \"" .. (installinfo.NameID or "noname") .. "\" Is already active and running!")
		return false
	elseif DisabledMods[installinfo.NameID] then
		GUI.DisplayMessageBox("A mod named: \"" .. (installinfo.NameID or "noname") .. "\" Is installed but disabled!")
		return false
	end
	if type(mod_table.ModUpdate) ~= "function" and not installinfo.Static then
		GUI.DisplayMessageBox("A mod named: \"" ..  (installinfo.NameID or "noname") .. "\" had an invalid ModUpdate function (" .. tostring(mod_table.ModUpdate) .. "), and is not Static.")
		return false
	end


	if not installinfo.Static then
		mod_table.mod_update = coroutine.create(mod_table.ModUpdate)
	end
	local handle = {
		prev = CurrentlyRunningModsEnd,
		value = mod_table,
		VersionMajor = installinfo.VersionMajor,
		VersionMinor = installinfo.VersionMinor,
		NameID = installinfo.NameID,
		Static = installinfo.Static,
		StartScriptPath = installinfo.StartScriptPath
	}
	return true, handle
end
function InsertMod(mod_handle)
	local old_list_end = CurrentlyRunningModsEnd
	CurrentlyRunningModsEnd = mod_handle
	if CurrentlyRunningMods == nil then
		CurrentlyRunningMods = CurrentlyRunningModsEnd
	end
	if old_list_end ~= nil then
		old_list_end.next = CurrentlyRunningModsEnd
	end
end

--[[ Move a mod from the DisabledMods table, and insert it into the script chain ]]
function EnableMod(name)
	local handle = DisabledMods[name]

	if DisabledMods[name] == nil then
		if GetModHandleWithName(name) or StaticMods[name] then
			-- Should we log an error here? A mod shouldn't be enable-able if it's already running.
			-- Should we call the mod's Enable function again?
			DisabledMods[name] = nil
			return true
		end
		GUI.DisplayMessageBox("Mod Manager tried to enable non-existant mod " .. tostring(name))
		return false
	end

	if not handle.Static then
		InsertMod(handle)
	end
	if handle.value.Enable then
		local enablefuncworked, whynot = pcall(handle.value.OnEnable)
		if not enablefuncworked then
			GUI.DisplayMessageBox(tostring(name or "NoModName") .. "'s Enable function has failed:\n" ..
														tostring(whynot or "NOREASON"))
		end
	end

	ModMetatable.MCM.AddModToMCM(handle)
	return true
end
function IsModEnabled(name)
	local modhandle, running = GetModHandleWithName(name)
	return running, modhandle
end

function RemoveModFromChain(name, alt_handle)
	local l = alt_handle or GetModHandleWithName(name)
	if not l then return nil, false end
	-- Remove the mod from the update chain
	if l.next then
		l.next.prev = l.prev
	end
	if l.prev then
		l.prev.next = l.next
	end
	if CurrentlyRunningMods == l then
		CurrentlyRunningMods = l.next
	end
	if CurrentlyRunningModsEnd == l then
		CurrentlyRunningModsEnd = l.prev
	end
	return l, true
end
function DisableMod(name)
	local handle, removed = RemoveModFromChain(name)
	if handle and handle.value.OnDisable then
		pcall(handle.value.OnDisable, l.value)
	end
	if not removed then
		handle = StaticMods[name]
		if handle then
			StaticMods[name] = nil
			removed = true
		end
	end

	ModMetatable.MCM.RemoveModFromMCM(handle)

	if removed then
		DisabledMods[handle.NameID] = handle
		return true, handle
	else
		return false
	end
end
function IsModDisabled(name)
	local disabledmod = DisabledMods[name]
	if disabledmod then
		return true, disabledmod
	else
		return false
	end
end

function UninstallMod(modname, force_delete, updating)
	local handle = GetModHandleWithName(modname) or DisabledMods[modname]
	if handle then
		-- if uninstalling or GetUpdateData func doesn't exist, call uninstall and store data
		if (not updating or not handle.value.GetUpdateData) and handle.value.Uninstall then
			local _, uninst_data = pcall(handle.value.OnUninstall, handle.value)
			if not force_delete and not handle.ClearData then
				UninstalledMods[modname] = uninst_data
			else
				DeleteUninstallData(modname)
			end
		end
		-- if updating, call GetUpdateData function and store data.
		if updating then
			if handle.value.GetUpdateData then
				local _, update_data = pcall(handle.value.GetUpdateData, handle.value)
				UninstalledMods[modname] = update_data
			end
		end

		RemoveModFromChain(modname)
		StaticMods[modname] = nil
		DisabledMods[modname] = nil
		ModMetatable.MCM.RemoveModFromMCM(handle)
		return true
	else
		return false
	end
end
function GetUninstallData(modname)
	return UninstalledMods[modname]
end
function DeleteUninstallData(modname)
	UninstalledMods[modname] = nil
end
function IsModUninstalled(modname)
	local uninstalldata = UninstalledMods[modname]
	if uninstalldata then
		return true, uninstalldata
	else
		return false
	end
end

function GetModMCMEntryAndKey(handle)
	if not handle or not handle.value then
		return
	end
	if not handle.value.GetMCMEntry then return end
	local worked, entry, key = pcall(handle.value.GetMCMEntry)
	if not worked then
		GUI.DisplayMessageBox("Mod \"" .. tostring(handle.NameID) .. "\"'s GetMCMEntry errored: " .. tostring(entry))
	elseif not key then
		GUI.DisplayMessageBox("Mod \"" .. tostring(handle.NameID) .. "\" tried to add Mod Configuration Menu options without a key!")
	else
		return entry, key
	end
end

function ReadInstalledMods()
	local installed_script = loadfile("scripts/Mod Manager/installedmods.lua")
	if type(installed_script) ~= "function" then
		GUI.DisplayMessageBox("installedmods.lua failed to compile!")
		return false
	end

	local installed_worked, installedmods, targetver = pcall(installed_script)
	if not installed_worked then
		GUI.DisplayMessageBox("Runner: Error in installedmods.lua:\n" .. tostring(installedmods) .. "\n\nMod management will be unavailable until the error is fixed.")
		return
	end

	if Version ~= targetver then
		GUI.DisplayMessageBox("DEBUG: InstalledMods says there's a new version of the runner, reloading from file and passing mod data!")
		local save = Terminate()
		_,t = pcall(loadfile("scripts/Mod Manager/startrunner.lua"), save)
		return
	end

	-- Update mods, and also create a table for easy indexing to see if a mod doesn't exist in installedmods anymore.
	local runningmodstmp = {}
	for modname, installinfo in pairs(installedmods) do
		UpdateModInstallation(modname, installinfo)
		runningmodstmp[installinfo.NameID] = true
	end

	local node = CurrentlyRunningModsEnd
	while node do
		local found = (runningmodstmp[node.NameID] or DisabledMods[node.NameID] or UninstalledMods[node.NameID]) ~= nil
		if not found then
			-- We have a mod saved, but it isn't in installedmods anymore. With permission we should delete it.
			DisableMod(node.NameID)
			UninstallationQueue[#UninstallationQueue + 1] = node
			ToCheckInstallationQueue = true
		end
		node = node.prev
	end
end

function UpdateModInstallation(modname, installinfo)
	if installinfo.Installed and installinfo.Enabled then
		-- If mod wants to be running
		local ismodrunning, runninghandle = IsModEnabled(modname)
		local ismoddisabled, disabledhandle = IsModDisabled(modname)
		local ismoduninstalled, uninstalldata = IsModUninstalled(modname)
		local _
		local handle = runninghandle or disabledhandle
		if ismodrunning or ismoddisabled then
			-- VERSION CHECK
			if handle.VersionMajor ~= installinfo.VersionMajor or handle.VersionMinor ~= installinfo.VersionMinor then
				-- We need to update
				GUI.DisplayMessageBox("DEBUG: Updating mod because of differing version: " .. modname .. 
					"\nStored: " .. tostring(handle.VersionMajor or "nomajor") .. "." .. tostring(handle.VersionMinor or "nominor") .. 
					"\nNew: " .. tostring(installinfo.VersionMajor or "nomajor") .. "." .. tostring(installinfo.VersionMinor or "nominor")
				)
				UpdateMod(modname, installinfo)
			end

			if ismoddisabled then
				EnableMod(modname)
				GUI.DisplayMessageBox("Enabling " .. modname)
			end
		else
			-- Mod is not installed.
			InstallMod(modname, installinfo)
		end
	elseif installinfo.Installed and not installinfo.Enabled then
		-- If mod wants to be disabled but installed still.
		DisableMod(modname)
	elseif not installinfo.Installed then
		UninstallMod(modname)
	end
end

function UpdateMod(modname, installinfo)
	UninstallMod(modname, false, true)
	local _, handle = InstallMod(modname, installinfo, true)
end
function UpdateModForced(modname, handle)
	handle.Enabled = true
	handle.Installed = true
	UpdateMod(modname, handle)
end

-- [[ Calls a mod's setup, creates its handle, and if not static inserts it into the script chain ]]
function InstallMod(modname, installinfo, updating)
	local modfunc, modtab = LoadScriptIntoFuncAndTab(ModsFolder .. installinfo.NameID .. "/" .. installinfo.StartScriptPath)
	local uninstalldata = GetUninstallData(modname)
	if not modfunc then 
		GUI.DisplayMessageBox("Failed to find/compile \"" .. tostring(modname) .. "\"s start script.")
		return false
	end

	-- Insert NameID into the mod's table. This is used for certain things.
	modtab._NAMEID = installinfo.NameID

	local script_worked, error_message = pcall(modfunc)
	if not script_worked then
		return GUI.DisplayMessageBox("Mod failed to initialize!\n" .. tostring(modname) .. "\n\n" .. tostring(error_message))
	end
	
	if not installinfo.ClearData and modtab.OnUpdate then
		pcall(modtab.OnUpdate, uninstalldata)
	end
	DeleteUninstallData(modname)


	local creation_success, handle = CreateModHandle(modtab, installinfo)
	if creation_success and installinfo.Enabled and not installinfo.Static then
		InsertMod(handle)
	elseif installinfo.Static then
		StaticMods[modname] = handle
	end

	if creation_success and installinfo.Enabled then
		ModMetatable.MCM.AddModToMCM(handle)
	end

	return creation_success, handle

end

function GetModHandleWithName(name, all)
	local all_occurances = {}
	local curscript = CurrentlyRunningMods
	while curscript do
		if curscript.NameID == name then
			if all then
				all_occurances[#all_occurances+1] = curscript
			else
				return curscript, true
			end
		end
		curscript = curscript.next
	end
	if all then
		all_occurances[#all_occurance+1] = DisabledMods[name]
		return all_occurances
	end
	if StaticMods[name] then 
		return StaticMods[name], true
	end
	return DisabledMods[name], false
end
function GetAllMods()
	local allmods = {}
	-- Currently running mods
	local curscript = CurrentlyRunningMods
	while curscript do
		allmods[curscript.NameID] = curscript
		curscript = curscript.next
	end
	-- Static mods
	for k,v in pairs(StaticMods) do
		if not allmods[k] then
			allmods[k] = v
		else
			GUI.DisplayMessageBox("A mod is both in the StaticMods list and CurrentlyRunningMods list!!!\n" .. tostring(v.NameID))
		end
	end
	return allmods
end

function OnSaveLoad()
	if not Portable then
		ReadInstalledMods()
	end
	ModMetatable.ModHooks.OnSaveLoad()
end

function Terminate()
	ShouldDie = true
	return {RunningMods = GetRunningMods(), StaticMods = StaticMods, DisabledMods = DisabledMods, UninstalledMods = UninstalledMods,
			Hooks = ModMetatable.ModHooks.Hooks, HooksEnum = ModMetatable.ModHooks.HooksEnum}
end

function ReloadRunner()
	local runnerfunc = loadfile("scripts/Mod Manager/runner.lua")
	if type(runnerfunc) ~= "function" then
		GUI.DisplayMessageBox("Couldn't run ModManager Runner script!")
		return
	end
	local old_vals = Terminate()
	local runnertab = {}
	setfenv(runnerfunc, runnertab)
	setmetatable(runnertab,runnertab)
	runnertab.__index = _G
	runnertab._G = _G
	runnerfunc(old_vals)
	GeneralScriptManager.AddScript(runnertab)
	runnertab.ReadInstalledMods()
end

function GetRunningMods()
  local save_table = {}
  local mod_script = CurrentlyRunningMods
  while mod_script do
    save_table[#save_table + 1] = mod_script
    mod_script = mod_script.next
  end
  return save_table
end
function LoadRunningMods(save_table)
	CurrentlyRunningMods = nil
	CurrentlyRunningModsEnd = nil
	for k, v in ipairs(save_table) do
		if v.NameID and v.value and v.VersionMajor and v.VersionMinor then
			InsertMod(v)
		else
			GUI.DisplayMessageBox("A mod handle from the savetable is malformed!\n\n" ..
				"\nNameID: " .. tostring(v.NameID) ..
				"\nvalue: " .. tostring(v.value) ..
				"\nVersionMajor: " .. tostring(v.VersionMajor) ..
				"\nVersionMinor: " .. tostring(v.VersionMinor))
		end
	end
end

-- When updating the runner we need to update the loaded mods' metatables
-- as they're still on the old runners ModMetatable which causes big problems
function UpdateModMetatable()
	local function update_mods_in_table(modlist)
		for k,v in pairs(modlist) do
			setmetatable(v.value, ModMetatable)
		end
	end
	update_mods_in_table(GetRunningMods())
	update_mods_in_table(DisabledMods)
	update_mods_in_table(StaticMods)
end
function AddOldModsMCMs()
	local function add_mcms_from_modlist(modlist)
		for k,v in pairs(modlist) do
			ModMetatable.MCM.AddModToMCM(v)
			-- GUI.DisplayMessageBox("Adding to mcm " .. tostring(v.NameID))
		end
	end
	add_mcms_from_modlist(GetRunningMods())
	add_mcms_from_modlist(StaticMods)
end
function CleanAndAddSavedModHooks(hooks, old_hook_enum)
	if not hooks or not old_hook_enum then
		GUI.DisplayMessageBox("Manager failed to load saved modhooks! This could cause some mods to stop working.\nReason: saved hooks and/or hook enum is nil.")
		return
	end
	for old_hook_id,old_hook_table in pairs(hooks) do
		local hook_name = ModMetatable.ModHooks.GetHookName(old_hook_enum, old_hook_id)

		-- iterate through hook table's callbacks and add them to the new modhooks.
		local hookentry = old_hook_table.Cur
		while hookentry do
			ModMetatable.ModHooks.AddHook(hook_name, hookentry.id, hookentry.func, hookentry.arg)
			hookentry = hookentry.next
		end
	end
end
function AddOldModsHooks()

end

if type(saved[1]) == "table" then
	saved = saved[1]
	LoadRunningMods(saved.RunningMods or {})
	DisabledMods = saved.DisabledMods or {}
	UninstalledMods = saved.UninstalledMods or {}
	StaticMods = saved.StaticMods or {}

	-- Load saved callbacks into new hooks
	CleanAndAddSavedModHooks(saved.Hooks, saved.HooksEnum)
	-- Update loaded mods' metatables to the new ModMetatable
	UpdateModMetatable()
	-- Get mods' menus to add them back to the new MCM inst.
	AddOldModsMCMs()

	-- Debugging
	--[[
	local mods = ""
	for k,v in pairs(saved.RunningMods) do
		mods = mods .. tostring(v.NameID or "NoID") .. "\n"
	end
	GUI.DisplayMessageBox("Loading saved mods:\n\n" .. mods)
	--]]
end
local manentry = ModMetatable.MCM.NewActionEntry("Mod Manager", true, ModMetatable.MCM.OpenMenu, {"Mod Manager Config", ModMetatable.MCM.GetModManagerMenuEntries})
manentry.Key = "ModManagerMCM"
table.insert(ModMetatable.MCM.OptionSets, 1, manentry)

--ReadInstalledMods()

GUI.DisplayMessageBox("Manager Runner v" .. tostring(Version) .. " has run for the first time!")