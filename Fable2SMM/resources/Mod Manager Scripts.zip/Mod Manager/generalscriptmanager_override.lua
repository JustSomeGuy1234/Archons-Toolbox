-- This script is run on newgame and saveload.
-- A debug function has been relocated here to make space in gamescripts_r.
-- That space is then used to call this script, the purpose of which is to start the runner.


local init_path = "scripts/Mod Manager/init.lua"

-- Replace the LoadFromSave function with our own that loads the manager if it's not already running.
function GeneralScriptManager.LoadFromSave(save_table)
  GeneralScriptManager.CurrentlyRunningScripts = nil
  GeneralScriptManager.CurrentlyRunningScriptsEnd = nil
  local managerscript
  for k, v in ipairs(save_table) do
    if v.ScriptName == "ModManagerRunner" then
      managerscript = v
    end
    if v.PotentialCombatants and v ~= CombatRegister then
      v = CombatRegister
    end
    GeneralScriptManager.Insert(v)
    if v._Name == "Orchestra" then
      Orchestra = v
      Orchestra.JustLoaded = true
    end
  end
  -- Init will either call OnSaveLoad or start the runner depending on what managerscript is.
  pcall(loadfile(init_path), managerscript)
end


-- Load the manager if this is a new game. The above function is not called so we do this.
if IsLoadedFromSaveGame and not IsLoadedFromSaveGame() then
  local manageroverride = {}
  function manageroverride.Update()
    SetGeneralScriptManager(GeneralScriptManager)
    local worked, whynot = pcall(loadfile(init_path))
    if not worked then
      GUI.DisplayMessageBox("Failed to start Manager runner:\n" .. tostring(whynot))
    end
  end
  SetGeneralScriptManager(manageroverride)
end



--[[
  -- This was basically to let us patch the childhood script, but honestly it's more trouble than it's worth.
  -- Patching is still introduced through the runner.

  local worked, whynot = pcall(loadfile("scripts/Mod Manager/Patching/DeltaPatchIngame.lua"))
  if not worked then
    GUI.DisplayMessageBox(whynot)
    return
  end

  local overridenrequire, overridewhynot = pcall(_OverrideRequire)
  if not overridenrequire then
    GUI.DisplayMessageBox(tostring("Failed to override `require` for patching:\n" .. tostring(overridewhynot)))
    return
  end

  AddPatch("scripts/quests/qc010_childhood.lua", "scripts/Mods/ChildhoodPatch/patch.lua", "mychildhoodpatch")
--]]