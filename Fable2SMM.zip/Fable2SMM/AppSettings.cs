﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Text.Json;

namespace Fable2SMM
{
    class AppSettings
    {
        public const string ResourcesPath = "./resources/";
        public static string SettingsPath {get {return ResourcesPath + "settings.json";} }
        public static void LoadManagerSettings()
        {
            new AppSettings("");
            if (!Directory.Exists(ResourcesPath))
                Directory.CreateDirectory(ResourcesPath);
            if (File.Exists(SettingsPath))
            {
                // Load settings
                using (FileStream stream = File.OpenRead(SettingsPath))
                {
                    AppSettings loadedSettings = JsonSerializer.Deserialize<AppSettings>(stream, ManifestParser.JsonOptions);
                    Inst = loadedSettings ?? new AppSettings("");
                }
            }
            else
            {
                // Create settings file
                string serialized = JsonSerializer.Serialize<AppSettings>(Inst);
                File.WriteAllText(SettingsPath, serialized);
            }
        }

        public AppSettings(string GAMEPATH)
        {
            this.GAMEPATH = GAMEPATH;
            Inst = this;
        }
        public static AppSettings Inst { get { return _inst; }
            set { _inst = value; } }
        static AppSettings _inst;
        public string GAMEPATH { get { return ModManaging.GameFolder; } set { ModManaging.GameFolder = value; } }
    }
}
