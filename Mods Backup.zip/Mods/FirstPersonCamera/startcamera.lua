function CacheCameraFuncs()
	old_sac = SACCamera.FrameUpdate
	old_sac_input = SACCamera.ProcessGameAction
	old_canned = CannedActionCamera.FrameUpdate
	old_canned_input = CannedActionCamera.ProcessGameAction
end
CacheCameraFuncs()
IsEnabled = false
Debugging = true

Sensitivity = .5
MakeDogInvisible = false
ForceUseTrueHeadPosition = false
UseThirdPersonCombat = false
BodyVisibility = 1
FirstPersonModFOV = 80

PositionWeight = CVector3(0,0,0)
MaxSlowtimeRotationFrames = Timing.GetTickRate() / 1.5
MaxParryRotationFrames = Timing.GetTickRate()
FocusRotationFrames = 0

WasFirstPersonLastFrame = true
MaxSwapCameraFrames = MaxSlowtimeRotationFrames
SwapCameraFrames = 0

OurCameraPosition = QuestManager.HeroEntity:GetPosition() or CVector3(0,0,0)
FacingX, FacingY, FacingZ = .5,0,.5
FacingVec = CVector3(FacingX,FacingY,FacingZ)
CameraYaw, CameraPitch = 1,0


local auxscript = loadfile("scripts/Mods/FirstPersonCamera/auxiliary.lua")
if type(auxscript) ~= "function" then
	error("FPS Mod auxscript failed to compile")
end
setfenv(auxscript, getfenv(1))
auxscript()

local function MyAssert(obj, msg)
	if not obj then
		GUI.DisplayMessageBox(msg)
		Disabled()
		error(msg)
	end
end
local function MyAssertSafe(obj, msg)
	if not obj then
		GUI.DisplayMessageBox(tostring(msg))
		Disable()
		return false
	end
	return true
end
function Draw3DText(text, font_size, argtable, pos_offset)
	if not Debugging then
		return
	end
	local curcam = CameraManager.GetCurrentCamera().Camera
	local drawpos = Physics.GetFacingVector(curcam) + curcam:GetPosition()
	if pos_offset then
		drawpos = drawpos + pos_offset
	end
	Debug.Draw3DText(drawpos, text, font_size or 1, argtable or {DrawInFrontOfScene = true})
end
function DrawPcall(funcname, func, ...)
	local worked, whynot = pcall(func, ...)
	if not worked then
		local curcam = CameraManager.GetCurrentCamera().Camera
		Draw3DText(tostring(funcname) .. ": " .. tostring(whynot))
		return false
	end
	return true
end

local function HideDog(should)
	if should then
		GraphicAppearance.SetCameraAlpha(GetDog(), 0)
	else
		GraphicAppearance.SetCameraAlpha(GetDog(), 1)
	end
end

function GetShouldUseTrueHeadPosition(self)
	local should = ForceUseTrueHeadPosition or self.Activate == CannedActionCamera.Activate
		or Player.HasPlayerMode(self.Player, EPlayerMode.PLAYER_MODE_FALLING) or ExpressionPerformer.IsPerformingExpression(self.Player)
		or Swimming.IsSwimming(self.Player) or Player.HasPlayerMode(self.Player, EPlayerMode.PLAYER_MODE_INTERACTION)
	if should then
		Draw3DText("\n\nUsing true head position.")
	end
	return should
end


function ResumeTransitionFromSACIfNecessary(self)
	Draw3DText(tostring(SwapCameraFrames))
	if not UseThirdPersonCombat then
		return 
	end

	if not GetIsInCombat() then
		if self.DebugName == "StringAndCageCamera" then
			if WasFirstPersonLastFrame then
				if SwapCameraFrames > 0 then
					-- We are mid transition to firstperson
					ResumeTransitionFromSAC(self)
					SwapCameraFrames = Bounds(0, SwapCameraFrames - 1, MaxSwapCameraFrames)	
					return true
				else
					-- We are first person and are not transitioning
					return false
				end
			else
				-- We are not in combat and we weren't first person last frame. Start transition from SAC!
				SwapCameraFrames = MaxSwapCameraFrames
				WasFirstPersonLastFrame = true
				local cur_facing = Physics.GetFacingVector(self.Camera)
				CameraYaw = math.atan2(cur_facing:GetX(), cur_facing:GetY())
				CameraPitch = cur_facing:GetZ()
				ResumeTransitionFromSAC(self)
				return true
			end
		end
	else
		-- We are in combat.
		return false
	end
end
function ResumeTransitionFromSAC(self)
	if SwapCameraFrames <= 0 then
		return
	end

	-- PositionWeight = Physics.GetFacingVector(self.Camera)
	-- FocusRotationFrames = SwapCameraFrames

	local campos = self.Camera:GetPosition()
	local pos_dif = campos - GraphicAppearance.GetDummyObjectPosition(self.Player, "Character.Focal.Mouth", 0)
	pos_dif = pos_dif / SwapCameraFrames
	Camera.MoveTo(self.Camera, campos - pos_dif)
	UpdateRotation(self)
end

function FPSFrameUpdate(self)
	if not MyAssertSafe(self.Player, "MyFirstPersonCamera No Player!") or MyAssert(self.Camera, "MyFirstPersonCamera No Camera!") then
		return
	end
	if ResumeTransitionFromSACIfNecessary(self) then
		return
	end
	if UseThirdPersonCombat and GetIsInCombat() then
		if self.DebugName == "StringAndCageCamera" then
			self.CurrentPosition = self.Camera:GetPosition()
			self.DesiredPosition = self.Camera:GetPosition()
			self.DesiredAngles = Physics.GetFacingVector(self.Camera)
			if WasFirstPersonLastFrame then
				WasFirstPersonLastFrame = false
				self:Activate(self.Player, self.Camera, self.Camera)
			end
			old_sac(self)
			return
		else
			Draw3DText("upd: not SACCamera!")
		end
	end

	DrawPcall("CheckForSlowtime", CheckForSlowtime, self.Player)
	DrawPcall("CheckForParry", CheckForParry, self.Player)
	DrawPcall("CheckForLockon", CheckForLockon, self)

	local infront = Physics.GetFacingVector(self.Camera)
	if not self.Camera or not self.Player then
		Draw3DText("No camera or player", .7)
		return
	end

	UpdatePosition(self)
	UpdateRotation(self)
	Camera.SetRoll(self.Camera, 0)
	Camera.SetBlurCut(self.Camera, 0)
	Camera.SetDOFAlpha(self.Camera, 0)
	Camera.SetFOV(self.Camera, FirstPersonModFOV or 80)
	CameraManager.CameraPosition = self.CurrentPosition
	HideDog(MakeDogInvisible)
	GraphicAppearance.SetCameraAlpha(self.Player, BodyVisibility)

end
function CalculateRotation()
	-- I am not a mathemagician :)
	CameraYaw = CameraYaw % (math.pi*2)
	CameraPitch = Bounds(-1.5, CameraPitch, 1.5) -- pi/2 max?

	if FocusRotationFrames > 0 then
		local pseudo_cam_pos = QuestManager.HeroEntity:GetPosition()
		pseudo_cam_pos:SetZ(OurCameraPosition:GetZ())
		local dir_weight = PositionWeight - pseudo_cam_pos
		dir_weight:Normalise()
		local weight_angle = math.atan2(dir_weight:GetX(), dir_weight:GetY())
		local weight_dir_dif = math.atan2(math.sin(CameraYaw - weight_angle), math.cos(CameraYaw - weight_angle))
		CameraYaw = CameraYaw - (weight_dir_dif / FocusRotationFrames)
		CameraPitch = dir_weight:GetZ()
		Draw3DText("dir weight angle dif: " .. tostring(weight_dir_dif) .. "\ndir weight: " .. tostring(dir_weight) ..
					 "\nPosition Weight:" .. tostring(PositionWeight - QuestManager.HeroEntity:GetPosition()), 1)
		FocusRotationFrames = FocusRotationFrames - 1
	end

	FacingX = math.sin(CameraYaw)
	FacingY = math.cos(CameraYaw)
	FacingZ = math.sin(CameraPitch)

	FacingX = FacingX*math.abs(math.cos(CameraPitch))
	FacingY = FacingY*math.abs(math.cos(CameraPitch))
end
function UpdateRotation(self)
	CalculateRotation(OurCameraPosition)
	FacingVec = CVector3(FacingX,FacingY,FacingZ)
	Camera.SetDirection(self.Camera, FacingVec)
end

function CalculatePosition(self)
	local cam_offset = CVector3(FacingVec:GetX(), FacingVec:GetY(), 0)
	cam_offset:NormaliseXY()
	cam_offset = cam_offset / 7.5

	local head_centre = Creature.GetCollisionHeadPosition(self.Player)
	if GetShouldUseTrueHeadPosition(self) then
		local mouth_pos = GraphicAppearance.GetDummyObjectPosition(self.Player, "Character.Focal.Mouth", 0)
		local mouth_rot = GraphicAppearance.GetDummyObjectFacingDirection(self.Player, "Character.Focal.Mouth", 0)
		local relative_up = FacingVec:GetCross(CVector3(0,0,.05)):GetCross(FacingVec)
		head_centre = mouth_pos - (mouth_rot / 7) + relative_up
	else
		cam_offset = cam_offset * 2.5
	end
	OurCameraPosition = head_centre + cam_offset
end
function UpdatePosition(self)
	CalculatePosition(self)
	Camera.MoveTo(self.Camera, OurCameraPosition)
end
function GetOurCameraPosition(self)
	-- TODO: figure out how to make RangedCombatCamera use our own position.
	-- Substituting GetDesiredCameraPos works, but our own FacingXYZ is used for an offset so the camera is slightly off
	CalculatePosition(self)
	return OurCameraPosition
end

function FPSProcessGameAction(self, action, control_x, control_y)
	if UseThirdPersonCombat and GetIsInCombat() then
		if self.DebugName == "StringAndCageCamera" then
			old_sac_input(self, action, control_x, control_y)
			return
		else
			Draw3DText("				input: we are NOT SACCamera")
		end
	end

	if action == EGameAction.GAME_ACTION_ROTATE_CAMERA then
		if CheckForLockon(self) then
			if math.abs(control_x) > 0.8 and (not LastSwapFrame or Timing.GetWorldFrame() - LastSwapFrame > Timing.GetTickRate() / 5) then
				LastSwapFrame = Timing.GetWorldFrame()
				Targeting.CheckForBetterTargetInDirection(self.Player, control_x < 0, 20)
			end
		else
			CameraYaw = CameraYaw + (control_x / 3) * Sensitivity
			CameraPitch = CameraPitch + (control_y / 3) * Sensitivity
		end
	end
end


function CheckForSlowtime(player)
	local is_posted, message = MessageEvents.IsMessageSentBy(EMessageEventType.MESSAGE_EVENT_CREATURE_CAST_SPELL_DIRECTION, player, spellmsgid)
	if is_posted then
		spellmsgid = message:GetID()
		local target = message:GetEntitySentTo()
		if message:GetExtraDataAsNumber() == ESpellType.SPELL_SLOW_TIME and target then
			PositionWeight = GetGoodDummyPosition(target)
			FocusRotationFrames = MaxSlowtimeRotationFrames
		end
	elseif not player then
		Draw3DText("no player!!!")
	else
		-- Draw3DText("not posted")
	end
end
function CheckForParry(player)
	local is_posted, message = MessageEvents.IsMessageSentBy(EMessageEventType.MESSAGE_EVENT_HIT_WITH_ACTION_TYPE, player, parrymsgid)
	if is_posted then
		parrymsgid = message:GetID()
		if message:GetExtraDataAsNumber() == EAbilityActionType.ABILITY_ACTION_BLOCK_PARRY then
			FocusRotationFrames = MaxParryRotationFrames
			PositionWeight = GetGoodDummyPosition(message:GetEntitySentTo())
			return
		end
	end
end
function CheckForLockon(self)
	local player = self.Player
	if Player.HasPlayerMode(player, EPlayerMode.PLAYER_MODE_TARGET_LOCK) then
		local target = Targeting.GetTarget(player)
		if not target or not target:IsAlive() then
			Draw3DText("Player is in lockon but no target!", 1, {DrawInFrontOfScene = true})
			return false
		end

		-- We have a target. We can set PositionWeight to the target's position and let that do most of the work.
		-- But we will also do some extra stuff to make the position a bit nicer.
		FocusRotationFrames = 4
		-- Instead of targeting the head directly, we use the enemy's (much more stable) base position and add the head's height to it.
		PositionWeight = target:GetPosition()
		local dummy_height = GetGoodDummyPosition(target):GetZ()
		PositionWeight:SetZ(dummy_height)
		-- Use hero position rather than head position to get direction to look at. Head moves too rapidly to be comfortable.
		local hero_pos = self.Player:GetPosition()
		local pseudo_cam_pos = CVector3(hero_pos:GetX(), hero_pos:GetY(), OurCameraPosition:GetZ())
		-- behind target is used to make the height of the enemy more of a weight than an exact point to look at. This helps with enemy's heights drastically changing
		local behind_target = PositionWeight - pseudo_cam_pos
		behind_target:SetZ(PositionWeight:GetZ() - dummy_height)
		behind_target:Normalise()
		behind_target = behind_target*2
		PositionWeight = PositionWeight + behind_target
		return true
	else
		return false
	end
end
function GetGoodDummyPosition(ent, dummy_object)
	local function get_best_dummy_object(dummy_objects)
		for k,v in ipairs(dummy_objects) do
			if GraphicAppearance.HasDummyObject(ent, v, 1) then
				return v
			end
		end
	end
	local dummies = {DummyObjects.COMBAT_MOUTH, "Character.Focal.Mouth", DummyObjects.CARRY_MOUTH, "Character.Focal.Eye.Right", "Character.Focal.Eye.Left", DummyObjects.CHEST}

	local position = ent:GetPosition()
	if GraphicAppearance.IsAvailable(ent) then
		dummy_object = dummy_object or get_best_dummy_object(dummies)
		if dummy_object then
			position = GraphicAppearance.GetDummyObjectPosition(ent, dummy_object, 0)
		end
	end
	return position
end

function GetIsInCombat()
	local results = SACCamera:CalculateNearbyFoes()
	return #results > 0
end

function EnableFirstPerson()
	if QuestManager.HeroEntity then
		IsEnabled = true
		local hero_face = Physics.GetFacingVector(QuestManager.HeroEntity) -- Should probably use self.Camera but doesn't have access
		CameraYaw = math.atan(hero_face:GetX() / hero_face:GetY())
		CameraPitch = 0
	else
		GUI.DisplayMessageBox("FirstPersonMod: No QuestManager.HeroEntity during EnableFirstPerson. I'm surprised the game still functions.")
		return
	end
	ReplaceSAC()
	ReplaceCanned()
	ReactivateCamera()
end
function DisableFirstPerson()
	RestoreSAC()
	RestoreCanned()
	ReactivateCamera()
	IsEnabled = false
end
function ToggleFirstPerson(call_activate)
	if not IsEnabled then
		if call_activate then
			SACCamera:Activate()
		end
		EnableFirstPerson()
	else
		DisableFirstPerson()
	end
end
function ReactivateCamera()
	-- Look away if you don't like hacky code.
	-- This function is called by the main thread, and by ModHooks, so we cannot yield.
	-- Instead we just let GSM run it.
	-- We also hijack the GetZoomLevel call for RangedCombatCamera to workaround a bug

	OverrideRangedZoom()
	local tab = {}
	function tab.Update()
		CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_RANGED_AIM)
		ScriptFunction.WaitForTimeInSeconds(.5)
		CameraManager.SetCameraOverride(QuestManager.HeroEntity, ECameraMode.CAMERA_MODE_DEFAULT)
		ScriptFunction.WaitForTimeInSeconds(.5)
		RestoreRangedZoom()
	end
	function tab.OnError(err)
		-- GUI.DisplayMessageBox("FirstPersonMod: Error in transition coroutine:\n\n" .. tostring(err))
	end
	GeneralScriptManager.AddScript(tab)
end
function OverrideRangedZoom()
	--[[
	if not OriginalProxyMeta then
		OriginalProxyMeta = getfenv(RangedCombatCamera.UpdateZoom)
	end
	setfenv(RangedCombatCamera.UpdateZoom, ProxyMeta)
	--]]
	RangedCombatCamera.ZoomFOVOverride = 75
	-- RangedCombatCamera:UpdateZoom()
end
function RestoreRangedZoom()
	RangedCombatCamera.ZoomFOVOverride = nil
	-- setfenv(RangedCombatCamera.UpdateZoom, OriginalProxyMeta or _G)
end

-- [[ Replacement Logic ]]
function ReplaceSAC()
	SACCamera.FrameUpdate = FPSFrameUpdate
	SACCamera.ProcessGameAction = FPSProcessGameAction

	local search = SearchTools.FilterWithScriptFilter(SearchTools.StartNewSearch("all"), function(ent) 
		return GraphicAppearance.IsAvailable(ent) and GraphicAppearance.GetFadedByCamera(ent) 
	end)
	local results = SearchTools.GetSearchResults(search)
	for _, entity in ipairs(results) do
		GraphicAppearance.SetCameraAlpha(entity, 1)
	end
end
function RestoreSAC()
	SACCamera.FrameUpdate = old_sac
	SACCamera.ProcessGameAction = old_sac_input
end
function ReplaceCanned()
	CannedActionCamera.FrameUpdate = FPSFrameUpdate
	CannedActionCamera.ProcessGameAction = FPSProcessGameAction
end
function RestoreCanned()
	CannedActionCamera.FrameUpdate = old_canned
	CannedActionCamera.ProcessGameAction = old_canned_input
end

-- [[ Mod Management Logic ]]
function Enabled()
	EnableFirstPerson()
end
function Disabled()
	DisableFirstPerson()
	if ModHooks then
		ModHooks.RemoveHook("OnSaveLoad", "FPSCamHook")
		ModHooks.RemoveHook("OnEnterArea", "FPSCamHook")
	end
end
function Uninstall()
	Disabled()
end

function GetMCMEntry()
	return MCM.NewActionEntry("First Person Cam", true, MCM.OpenMenu, {"First Person Mod", GetConfigMenuEntries}), "FirstPersonCamera"
end


if ModHooks then
	-- We're a mod
	ModHooks.AddHook("OnSaveLoad", "FPSCamHook", EnableFirstPerson, true)
	ModHooks.AddHook("OnEnterArea", "FPSCamHook", EnableFirstPerson, true)
end
