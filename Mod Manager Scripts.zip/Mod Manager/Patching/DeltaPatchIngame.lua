_OriginalRequire = require

local patchfolder = "GAME:\\data\\scripts\\Mod Manager\\Patching\\"
_ApplyPatch = loadfile(patchfolder .. "DeltaPatchApplicator.lua")

local patchertype = type(_ApplyPatch)
if patchertype ~= "function" then
	GUI.DisplayMessageBox("_ApplyPatch function failed to compile! patching will not be available (yet):\nfunction type: " .. tostring(patchertype))
	return false
end

function _GetFileName(scriptname)
	local slash = (scriptname:find("/") or 1) > (scriptname:find("\\") or 1) and "/" or "\\" -- nested ternary ftw

	scriptname = scriptname:sub(1-scriptname:reverse():find(slash),-1)
	local endindex = scriptname:find(".lua")
	return scriptname:lower():sub(1, endindex and endindex-1)
end

PatchCache = {}

--[[
function ReCacheAllPatches(force)
	for k,scriptname in pairs(PatchCache) do
		local source = v.Source
		local patch = v.PatchPath
		PatchFunction(scriptname, source, patch, force)
	end
end
--]]

function _PatchRequire(sn)
	local endindex = sn:find(".lua")
	local scriptname = sn:lower():sub(1, endindex and endindex-1)

	local scripttable = PatchCache[scriptname]
	if scripttable and scripttable.func then
		local moduleworked, modulewhynot = pcall(scripttable.func, scriptname)
		if not moduleworked then
			GUI.DisplayMessageBox("Failed to run patched script " .. tostring(scriptname))
			return _OriginalRequire(scriptname)
		end
		return _G[scriptname]
	else
		return _OriginalRequire(scriptname)
	end
end

function _RestoreRequire()
	rawset(_G, "require", _OriginalRequire)
end
function _OverrideRequire()
	rawset(_G, "require", _PatchRequire)
end

--[[
scriptpath : Source script's path relative to /data/ excluding the bnk file e.g. scripts/quests/qc010_childhood.lua
patchpath : Patch file's path relative to /data/ e.g. scripts/Mods/childhoodmod/childhoodquest_patch.lua
modkey : A string that's used to identify which mod added the patch. Try to keep this the same for each patch your mod adds.
overwrite : If true, overwrite a pre-existing cached patch should there be one.
--]]
function AddPatch(scriptpath, patchpath, modkey, overwrite)
	local scriptname = _GetFileName(scriptpath)
	local worked, patchedfunc = pcall(_ApplyPatch, scriptpath, patchpath)
	if not worked then
		return worked, patchedfunc
	end

	if not PatchCache[scriptname] or overwrite then
		PatchCache[scriptname] = {
			func = patchedfunc,
			key = modkey,
			originalpath = scriptpath,
			patchpath = patchpath
		}
		return true
	else return false, "Script already has a patch!" end
end

--[[
	scriptpath : the script's path or filename to be un-patched. Try to keep this the same as whatever you gave AddPatch.
	modkey : must be identical to the modkey given to AddPatch, unless force is true
	force (NOT RECOMMENDED): if the modkey doesn't match but you must remove a patch, set as true. runs the risk of removing a different mod's patch.
		This should ONLY be used if the user wants to unpatch the script regardless of which mod added it.
--]]
function RemovePatch(scriptpath, modkey, force)
	local scriptname = _GetFileName(scriptpath)
	local patchtab = PatchCache[scriptname]
	if patchtab then
		if patchtab.key == modkey or force then
			PatchCache[scriptname] = nil
			return true
		else
			return false, "Given key did not match the patch's key. Pass true as the third arg to force."
		end
	end

end
