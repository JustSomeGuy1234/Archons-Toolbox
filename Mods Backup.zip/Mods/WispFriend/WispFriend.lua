-- TODO: Add status effects. -- In Progress (vulnerability done, bind in progress)
-- 		 	Bind: Currently caging enemies inbetween 4 items. Might make em invisible and use that shield fx (luciens?), or the shadow tar fx. Also, look at physics for collision to prevent hero.
--					Issue though, if the hero moves away their ai collision is disabled. Maybe make it so their ai is disabled while the hero is far.
--			Stun: Combat.SetCanFight(ent, false) and Combat.SetCanFlee
--			Other incapacitation: Look at the navigation table.
--			Telekenesis: Apply scripted hit to a nearby enemy (assuming hittable)
--			Figure out how to apply an effect for a limited time without having the wisp hop. 
--				Or just have the wisp hop to the hero after applying an effect, then wait as a cooldown.


-- TODO: Particles highlight the target depending on current effect
-- Candidate effects: FX_Necromancer_Target, FX_Shadow_Teleport (lingers), FX_Forest_Troll_Travel (good for stun), FX_Blast_Trail (good for targeting), FX_Spell_Fireball (good fire spell)
--					  FX_Clothes_Change (huge quick blue explosion. Maybe freeze?), FX_PotionEffect_Experience_Strength(also good target indicator), FX_PotionEffect_Experience_Skill, FX_PotionEffect_Experience_Will,
--					  FX_XP_Powerup_Effects, FX_Hero_Teleport (blue geyser), FX_Musicbox_Disappear (combo hit effect), FX_HeroCircle_Symbol_S and _Red_S (hero floor symbol, good ultimate), 
-- 					  FX_HeroCircle_Symbol and _Red(particle ring around hero symbol), FX_Wide_Light_Beam (beam in guild hall. Good heal maybe.) and FX_God_Ray (smaller) and FX_Highlight_Beam (even less offensive),
--					  FX_Hammer_Blessing (big shiny sparkles), FX_Lucien_Shockwave (Good for big force/push back), FX_Standard_Teleporter (swirly magic teleporter), 
--					  FX_Magic_Ship_Blast (straight up huge EXPLOSION) or FX_Wood_Explosion (same without sound) or FX_Explosion_Rock (slightly smaller with rock), 
--					  FX_HeroHill_Ranged_S and _Melee_ and _Magic_ and _Hero_ (like hero symbol but smaller and louder), FX_Goodguy_Teleporter (like teleporter but without ring)
--					  FX_HeroHill_Melee _Ranged _Melee _Magic (good for more aggressive targeting), FX_Musicbox_Base (Small gold glowy), FX_HeroHill_Sparkles (aoe bigger sparkles),
--					  FX_Lucien_Shield (sphere of fuzzy stuff, maybe good for bind/stun), FX_Lucien_Shield_Hit, FX_Blocking_Fire (wall of fire), FX_Banshee_Debris_Suck (windy blowing sucky)
--					  FX_Poison_Smoke (green gas)
--					  FX_Ritual_Statue_Water (if you want someone wet), FX_CullisGate_Stage_01 and 02 and 03 (could be very good for targeting)! FX_CullisGate_UpBlast (huge electric "cage"), 
-- 					  FX_Teleporter_Explosion (SMITED), FX_Shadow_Tar (bubbly floor stuff, discrete for targeting) 
--				      fxscr_ribbon_red (red lasery thing, good for drain)
--					  
-- TODO: Either persist between level loads or don't but respawn. Script seems good at not dying, just the wisp ent isn't.
-- TODO: Add menu for configs
-- TODO: Testing

-- I'm unfortunately 99% certain that stopping the wisp sound with the stop sound function works but it just starts again probably due to an animation/timer thing.
-- 		Figured it out! Just set the sound category's pitch to 0!

-- We can spawn the wisp visuals ourselves.
-- Funnily enough it's with ElectricArcManager.CreateNamedEntityDummyEndPointsArc("mywisp", GetPlayerHero(), GetPlayerHero(), "Character.FX.Particle.", "", "FXCRE_Hollowman_Wisp", false)

-- TODO: Work on the bind effect and effect update in general.
-- Currently for cooldown I just set target to hero, but this causes the wisp to try to effect the hero.
--		We should probably get rid of the swap timer and replace it with the cooldown timer or something
-- Maybe make an enemy that escapes the cage ragdoll hehe 

-- Casting spells and implementing the combo system should actually be REALLY easy.
-- Create another coroutine for tracking hits, both sent and received.
-- In the ApplyEffect function just cast a spell, and scale it by the combo!

-- TODO: Beetle facehugger swarm special attack
-- TODO: Butterfly-related special attack

-- TODO Priority: Modify the ZAP ultimate: Slow down the into, remove the outof, and wait until the action is finished for zap

-- TODO Priority:
-- Implement Block.ClearBlocking(target). It seems to clear the target's block counter so you can endlessly hit em.
-- Should use it during the status effect update or something that is run every few hundred ms. Should it be applied for specific effects like bind, or all of em?

-- TODO Priority:
-- Instead of doing a damage multiplier by decreasing health, use Combat.SetDamageMultiplier(combatant, multiplier)

-- TODO: Combat fluidity
-- Combat.GetNumberOfSuccessiveHits
-- Combat.SetDamageMultiplier()
-- Combat.LaunchedCounterAttack()
-- Combat.IsChargingFlourishAttack()
-- Player.ReloadHeroCombatBalanceData()
-- SpellManager.IsCharging -- works
-- SpellManager.ResetEntityMagic -- works
-- SpellManager.ResetEntityMagicAffects
-- Debug.SetExperienceOrbGeneralXPMultiplier
-- Debug.SetFlourishAddedDamage



require"MultipageMenu"

local tick_counter = 0
PainfulDebug = false
Entities = {}
DebugText = "Default Debug Text"
ShowDebugText = true
ShouldDie = false
MaxHeroDistance = 4 			-- Distance the wisp can fall behind the hero before hopping to them.
MaxTargetDistance = 2.5			-- Distance wisp can be from target enemy before hopping to them.
TargetHeightOffset = .4 		-- Height from entities feet the wisp will hop to.
TargetSwapTime = 6 				-- How often the wisp will swap targets to keep things interesting.
CombatSpeed = 1 				-- How fast the wisp moves during combat
RoamingSpeed = .7 				-- How fast the wisp moves when following the hero
InCombat = false				-- While it's something I'd rather keep in a local, it needs to be accessable outside of the AI update too. (could keep it local but have a func that gets it?)
WispTarget = GetPlayerHero()	-- Once again something I'd like to keep in a local but it needs to be accessed by the vfx coroutine.
WispEffects = {
					   [1] = {Name = "Vulnerability", Cooldown = 4, EffectTime = 5, VFX = ""},
					   [2] = {Name = "Bind", Cooldown = 4, EffectTime = 8, VFX = ""}
			  }
EffectEnum = {VULNERABILITY = 1, BIND = 2}
CurrentEffect = EffectEnum.VULNERABILITY
BindObjects = {}

Upgrades = {}
BaseComboCountdown = 4
BaseComboPerLevel = 5
local CurrentCombo = 0


local last_x_press, last_a_press, LastMessageID_PressedAButton, LastMessageID_PressedXButton
last_x_press = -1000; last_a_press = 1000


function NewWisp()
	if Entities.WispEnt and Entities.WispEnt:IsAlive() then
		Entities.WispEnt:Destroy()
	end
	Entities.WispEnt = Debug.CreateEntityByHero("HollowManWisp", "MyWisp")
	CombatRegister:SetHollowManWispMovement(Entities.WispEnt, true)
	CombatRegister:SetHollowManWispSpawn(Entities.WispEnt, false)
	Combat.SetCanFight(Entities.WispEnt, false)
	Combat.SetCanFlee(Entities.WispEnt, false)
	Combat.SetCanBeAttacked(Entities.WispEnt, false)
	Follow.SetAsLevelFollowing(Entities.WispEnt, true)
	Wisp.SetSpeed(Entities.WispEnt, RoamingSpeed)

end
function KillWisp()
	ShouldDie = true
	if Entities.WispEnt then
		Entities.WispEnt:Destroy()
	end
	if Entities.CurrentVFX then
		Entities.CurrentVFX:Destroy()
	end
	RemoveCage()
end

-- We currently have... 3 coroutines including the manager.
aiworked = false
aiwhynot = "AI coroutine hasn't been started yet"
menuworked = false
menuwhynot = "Menu coroutine hasn't been started yet"
comboworked = false
combowhynot = "Combo coroutine hasn't been started yet"

-- The normal Update coroutine basically acts as a manager for the wisp AI and VFX coroutines.
-- This "manager" creates the wisp's entity and AI instance, and the VFX coroutine on the first tick.
-- Afterwards, it simply updates them until there's an error.
-- If an error occurs, it will display it and stop.
function ModUpdate()
	NewWisp()
	-- Mutes the wisp's whining
	ScriptFunction.WaitForTimeInSeconds(1)
	Sound.SetPitchForSoundCategory(Entities.WispEnt, "", 0, 1)

	aiupdate = coroutine.create(AIUpdate)
	comboupdate = coroutine.create(ComboUpdate)
	menuupdate = coroutine.create(MenuUpdate)
	while not ShouldDie do
		coroutine.yield()
		tick_counter = tick_counter + 1
		
		CheckWisp()

		if ShowDebugText then
			Debug.Draw3DText(Entities.WispEnt:GetPosition() + CVector3(0,0,.5), DebugText, 1.2, {DrawInFrontOfScene = true})
			Debug.Draw3DText(Entities.WispEnt:GetPosition() + CVector3(0,0,-0.5), tostring(CurrentCombo), 1.2, {DrawInFrontOfScene = true})
		end

		aiworked, aiwhynot = coroutine.resume(aiupdate)
		if not aiworked then
			GUI.DisplayMessageBox("Wisp errored! Reason:\n " .. tostring(aiwhynot))
			ShouldDie = true
		end

		comboworked, combowhynot = coroutine.resume(comboupdate)
		if not comboworked then
			GUI.DisplayMessageBox(tostring("Combo Coroutine errored! Reason:\n" .. tostring(combowhynot)))
			ShouldDie = true
		end

		menuworked, menuwhynot = coroutine.resume(menuupdate)
		if not menuworked then
			GUI.DisplayMessageBox("Wisp Menu errored! Reason:\n " .. tostring(menuwhynot))
			ShouldDie = true
		end
	end
	KillWisp()
	coroutine.yield()
end

function CheckWisp()
	if not Entities.WispEnt or not Entities.WispEnt:IsAlive() then
		NewWisp()
	end
end
-- AI Update coroutine does the meaty stuff and is updated every tick by the above coroutine.
function AIUpdate()
	while not ShouldDie do
		-- The beginning is only ever returned to when swapping between roaming and combat modes.
		ScriptFunction.WaitForTimeInSeconds(.1)
		InCombat = AreEnemiesNear()
		if not InCombat and not ShouldDie then
		--[[ Roaming Mode ]]--

			Wisp.SetSpeed(Entities.WispEnt, RoamingSpeed)
			local tooFar = not IsDistanceBetweenThingsUnder(Entities.WispEnt, QuestManager.HeroEntity, MaxHeroDistance)
			while not InCombat do
				ScriptFunction.WaitForTimeInSeconds(.5)
				tooFar = not IsDistanceBetweenThingsUnder(Entities.WispEnt, QuestManager.HeroEntity, MaxHeroDistance)
				if tooFar then
					Wisp.SetDestination(Entities.WispEnt, QuestManager.HeroEntity:GetPosition() + CVector3(0,0,3))
					while Wisp.IsMoving(Entities.WispEnt) do
						ScriptFunction.WaitForTimeInSeconds(.25)
						DebugText = "Roaming\nHopping to Hero"
					end
				end
				DebugText = "Roaming\nWaiting for Hero to move"
				InCombat = AreEnemiesNear()
			end

		elseif InCombat and not ShouldDie then
		--[[ Combat Mode ]]--

			local function ApplyCooldown(cooldown, cooldowntimer, swaptimer)
				cooldowntimer:SetTime(cooldown)
				swaptimer:SetTime(cooldown + .1)
				RemoveEffect(WispTarget, CurrentEffect)
				WispTarget = GetPlayerHero()
			end

			DisplayBlocking("Entering combat mode")
			Wisp.SetSpeed(Entities.WispEnt, CombatSpeed)
			local tooFar = not IsDistanceBetweenThingsUnder(Entities.WispEnt, QuestManager.HeroEntity, MaxTargetDistance)
			local swap_timer = QuestManager.NewTimer(1) -- Timer used to hop targets, but first loop we want it small so it leaves the hero.
			WispTarget = GetPlayerHero()
			DebugText = "Entering Combat"
			local applied_timer = QuestManager.NewTimer(0)
			local cooldown_timer = QuestManager.NewTimer(0)
			local hascooled = true
			local got_new_target = false -- Used to immediately hop to new target rather than wait for it to trigger
			local original_effect_pos
			local ultimate_cooldown = QuestManager.NewTimer(0)
			while InCombat and not ShouldDie do				
			-- Combat Loop

				-- If it's time to find an enemy, let's try.
				if swap_timer:GetTime() == 0 then
					swap_timer:SetTime(TargetSwapTime)
					WispTarget = AcquireNewTarget(WispTarget)
					got_new_target = true
				end
				if WispTarget == nil or Entities.WispEnt == nil or type(MaxTargetDistance) ~= "number" then
					DisplayBlocking("Somehow wisp target or Entities.WispEnt or MaxTargetDistance is nil??? Killing Wisp AI.")
					return
				end
				if not WispTarget:IsAlive() then
					DisplayBlocking("wisp target died, getting new target")
					DoTargetSwap(WispTarget, CurrentEffect, applied_timer, swap_timer, WispEffects[CurrentEffect].EffectTime)
				end
				DebugText = "Combat waiting target movement\nTarget: " .. (WispTarget:GetName() or "noname")

				-- Position update bit. 
				if got_new_target or tick_counter % 10 == 0 then
					got_new_target = false
					tooFar = not IsDistanceBetweenThingsUnder(Entities.WispEnt, WispTarget, MaxTargetDistance)
					if tooFar then
						DisplayBlocking("About to move wisp")
						Wisp.SetDestination(Entities.WispEnt, WispTarget:GetPosition() + CVector3(0,0, MaxTargetDistance - 0.1))
					end
				end

				-- Effect update
				if cooldown_timer:GetTime() <= 0 then
					if applied_timer:GetTime() <= 0 then
						DisplayBlocking("applied timer and cooldown timer is 0\neither applying effect or removing it")
						if hascooled then
							DoTargetSwap(WispTarget, CurrentEffect, applied_timer, swap_timer, WispEffects[CurrentEffect].EffectTime)
							original_effect_pos = WispTarget:GetPosition()
							hascooled = false
						else
							DisplayBlocking("effect duration over, applying cooldown")
							local cooldown_duration = WispEffects[CurrentEffect].Cooldown
							ApplyCooldown(cooldown_duration, cooldown_timer, swap_timer)
							hascooled = true
						end
					else
						-- update current effect. Status update will take the original effect pos and do something if the target has moved from it.
						if tick_counter % 5 == 0 then
							StatusUpdate(WispTarget, original_effect_pos)
							if WispTarget ~= QuestManager.HeroEntity then
								Block.ClearBlocking(WispTarget)
							end
						end
					end
				end

				if ultimate_cooldown:GetTime() <= 0 then
					if CurrentCombo >= 6 and IsXAndAPressed() then
						ZapUltimate()
						ultimate_cooldown:SetTime(1)
					end
				end

				InCombat = AreEnemiesNear()
				coroutine.yield()
			end
			DisplayBlocking("exiting combat, calling RemoveEffect")
			RemoveEffect(WispTarget, CurrentEffect)
		end
	end
end

-- For updating the status effects that get applied to enemies. Called exclusively by AI coroutine.
function StatusUpdate(target, center)
	if not target or not center then
		DisplayBlocking("StatusUpdate was given no target and/or no center!\nTarget:" .. tostring(target) .. "\n\ncenter: " .. tostring(center))
		return
	end
	if CurrentEffect == EffectEnum.BIND and ((center - target:GetPosition()):GetLength() > 1) then
		RemoveEffect(target, CurrentEffect)
		ApplyEffect(target, CurrentEffect)
	end
end




-- Menu system. If the player goes first person, looks at the entity, and presses X then open the menu. TODO: Add the looking at entity bit.
function MenuUpdate()
	local function show_menu()
		local main_menu_result
		while main_menu_result ~= 0 do
			main_menu_result = MultipageMenu.ShowMenuBoxWithPages(
				"Wisp Menu Title",
				{ 
					{TextTag = "Say Hello", Enabled = true},
					{TextTag = "Toggle Debug Text " .. "(Enabled: " .. tostring(ShowDebugText) .. ")", Enabled = true},
					{TextTag = "Spell Select", Enabled = false} 
				}
			)
			if main_menu_result == 1 then
				GUI.DisplayMessageBox("Hi!")
				return -- Only return if an option doesn't lead to another menu or you don't want the user to have multiple options.
			elseif main_menu_result == 2 then
				ShowDebugText = not ShowDebugText
			end
		end
	end

	while not ShouldDie do
		if not InCombat then
			if Player.IsInFirstPerson(QuestManager.HeroEntity) then
				local pressed_x, message = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_GENERIC_X_BUTTON_PRESSED, LastMessageID_PressedXButton)
				if pressed_x and (Timing.GetWorldFrame() - message:GetTimeStamp() < 5) then
					LastMessageID_PressedXButton = message:GetID()
					show_menu()
				end
			end
		end
		coroutine.yield()
	end
end

function ComboUpdate()
	local was_enemy_hit, enemy_hit_message, hit_enemy, lastid, countdown_timer, hero, wisp, damage_type -- effishunsee
	countdown_timer = QuestManager.NewTimer(0)
	hero = QuestManager.HeroEntity

	local function ShowComboLevel()
		local centre = hero:GetPosition() + CVector3(0,0,3)
		local level = CurrentCombo / BaseComboPerLevel
		for i=1,level do
			local thing = Debug.CreateEntityAt("FX_Musicbox_Disappear", "myfx", hero:GetPosition())
			thing:SetPosition(centre + CVector3(
												math.sin(math.rad(360/level * (i + .5))),
												0, 
												math.cos(math.rad(360/level * (i + .5)))
												)
			)
			Sound.PlayEventAtPitch(Entities.WispEnt, "SE_SPELL_RELEASE_BUTTON_TARGETED_TIME_SLOT_" .. tostring(i), "", 1.8)
			coroutine.yield(); coroutine.yield()
		end
	end

	while not ShouldDie do

		if countdown_timer:GetTime() == 0 then
			countdown_timer:SetTime(BaseComboCountdown)
			CurrentCombo = (CurrentCombo > 1 and CurrentCombo - 1) or 0 -- WeirdChamp ternary but okay
		end

		if InCombat then
			was_enemy_hit, enemy_hit_message = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_HIT, lastid)
			if was_enemy_hit then

				hit_enemy = enemy_hit_message:GetEntitySentTo()
				lastid = enemy_hit_message:GetID()
				damage_type = enemy_hit_message:GetExtraDataAsNumber()
				local damage_was_melee = damage_type == EHitDamageType.HIT_DAMAGE_CUT or damage_type == EHitDamageType.HIT_DAMAGE_BLUNT or damage_type == EHitDamageType.HIT_DAMAGE_GENERIC

				if hit_enemy ~= hero and enemy_hit_message:GetEntitySentBy() == hero and damage_was_melee then
					CurrentCombo = CurrentCombo + 1
					countdown_timer:SetTime(BaseComboCountdown)
					if CurrentCombo % BaseComboPerLevel == 0 then ShowComboLevel() end
				elseif hit_enemy == hero then
					CurrentCombo = math.floor(CurrentCombo/2)
				end
				
			end
		else
			CurrentCombo = 0
		end
		coroutine.yield()
	end
end

function SpawnCage(targetpos)
	-- GUI.DisplayMessageBox("debug: spawning cage")
    local sword = Debug.CreateEntityByHero("MetalWork_Minigame_Stage1")
    sword:SetPosition(targetpos + CVector3(-0.5,0,1))
    Physics.SetFacingVector(sword, CVector3(0,0,0))
	GraphicAppearance.SetScale(sword, 1.7)
	BindObjects[1] = sword


    sword = Debug.CreateEntityByHero("MetalWork_Minigame_Stage1")
    sword:SetPosition(targetpos + CVector3(0.5,0,1))
    Physics.SetFacingVector(sword, CVector3(0,0,0))
	GraphicAppearance.SetScale(sword, 1.7)
	BindObjects[2] = sword

    sword = Debug.CreateEntityByHero("MetalWork_Minigame_Stage1")
    sword:SetPosition(targetpos + CVector3(0,0.5,1))
    Physics.SetFacingVector(sword, CVector3(1,0,0))
	GraphicAppearance.SetScale(sword, 1.7)
	BindObjects[3] = sword

    sword = Debug.CreateEntityByHero("MetalWork_Minigame_Stage1")
    sword:SetPosition(targetpos + CVector3(0,-0.5,1))
    Physics.SetFacingVector(sword, CVector3(1,0,0))
	GraphicAppearance.SetScale(sword, 1.7)
	BindObjects[4] = sword
end

function RemoveCage()
	for i=1,#BindObjects do
		BindObjects[i]:Destroy()
	end
end

function ZapUltimate()
	local hero = QuestManager.HeroEntity
	local empty_handed = true
	local temp_obj
	local hand_weapon = ObjectAttachment.GetEntityAttachedToDummy(hero, DummyObjects.HAND_RIGHT, 0)
	if hand_weapon and hand_weapon:IsAlive() then
		empty_handed = false
	end
	if empty_handed then
		temp_obj = Debug.CreateEntityByHero("ObjectChickenDrumstick")
		GraphicAppearance.SetCameraAlpha(temp_obj, 0)
		ObjectAttachment.AddEntity(hero, temp_obj, "Character.Carry.Hand.Right", 0)
	end


	Action.FinishAllActions(hero)

	local action = {
		Type = EScriptableAction.LOOP,
		Priority = EActionPriority.PRIORITY_COMBAT_UNINTERRUPTABLE_STRIKE,
		IntoAction = {
		    Type = EScriptableAction.PLAY_ANIMATION,
			Anim = "ExpressionTrophyInto",
			OverrideLooking = true,
			SpeedMultiplier = .2
		},
		LoopAction = {
			Type = EScriptableAction.PLAY_ANIMATION,
			Anim = "ExpressionTrophyLoop",
			OverrideLooking = true,
			SpeedMultiplier = 15
		},
		NumLoops = 1
	}
	Wisp.SetDestination(Entities.WispEnt, (temp_obj or hand_weapon):GetPosition() + CVector3(0,0,2))
	Action.SetCurrentAction(hero, action)
	ScriptFunction.WaitForCurrentActionToFinish(hero)

	local zap_origin
	if not empty_handed then
		-- todo: Spread zap points across Weapon.Weapon.Sheathe (1h only?), Hold, UpperHold (some 2h only) and Top
		zap_origin = GraphicAppearance.GetDummyObjectPosition(hand_weapon, "Weapon.Weapon.Hold", 0)
	else
		zap_origin = GraphicAppearance.GetDummyObjectPosition(hero, "Character.Carry.Hand.Right", 0)
	end

	local targets = CameraManager.GetFoes(SACCamera:GetMaxSearchDistanceForEnemies())

	Player.AddRumbleFromTable(hero, {
	  ID = ERumbleTypes.RUMBLE_TYPE_QUAKE,
	  MaxLevel = 1,
	  AttackTime = 1,
	  DecayTime = 1,
	  Duration = 2,
	  LeaveOpen = false
	})
	Player.AddScreenShake(hero, {
	  ID = ERumbleTypes.RUMBLE_TYPE_PLAYER_HIT,
	  MaxLevel = 2,
	  AttackTime = .5,
	  DecayTime = 1,
	  Duration = 1,
	  LeaveOpen = false
	})

	SpellManager.CreateScriptedSpellShot(Entities.WispEnt, ESpellType.SPELL_LIGHTNING, 1,
										 Entities.WispEnt:GetPosition(), true, temp_obj or hand_weapon, CVector3(0, 0, 0))
	ScriptFunction.WaitForTimeInSeconds(.25)

	if zap_origin then
		for i=0,#targets do
		SpellManager.CreateScriptedSpellShot(hero, ESpellType.SPELL_LIGHTNING, math.floor(CurrentCombo / 4),
										 zap_origin, true, targets[i], CVector3(0, 0, 0))
		end
	end
	if temp_obj then
		temp_obj:Destroy()
	end
	CurrentCombo = 0
end

function IsXAndAPressed()
	local a_posted, amsg = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_GENERIC_A_BUTTON_PRESSED, LastMessageID_PressedAButton)
	if a_posted then 
		LastMessageID_PressedAButton = amsg:GetID()
		last_a_press = amsg:GetTimeStamp()
	end
	local x_posted, xmsg = MessageEvents.IsMessagePosted(EMessageEventType.MESSAGE_EVENT_GENERIC_X_BUTTON_PRESSED, LastMessageID_PressedXButton)
	if x_posted then 
		LastMessageID_PressedXButton = xmsg:GetID()
		last_x_press = xmsg:GetTimeStamp()
	end
	local time_allowance = Timing.GetTickRate() / 7
	local world_frame = Timing.GetWorldFrame()
	return math.abs(last_x_press - world_frame) < time_allowance and math.abs(last_a_press - world_frame) < time_allowance and math.abs(last_x_press - last_a_press) < time_allowance
end

function AreEnemiesNear()
	if SACCamera then
		return #CameraManager.GetFoes(SACCamera:GetMaxSearchDistanceForEnemies()) > 0 -- *sigh* Using this instead of SACCamera's nearby foes because it's not perfect.
	else
		GUI.DisplayMessageBox("SACCamera is nil!")
		ShouldDie = true
	end
end

-- This function gets a new target for the wisp to target and hop to.
function AcquireNewTarget(oldTarget)
	DisplayBlocking("debug: AcquireNewTarget start")
	local potentialTargets = CameraManager.GetFoes(SACCamera:GetMaxSearchDistanceForEnemies())
	local target
	if #potentialTargets > 0 then
		target = potentialTargets[math.random(1, #potentialTargets)]
		local moreTargets = #potentialTargets > 1
		local creature_type = Creature.GetCreatureType(target)
		if moreTargets and (target == oldTarget or creature_type == ECreatureType.CREATURE_TROLL or creature_type == ECreatureType.CREATURE_SHARD) then
			-- Already have this target and there's more than one. We want ver eye it ee
			local potentialNewTargets = {}
			local isthereanewtarget = false
			for k,v in ipairs(potentialTargets) do
				creature_type = Creature.GetCreatureType(v)
				if oldTarget ~= v and (creature_type ~= ECreatureType.CREATURE_TROLL and creature_type ~= ECreatureType.CREATURE_SHARD) then
					table.insert(potentialNewTargets, #potentialNewTargets+1, v)
					isthereanewtarget = true
				end
			end
			if not isthereanewtarget then
				DisplayBlocking("Out of all potential targets, none were valid. This may happen when fighting multiple shards.")
			else
				target = potentialNewTargets[math.random(1, #potentialNewTargets)]
			end
		end
		if target == nil or not target:IsAlive() then
			target = QuestManager.HeroEntity
			DisplayBlocking("Wisp tried to get dead or nil enemy! Given hero instead.\nThis should NEVER happen.")
		end
	else
		-- In the future, when this happens try getting the heroes target if its relation is enemy.
		target = QuestManager.HeroEntity
	end
	DisplayBlocking("debug: AcquireNewTarget end")
	return target
end

function DoTargetSwap(old_target, effect, appliedtimer, swaptimer, time)
	RemoveEffect(old_target, effect)
	WispTarget = AcquireNewTarget(old_target)
	if WispTarget ~= QuestManager.HeroEntity then
		ApplyEffect(WispTarget, effect)
	end
	if swaptimer then
		swaptimer:SetTime(time)
	end
	if appliedtimer then
		appliedtimer:SetTime(time)
	end
end

-- This function applies effects to the target entity, and spawns vfx.
function ApplyEffect(target, effect)
	DisplayBlocking("ApplyEffect start")
	if target == QuestManager.HeroEntity then
		GUI.DisplayMessageBox("Wisp tried to apply effect to hero")
		return
	elseif target == nil then
		GUI.DisplayMessageBox("Wisp tried to apply effect to nil")
		return
	end


	if target and target:IsAlive() then
		if effect == EffectEnum.VULNERABILITY then
			Health.Modify(target, -Health.Get(target)/2, target)
		elseif effect == EffectEnum.BIND then
			SpawnCage(target:GetPosition())
		end
		Entities.CurrentVFX = Debug.CreateEntityAt("FX_CullisGate_Stage_01", "wispfx", target:GetPosition())
		ObjectAttachment.AddEntity(target, Entities.CurrentVFX, "", 0)
	end
	

	DisplayBlocking("ApplyEffect end, vfx spawned")
end

-- This function removes effects from the target entity.
function RemoveEffect(target, effect)
	DisplayBlocking("debug: Remove effect start")
	if Entities.CurrentVFX then
		Entities.CurrentVFX:Destroy()
	end
	if target == QuestManager.HeroEntity then return end
	if target and target:IsAlive() then
		if effect == EffectEnum.VULNERABILITY then
			Health.Modify(target, Health.Get(target), target)
		end
	end
	if effect == EffectEnum.BIND then
		RemoveCage()
	end
	DisplayBlocking("debug: Remove effect end")
end



function DisplayBlocking(msg)
	if PainfulDebug then
		GUI.DisplayMessageBox(tostring(msg))
		ScriptFunction.WaitForTimeInSeconds(.5)
	end
end

local function ShutWispUp()
	local tab = {}
	function tab:Update()
		ScriptFunction.WaitForTimeInSeconds(2)
		if Entities and Entities.WispEnt and Entities.WispEnt:IsAlive() then
			Sound.SetPitchForSoundCategory(Entities.WispEnt, "", 0, 1)
		else
			GUI.DisplayMessageBox(tostring("failed to get wisp ent to shut up"))
		end
	end
	GeneralScriptManager.AddScript(tab)
end
ModHooks.AddHook("OnEnterArea", "ShutWispUpEnterArea", ShutWispUp, nil)
ModHooks.AddHook("OnSaveLoad", "ShutWispUpOnLoad", ShutWispUp, nil)

function Disable()
	if InCombat then
		RemoveEffect(WispTarget, CurrentEffect)
	end
	if Entities.WispEnt then Entities.WispEnt:Destroy() end
	if Entities.CurrentVFX then Entities.CurrentVFX:Destroy() end
	ModHooks.RemoveHook("OnSaveLoad", "ShutWispUpEnterArea")
	ModHooks.RemoveHook("OnSaveLoad", "ShutWispUpOnLoad")
end