local chickensinfo = {}
local particles = {}
if GetScriptFromGsmByName then local oldco = GetScriptFromGsmByName("chickenrain"); if oldco then oldco.ShouldDie = true end; end
local hero = QuestManager.HeroEntity


local snippetco = {ScriptName = "chickenrain"}
function snippetco:Update()
	self.custom_update = coroutine.create(self.CustomUpdate)
	while not self.ShouldDie do
		coroutine.yield()
		self.MyScriptWorked, self.ScriptWhyNot = coroutine.resume(self.custom_update, self)
		if not self.MyScriptWorked then
			GUI.DisplayMessageBox("Script errored! Reason:\n " .. tostring(self.ScriptWhyNot))
			self.ShouldDie = true
		end
	end
	coroutine.yield()
	for k,v in pairs(chickensinfo) do
		destroy_chicken(v)
	end
end

function snippetco:CustomUpdate()
	local chickenlimit = 20
	local spawndelay = .2
	local radius = 30 * 2
	local blastradius = 4
	local blastfxscale = 1
	local blastdamage = 150
	local spawnTimer = QuestManager.NewTimer(0)

	local function destroy_chicken(info)
		info["chicken"]:Destroy()
		info["fx"]:Destroy()
	end

	local function explode_damage(info)
		local search = SearchTools.FilterWithEC(SearchTools.StartNewSearch("creature"), Hittable.GetECType())
		SearchTools.FilterWithinDistanceOfPos(search, info["chicken"]:GetPosition(), blastradius)
		local results = SearchTools.GetSearchResults(search)

		for k,v in ipairs(results) do
			Hittable.Hit(v, {Damage = blastdamage})
		end
	end

	local toOverride = true
	while not self.ShouldDie do
		coroutine.yield()

		if toOverride then
			toOverride = false
			EnvironmentTheme.SetOverrideBlending(true)
		end

		-- Spawn Chicken and FX, add to tracker
		if spawnTimer:GetTime() <= 0 then
			local chickeninfo = {}

			-- Chicken
			local chicken = Debug.CreateEntityByHero("CreatureFaunaChicken")
			table.insert(chickensinfo, 1, chickeninfo)
			chicken:SetPosition(hero:GetPosition() + CVector3(math.random(radius) - radius/2, math.random(radius) - radius/2, 10))
			chickeninfo["chicken"] = chicken
			Physics.SetVelocity(chicken, CVector3(0,0,-.5))

			-- FX
			local fx = Debug.CreateEntityByHero("FX_Torch_Fire")
			ParticleEmitter.SetScale(fx, 3)
			ObjectAttachment.AddEntity(chicken, fx)
			chickeninfo["fx"] = fx

			spawnTimer:SetTime(spawndelay)
		end

		-- Chicken Updater. Iterate over each chicken and explode on contact.
		for infoID,infotable in ipairs(chickensinfo) do
			local chicken = infotable["chicken"]
			local lastvel = infotable["LastVelocity"]
			local newvel = Physics.GetVelocity(chicken)

			lastvel = lastvel or newvel
			infotable["LastVelocity"] = newvel

			-- If velocity had a big change, we hit something. Explode.
			local diff = math.abs(newvel:GetLength() - lastvel:GetLength())
			if diff > 1 then
				local explosion = Debug.CreateEntityAt("FX_Teleporter_Explosion", "explosion", chicken:GetPosition())
				ParticleEmitter.SetScale(explosion, blastfxscale)
				explosion:SetPosition(chicken:GetPosition())
				explode_damage(infotable)
				destroy_chicken(infotable)
				table.remove(chickensinfo, infoID)
				MessageEvents.PostMessage({
			      type = "SCARY",
			      from = explosion,
			      to = explosion
				})
			end
		end

		-- Cull any chickens that have not exploded
		if #chickensinfo > chickenlimit then
			local deletedchicken = chickensinfo[#chickensinfo]
			destroy_chicken(deletedchicken)
			chickensinfo[#chickensinfo] = nil
		end
	end
	for k,v in pairs(chickensinfo) do
		destroy_chicken(v)
	end
end


GeneralScriptManager.AddScript(snippetco)