-- MOD HOOKS
ModHooks = {}
setmetatable(ModHooks, ModHooks)

local hooks_script = loadfile("scripts/Mod Manager/modhooks.lua")
if type(hooks_script) ~= "function" then
	GUI.DisplayMessageBox("Mod Manager failed to run modhooks script!" .. "\n\nReason: " .. ((type(hooks_script) == "string") and "Failed to find script!" or "Failed to compile script!"))
end

ModHooks.__index = _G
setfenv(hooks_script, ModHooks)
hooks_script()

-- PATCHING

Patching = {}
setmetatable(Patching, Patching)

local patch_script = loadfile("scripts/Mod Manager/Patching/DeltaPatchIngame.lua")
if type(patch_script) ~= "function" then
	GUI.DisplayMessageBox("Mod Manager failed to run Patching script!" .. "\n\nReason: " .. ((type(patch_script) == "string") and "Failed to find script!" or "Failed to compile script!"))
else
	Patching.__index = _G
	setfenv(patch_script, Patching)
	patch_script()
end

-- MOD MISC
ModMisc = {}
setmetatable(ModMisc, ModMisc)

local misc_script = loadfile("scripts/Mod Manager/modmisc.lua")
if type(misc_script) ~= "function" then
	GUI.DisplayMessageBox("Mod Manager failed to run modhooks script!" .. "\n\nReason: " .. ((type(misc_script) == "string") and "Failed to find script!" or "Failed to compile script!"))
end

ModMisc.__index = _G
setfenv(misc_script, ModMisc)
misc_script()