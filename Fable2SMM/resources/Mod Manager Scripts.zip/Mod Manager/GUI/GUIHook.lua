
-- Overwrite loadfile with our custom version defined in and passed from the expandablemenudebugging patch.
local arg = {...}
arg = arg[1]
loadfile = arg or loadfile

-- Opens/Creates a menu log file for writing
-- Replaces `output` and `print` with a write to the log file
do
  local logfile,fileerror = io.open("GAME:\\logs\\menu.log", "w")
  local file_iteration = 0
  while fileerror and string.find(fileerror, "Permission") do 
    logfile,fileerror = io.open("GAME:\\logs\\menu" .. tostring(file_iteration) .. ".log", "w")
    if file_iteration > 30 then return end -- Error prone, but I higly highly doubt there will be more than 30 contracts/instances/whatever.
  end

  local oldprint = print
  if logfile then
    local oldoutput = output
    function output(...)
      pcall(oldoutput, ...)
      if not ... or type(...) ~= "string" then
        logfile:write(tostring(... or "nil")) 
      else
        logfile:write(...)
      end
      logfile:write("\n")
      logfile:flush()
    end
    function print(...)
      pcall(oldprint, ...)
      if not ... or type(...) ~= "string" then
        logfile:write(tostring(... or "nil")) 
      else
        logfile:write(...)
      end
      logfile:write("\n")
      logfile:flush()
    end
  end
  -- while not logfile do oldprint("MYFAIL: FILEFAILED | " .. tostring(fileerror or "noreason")) end
  output("GUIHooked!")
end 

-- A function to explore a little bit
function PrintTable(tab, objectname)
  local objType = type(tab)
  if objType ~= "table" then 
    output("---------------ERROR: PrintTable was passed a " .. objType .. " instead of a table!---------------") 
    return
  end

  output("--------------- PRINTING " .. tostring(objectname or "someobj") .. " ---------------")
  for k,v in pairs(tab) do
    output(tostring(k))
  end
  output("--------------------------------------------------")
end

-- Trigger Patch Generation
-- *MOVED TO MYGUICODE "TEMPORARILY"*




-- Run our code file


local code = loadfile("GAME:\\data\\scripts\\Mod Manager\\GUI\\MyGUIcode.lua")
if type(code) == "function" then
  local worked, reason = pcall(code)
  if not worked then
    pcall(output, "ERROR: FAILED TO RUN MYGUICODE: " .. tostring(reason or "no reason???"))
  end
end
