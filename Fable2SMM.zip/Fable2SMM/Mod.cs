﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows;
using System.Runtime.CompilerServices;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace Fable2SMM
{

    public class Mod : INotifyPropertyChanged
    {
        public Mod(string NameID, string StartScriptPath, double VersionMajor, double VersionMinor, bool Installed, bool Enabled, bool ClearData, List<string> Files, string Description, string Author, List<string> AuthorURLs, bool IsFromInstalledMods)
        {
            if (string.IsNullOrEmpty(NameID) || StartScriptPath == null || Files == null)
                throw new Exception($"Tried to instantiate mod but something is null:\nname={NameID}, startscript={StartScriptPath}, files={Files}");
            else if (Files.Count == 0)
                Console.WriteLine("Files for mod " + NameID + " is empty. There should probably be at least 1 file.");

            List<string> manURLs = null;
            if (IsFromInstalledMods)
            {
                // If we're in installedmods, get additional info (description, author, etc) from manifest.
                Mod manMod = ManifestParser.ConvertManifestToMod(ManifestParser.GetManifestFromModFolder(NameID));
                if (manMod != null)
                {
                    if (string.IsNullOrEmpty(Description))
                        Description = manMod.Description;
                    if (string.IsNullOrEmpty(Author))
                        Author = manMod.Author;
                    if (AuthorURLs.Count == 0)
                    {
                        manURLs = manMod.AuthorURLs;
                    }
                }
            }

            this._nameID = NameID;
            this._startScriptPath = StartScriptPath;
            this._versionMajor = VersionMajor;
            this._versionMinor = VersionMinor;
            this._installed = Installed;
            this._enabled = Enabled;
            this._clearData = ClearData;
            this._isFromInstalledMods = IsFromInstalledMods;
            this._files = Files;
            this._description = Description;
            this._author = Author;
            this._authorURLs = manURLs ?? AuthorURLs;
        }

        public static string InstalledModsPath { get { return ModManaging.RunnerFolder + @"\installedmods.lua"; } }

        // Should be called by the setter
        public void SetModBool(bool value, [CallerMemberName] string property = "")
        {
            string propertyPath = $"installedmods.{this.NameID}.{property}";
            (var values, var _) = LuaParsing.ParseTable(ModManaging.CurrentInstalledModsContent, out Dictionary<string, object> newTable, new List<string> { propertyPath });
            if (!values.ContainsKey(propertyPath))
                throw new Exception("Couldn't toggle enabled on mod " + this.NameID);

            ModManaging.InstalledModsFileDict = newTable;
            ModManaging.CurrentInstalledModsContent = LuaParsing.ReplaceNextWordInString(ModManaging.CurrentInstalledModsContent, value.ToString().ToLower(), values[propertyPath]);
            if (ModManaging.RealtimeSaving)
                File.WriteAllText(InstalledModsPath, ModManaging.CurrentInstalledModsContent);
        }

        public static void InstallMod(Mod mod)
        {
            throw new NotImplementedException("Consider using the InstallModIntoInstalledModsAndAddToList method instead");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="manifestContent">The mods manifest used to create the table string for installedmods. If null, tries to get the folder name from the NameID.</param>
        public void InstallModIntoInstalledModsAndAddToList(string manifestContent = null)
        {
            if (string.IsNullOrEmpty(manifestContent))
                manifestContent = ManifestParser.GetManifestFromModFolder(NameID);
            if (LuaParsing.IsModInInstalledMods(NameID))
            {
                UpdateMod();
                return;
            }
            string modTableString = ManifestParser.ConvertJsonManifestIntoTable(manifestContent);

            ModManaging.CurrentInstalledModsContent = LuaParsing.AddTableToInstalledMods(ModManaging.CurrentInstalledModsContent, modTableString, NameID);
            Installed = true;
            IsFromInstalledMods = true;
            DirManifest.CurrentDirManifestContent = DirManifest.AddModFilesToDirManifest(this);
            ModManaging.ModList.Add(this);
        }

        /// <summary>
        /// Takes info from the Mod's manifest in the Mods folder then updates the dir.manifest & installedmods.lua files appropriately.
        /// </summary>
        public void UpdateMod()
        {
            // Basically take the new version's manifest (and convert it to a table), then add the old management values to it, then replace the old version in installedmods with the new version.
            bool wasInstalled, wasEnabled, wasClearData;
            wasInstalled = Installed;
            wasEnabled = Enabled;
            wasClearData = ClearData;
            string wasInstalledString = wasInstalled.ToString().ToLower();
            string wasEnabledString = wasEnabled.ToString().ToLower();
            string wasClearDataString = wasClearData.ToString().ToLower();
            string newManifest = ManifestParser.GetManifestFromModFolder(NameID);
            string newModTableString = ManifestParser.ConvertJsonManifestIntoTable(newManifest, true);
            // Keep the mod's installed bool the same:
            (var foundBoolOffsets, var foundKeyOffsets) = LuaParsing.ParseTable(newModTableString, out Dictionary<string, object> newModTableDict, new List<string>() { $"{NameID}.Installed" });
            if (foundBoolOffsets.Count <= 0)
                throw new Exception("Failed to find Installed bool in mod " + NameID + " (from manifest)");
            newModTableString = LuaParsing.ReplaceNextWordInString(newModTableString, wasInstalledString, foundBoolOffsets[$"{NameID}.Installed"]);
            // Keep the mod's enabled bool the same:
            (foundBoolOffsets, foundKeyOffsets) = LuaParsing.ParseTable(newModTableString, out newModTableDict, new List<string>() { $"{NameID}.Enabled" });
            if (foundBoolOffsets.Count <= 0)
                throw new Exception("Failed to find Enabled bool in mod " + NameID + " (from manifest)");
            newModTableString = LuaParsing.ReplaceNextWordInString(newModTableString, wasEnabledString, foundBoolOffsets[$"{NameID}.Enabled"]);
            // Keep the mod's cleardata bools the same:
            (foundBoolOffsets, foundKeyOffsets) = LuaParsing.ParseTable(newModTableString, out newModTableDict, new List<string>() { $"{NameID}.ClearData" });
            if (foundBoolOffsets.Count <= 0)
                throw new Exception("Failed to find ClearData bool in mod " + NameID + " (from manifest)");
            newModTableString = LuaParsing.ReplaceNextWordInString(newModTableString, wasClearDataString, foundBoolOffsets[$"{NameID}.ClearData"]);

            // Now that we have the new mod version, we need to replace the old one by removing it and inserting the new one
            string modPath = $"installedmods.{NameID}";
            (foundBoolOffsets, foundKeyOffsets) = LuaParsing.ParseTable(ModManaging.CurrentInstalledModsContent, out var installedModsDict, new List<string>() { modPath });
            if (foundKeyOffsets.Count <= 0)
                throw new Exception("Failed to find Mod " + NameID + " in installedmods to remove for updating!");

            // Remove old mod files and add new ones
            {
                Mod newMod = ManifestParser.ConvertManifestToMod(newManifest);
                var newModfiles = newMod.Files;
                var redundantFiles = new List<string>();
                redundantFiles.AddRange(Files.Where(x => !newModfiles.Contains(x)));
                Console.WriteLine($"DEBUG: Removing files from {NameID}: `{redundantFiles.Count}`");


                DirManifest.CurrentDirManifestContent = DirManifest.RemoveFilesFromDirManifest(redundantFiles, DirManifest.CurrentDirManifestContent);
                DirManifest.CurrentDirManifestContent = DirManifest.AddModFilesToDirManifest(newMod);
                Files = newModfiles;
            }

            // Remove old mod table and insert the new one
            ModManaging.CurrentInstalledModsContent = LuaParsing.RemoveNextTableInString(ModManaging.CurrentInstalledModsContent, foundKeyOffsets[modPath]);
            ModManaging.CurrentInstalledModsContent = LuaParsing.AddTableToInstalledMods(ModManaging.CurrentInstalledModsContent, newModTableString, NameID);

            LuaParsing.ParseTable(ModManaging.CurrentInstalledModsContent, out installedModsDict); // Reassign the new installedmods dictionary containing the new mod version to the public property
            ModManaging.InstalledModsFileDict = installedModsDict;
        }


        public void DeleteModCompletely()
        {
            Console.WriteLine("Trying to delete mod " + NameID + " and its files. Is this okay?");
            if (Console.ReadKey().Key != ConsoleKey.Y)
                return;
            // First we remove the mod's table. Honestly, this probably isn't something we should do except in extreme circumstances
            string search = $"installedmods.{NameID}";
            (var _, var keyPos) = LuaParsing.ParseTable(ModManaging.CurrentInstalledModsContent, out var _, new List<string> { search });
            if (!keyPos.ContainsKey(search))
                throw new Exception("Failed to find mod in installedmods.lua to remove!");
            ModManaging.CurrentInstalledModsContent = LuaParsing.RemoveNextTableInString(ModManaging.CurrentInstalledModsContent, keyPos[search]);

            // Remove the mods dir.manifest entries
            DirManifest.CurrentDirManifestContent = DirManifest.RemoveFilesFromDirManifest(Files, DirManifest.CurrentDirManifestContent);
            ModManaging.InstalledModsFileDict.Remove(search);
            ModManaging.ModList.Remove(this);


            string finalFolderPath = Path.Combine(ModManaging.ModsFolder, NameID);
            if (finalFolderPath == ModManaging.ModsFolder)
                throw new Exception("Almost deleted entire mods folder! NameID of this mod must be wrong " + NameID);

            if (!Directory.Exists(finalFolderPath))
                throw new Exception($"Failed to find folder {NameID} in /Mods/ folder!");
            if (Directory.Exists(finalFolderPath))
                Directory.Delete(finalFolderPath, true);
        }



        public override string ToString()
        {
            string nameString = NameID ?? "NULLMODNAME";
            return nameString;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] String propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public string NameID { get { return _nameID; } set { _nameID = value; OnPropertyChanged(); } }
        private string _nameID;
        public string StartScriptPath { get { return _startScriptPath; } set { _startScriptPath = value; OnPropertyChanged(); } }
        private string _startScriptPath;
        public double VersionMajor { get { return _versionMajor; } set { _versionMajor = value; OnPropertyChanged(); } }
        private double _versionMajor;
        public double VersionMinor { get { return _versionMinor; } set { _versionMinor = value; OnPropertyChanged(); } }
        private double _versionMinor;

        public bool Installed
        {
            get { return _installed; }
            set
            {
                if (value)
                {
                    if (!LuaParsing.IsModInInstalledMods(NameID))
                    {
                        if (!IsFromInstalledMods) // TODO: There is almost certainly a better way. Maybe we should store the manifest text in the Mod object? This is kinda gross
                            ModManaging.CurrentInstalledModsContent = LuaParsing.AddTableToInstalledMods(ModManaging.CurrentInstalledModsContent, ManifestParser.ConvertJsonManifestIntoTable(ManifestParser.GetManifestFromModFolder(NameID)), NameID);
                        else
                            throw new Exception("Mod is not in installedmods file but is also not from manifest?\nThis would only happen if we retained a manifest from a zip/folder, OR if the user deleted the manifest during runtime.");
                    }
                }
                _installed = value;
                SetModBool(value);
                if (!value)
                    Enabled = false;
                OnPropertyChanged();
            }
        }
        private bool _installed;

        public bool Enabled
        {
            get { return _enabled; }
            set
            {
                if (!Installed)
                    value = false;
                _enabled = value;
                SetModBool(value);
                OnPropertyChanged();
            }
        }
        private bool _enabled;
        public bool ClearData
        {
            get { return _clearData; }
            set
            {
                _clearData = value;
                SetModBool(value);
                OnPropertyChanged();
            }
        }
        private bool _clearData;

        public List<string> Files { get { return _files; } set { _files = value; } }
        private List<string> _files;

        public string Description { get { return _description; } set { _description = value; } }
        private string _description;
        public string Author { get { return _author; } set { _author = value; } }
        private string _author;
        public List<string> AuthorURLs { get { return _authorURLs; } set { _authorURLs = value; OnPropertyChanged(); } }
        private List<string> _authorURLs;

        public bool IsOutOfDate { get { return _isOutOfDate; } set { _isOutOfDate = value; } }
        private bool _isOutOfDate;
        public bool IsDeleted { get { return _isDeleted; } set { _isDeleted = value; } }
        private bool _isDeleted;

        public bool IsFromInstalledMods { get { return _isFromInstalledMods; } set { _isFromInstalledMods = value; } }
        private bool _isFromInstalledMods;

        public bool HasImage { get { return File.Exists(Path.Combine(ModManaging.ModsFolder, NameID, "thumb.png")); } }
        public Uri ImageUri { get { return new Uri(Path.Combine(ModManaging.ModsFolder, NameID, "thumb.png")); } }

    }
}
