lastError = "Error not set yet"
oldError = Debug.Error
function ModUpdate()
	custom_update = coroutine.create(CustomUpdate)
	while not ShouldDie do
		coroutine.yield()
		MyScriptWorked, ScriptWhyNot = coroutine.resume(custom_update)
		if not MyScriptWorked then
			GUI.DisplayMessageBox("Script errored! Reason:\n " .. tostring(ScriptWhyNot))
			ShouldDie = true
		end
	end
	Debug.Error = oldError
	coroutine.yield()
end

function CustomUpdate()
	while not ShouldDie do
		coroutine.yield()
		Debug.Draw3DText(QuestManager.HeroEntity:GetPosition() + CVector3(0,0,3), lastError)
	end
end

function MyError(...)
	if type(...) == "table" then
		lastError = unpack(...)
	else
		lastError = ...
	end
	oldError(...)
end

Debug.Error = MyError

function Disable()
	Debug.Error = oldError
end