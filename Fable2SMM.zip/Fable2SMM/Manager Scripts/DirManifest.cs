﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Fable2SMM
{
    class DirManifest
    {
        public static string DirManifestPath { get { return ManagerInstallation.DataFolder + @"\dir.manifest"; } }
        public static string DirManifestBackupPath { get { return DirManifestPath + ".bak"; } }
        public static string DirManifestForcedPath { get { return ManagerInstallation.DataFolder + @"\dir.forced.manifest"; } }

        public const string DirManifestForcedResourcePath = ManagerInstallation.ResourcesFolder + "/dir.forced.manifest";

        public static string CurrentDirManifestContent { get { return _currentDirManifestContent; } set { _currentDirManifestContent = value; OnCurrentDirManifestContentChanged(EventArgs.Empty); } }
        static string _currentDirManifestContent = "";
        public static event EventHandler CurrentDirManifestContentChanged;
        private static void OnCurrentDirManifestContentChanged(EventArgs e)
        { CurrentDirManifestContentChanged?.Invoke(null, e); System.Diagnostics.Trace.WriteLine("Changing dir manifest content!"); }


        public const string dirManifestHash = "C67DD5E9E6C6D433A5F8D88B1CECA8D0D778D71718DC5785D98D79F251E23090";

        public static string AddFilesToDirManifest(List<string> files)
        {
            // Split manifest into strings and create a dict for efficient comparison
            List<string> newFilesLines = new List<string>();
            List<string> newDirManifestLines = CurrentDirManifestContent.Split(
                                    new string[] { "\r\n", "\r", "\n" },
                                    StringSplitOptions.None
                                ).ToList();
            Dictionary<string, bool> manifestAsDict = new Dictionary<string, bool>();
            foreach (string thisEntry in newDirManifestLines)
            {
                if (string.IsNullOrEmpty(thisEntry))
                    continue;
                manifestAsDict.Add(thisEntry.Replace('/', '\\'), true);
            }
            // Sanitize file string and add it to the new files list if it isn't already in the manifest dict
            foreach (string file in files)
            {
                string fileTrimmed = file.Trim().Replace('/', '\\');
                if (manifestAsDict.ContainsKey(fileTrimmed))
                    System.Diagnostics.Trace.WriteLine($"File is already in dir.manifest:\n\t`{fileTrimmed}`");
                else
                    newFilesLines.Add(fileTrimmed);
            }
            newDirManifestLines = newDirManifestLines.Concat(newFilesLines).ToList();
            return string.Join("\n", newDirManifestLines);
        }
        public static string AddModFilesToDirManifest(Mod mod)
        {
            return AddFilesToDirManifest(mod.Files);
        }
        public static void AddForcedFilesToDirManifest()
        {
            List<string> forcedfiles = File.ReadAllLines(DirManifestForcedPath).ToList();
            CurrentDirManifestContent = AddFilesToDirManifest(forcedfiles);
        }

        public static string RemoveModFilesFromDirManifest(Mod mod)
        {
            return RemoveFilesFromDirManifest(mod.Files, CurrentDirManifestContent);
        }
        public static string RemoveFilesFromDirManifest(List<string> filesToRemove, string manifestContent)
        {
            List<string> dirManifestLines = manifestContent.Split(
                                                new string[] { "\r\n", "\r", "\n" },
                                                StringSplitOptions.None
                                            ).ToList();
            filesToRemove = filesToRemove.Select(x => x.Replace('/', '\\')).ToList();
            dirManifestLines.RemoveAll(x => filesToRemove.Contains(x));
            return string.Join("\n", dirManifestLines);
        }
        public static List<string> DirManifestDeltaFromFiles(string manifestPath, string backupPath)
        {
            List<string> manFiles = File.ReadAllLines(manifestPath).ToList();
            Dictionary<string, string> backFilesDict = File.ReadAllLines(backupPath).ToDictionary<string, string>(x => x);
            List<string> delta = manFiles.Where((file, index) => !backFilesDict.ContainsKey(file)).ToList();

            return delta;
        }
        public static bool VerifyDirManifestBackup(string backupmanPath)
        {
            return ManagerInstallation.GetFileHash(backupmanPath) == dirManifestHash;
        }
        public static void RestoreOriginalDirManifest(bool addForcedFiles)
        {
            //throw new NotImplementedException("You should make sure this code is correct before calling this properly :p");
            File.Copy(DirManifestBackupPath, DirManifestPath, true);
            CurrentDirManifestContent = File.ReadAllText(DirManifestPath);

            AddForcedFilesToDirManifest();
        }
        public static void ResetAndAddModsToDirManifest()
        {
            RestoreOriginalDirManifest(true);
            foreach (Mod mod in ModManaging.ModList)
            {
                CurrentDirManifestContent = AddModFilesToDirManifest(mod);
            }
            File.WriteAllText(DirManifestPath, CurrentDirManifestContent);
        }
    }
}
